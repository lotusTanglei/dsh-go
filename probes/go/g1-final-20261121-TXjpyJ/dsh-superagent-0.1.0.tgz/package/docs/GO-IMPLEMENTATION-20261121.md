# Go 实施核对与证据（2026-11-21）

实施授权：用户要求按 [开发提示词](<superagent-design-20261121-v2/PROMPTS.md>) 开发。设计包原文、既有未提交文档及探针保留；这不是安装、部署、迁移或提交许可。

## G0：只读核实

运行安装版：`@deepseek-ai/dsh 0.2.2-rc.5`，Electron `44.7.0` / Node `24.21.0`。工作区 shell Node 是 `22.23.1`，因此测试、类型检查、构建使用 `ELECTRON_RUN_AS_NODE=1 "$DSH_NODE_EXECUTABLE"`（安装版 runtime）。没有 Inspect / 浏览器控制，源码合同不是实时挂载和真实 GUI 证据。

| 已知能力 / 缺口 | 证据与处理 |
| --- | --- |
| 已有可信 Host 项目成员、普通会话结构化工作观察、默认纳入与会话排除、异步失效 | [Source](<../src/sources/session-work.ts>)、[Host 接线](<../src/runtime.ts>)。不靠 cwd / 标题猜项目；不读所有聊天来定位。 |
| 现有命令仅文本到超管 / Ticket lineage | [命令](<../src/workspace/commands.ts>)、[投递](<../src/workspace/ingress.ts>)。可复用 digest / CAS / dispatch fence / unknown 对账；不等于普通会话控制已实现。 |
| 普通会话实际控制 API | [controller prompt](</Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-api-session-controller/src/index.ts#L468>)：`prompt(request, signal): Promise<{accepted:true}>`，请求含 `requestId/sessionId/mode:queue|steer/content`，没有统一 `submit`。`control(signal)` 是投影流而非命令；[agent resolve](</Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-api-session-controller/src/agent.ts#L151>) 支持普通 cold/live，拒绝 subagent-origin。未做真实控制探针。 |
| 幂等不能直接沿用 Host ID 去重当完成保证 | [commands](</Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-api-session-controller/src/commands.ts#L389>) 仅按 ID 记忆，不比较正文 digest；适配层须补冲突/版本/fence/最小证据对账。`accepted:true` 不是完成或人已读。 |
| stop 与 queue 管理 | [commands](</Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-api-session-controller/src/commands.ts#L447-L539>) 的 `updateQueue` 支持 edit/remove/steer，`cancel` 对 live 普通 Agent；不能把申请当已停止。 |
| 模型扩展点 | [LLM prepareCall](</Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-llm/src/index.ts#L975>) 支持逐次固定配置；[Agent model](</Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-agent/src/runtime-types.ts#L71>) 的 `model.select` 影响下一未准备 step。现有 session `selectModel` [写全局默认](</Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-api-session-controller/src/commands.ts#L180>)，不能当阶段配置入口。 |
| 原图链不能直接复用附件 API 冒称闭环 | [附件读取](</Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-api-session-controller/src/commands.ts#L427>) 不验证图片归属，不能充当范围闸；[本地图片存储](</Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-attachment-local/README.md#L88>) 可缩放/重编码，不等于原始字节保真。generic file 保真但视觉能力另验。 |
| 视觉未知不等于支持 | [prompt admission](</Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-api-session-controller/src/commands.ts#L352>) 仅已知否定时拒绝；[LLM](</Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/dsh-llm/src/index.ts#L1120>) 可把 text-only 历史图降占位。Go 需要严格能力与原图引用检查，不能沿此默认放行。 |
| 来源接入 | [当前配置](<../src/config.ts>) 仅 session/inbox/wecom-document。企微连接器不等于 docs.qq.com；腾讯表格/普通文档和本地格式仍须逐类实现/验证，支持矩阵未最终确认。 |
| 权限与安全 | [已知限制](<KNOWN-LIMITS.md>) L1/L2 未通过，生产 Worker 关闭；普通控制不能成为执行旁路。Host/Origin 不是身份，保留既有 owner/Origin/epoch；本轮不修改 profile 或核心。 |

## 首个最窄切片：G1 范围与无副作用定位

使用路径：管理范围 → 完整分页的项目目录（含空项目）→ 当前项目会话 → 排除/恢复回执。范围由真实成员和稳定 ID 计算；项目排除优先，会话显式排除保留；恢复不激活、不重投、不复用批准。归属 unknown 仅呈现元数据，禁止读取工作正文和定位。

复用现有 `kv` 存储独立项目 ID 集与递增 scope version；保持 legacy 会话排除 key 不变，不改 schema、不迁移用户数据。递增序号防止“排除→恢复”把旧授权版本重新变有效（ABA）；版本是撤权 fence，不是新许可。

无副作用定位使用已获准的有限结构化目标与字面检索，不声称自然语言模型定位已实现。显式 session ID 仍重验当前目录、范围与归属；标题独命中只追问，同名不盲投；最多核实 100 项，超出或证据不全显示 partial/blocked，不把首个摘要页当全集。定位结果始终 `controlAvailable:false`，不是控制成功或执行授权。

## 验证记录

- 修改前基线：50 files / 598 tests 通过（Electron Node 24），未连接 provider、未控制用户会话。
- 第一轮范围代码定向：37 tests 通过；typecheck 发现项目目录 DTO 扩大了 `sessionWork` 返回联合类型，旧测试仅以 `items` 判别不足，改为同时判别会话 `scope`。此为类型合同修正，未删测试/降断言；下一轮须重新验证。
- 首轮全量门禁 690/693 通过，3 项失败已调查：旧 Client AST 测试不认识新增非执行定位字段；精确 route 清单缺 `session-locate`；artifact 检测到构建前旧 locale。修正的是精确新接口白名单/清单，命令直投仍禁止；先构建最新资源再完整回归。
- 第二轮：typecheck / build / client syntax 与 54 files / 693 tests 全通过。独立对抗复核补修：定位不复用 15 秒旧事实或 summary 在途读取、定位及项目目录迟到结果重验内部归属/访问/停止状态，均有反例回归。
- 独立 UX 静态复核另发现 3 项，均补修并增加反例：原操作回执独立于导航且标原 epoch；保存后有界重读原已加载项目窗口并恢复项目/tab；同名候选返回脱敏限长命中字段和片段作为文本显示。随后门禁 54 files / 701 tests、typecheck/build/syntax/pack dry-run 通过，包清单 162 项。
- UX 再复核发现同一导航路径的遗漏：同 epoch 的精确保存回执若在 Sources 页到达，旧 Sources 分页缓存未失效。已补同 epoch 失效与观测 generation，拒绝旧在途响应回填；跨 epoch 不清新页缓存。定向 43 tests、noEmit、diff check 通过；全量最终门禁证据位于 [G1 最终证据目录](<../probes/go/g1-final-20261121-TXjpyJ/>)。旧 flight 期间新读取不自动排队；完成后保留显式刷新，不盲重试。
- G1 最终门禁：54 files / **704 tests** 通过；typecheck、build、client syntax、diff check 全部 exit 0。见 [测试日志](<../probes/go/g1-final-20261121-TXjpyJ/test.log>)、[构建日志](<../probes/go/g1-final-20261121-TXjpyJ/build.log>)。所有新旧测试使用本地合成 Host / 隔离 SQLite，无 provider 或用户会话控制。
- 未运行真实 Host 探针、未安装更新，原 GUI 的视觉/点击/IME/焦点/主题/窄屏均 unknown；测试不是 R1—R5 或 A01—A15 完整验收。

### 原 URL 人工检查（均待验）

在原 DSH GUI `http://127.0.0.1:59762`，经另行授权加载新版后：设置 → 管理范围 → 空项目/同名项目 → 单项目纳入/排除；核对真实保存回执与排除不停止提示；回来源确认旧正文消失；项目第二页保存后返回原项目；定位同名候选的目标片段、明确选择重验、partial/blocked 文案；导航和保存并发不改草稿/目标。浅/深主题、窄屏/短高度、Tab/读屏、焦点返回、中文 IME 输入和 Escape 候选取消另验。当前没有浏览器控制，未启动替代服务或伪造截图。

## 需求 / 验收映射（本切片，不代替最终规格）

| 范围 | 当前证据 | 未通过 / 未验 |
| --- | --- | --- |
| R4 / A02 / A11 | 项目目录含空项目；项目与会话排除优先级；持久递增版本；改名/移动/重启与新增会话反例 | 真实安装 Host 项目与 GUI 保存未验；“所有”仅当前 Host，非其他 profile/进程/机器 |
| R1 / A01 / A10 | 有限字面定位；结构化目标命中、同名追问、显式选择重验；伪造ID/注入不能控制 | 完整自然语言定位、普通 cold/live 执行、人类指令→持久目标回执仍未闭环，不能宣称 R1 完成 |
| R4 / A12 / A14 | 读前/读后/发布前范围、归属、访问与内部 lineage 重验；排除迟到拒绝、恢复不重放；范围 ABA fence | 实际已 dispatch 控制、附件撤权、原会话停止与崩溃回执尚待 G2/G3/G6 |
| R2 / A05 / A06 | 保留既有结构化进展与问题观察，不用 idle 当完成 | 集中精确业务回答/操作审批、自由输入联动与全部 legacy 问题投影尚待 G6 |
| R3 / A07—A09 | 保留既有企微来源及其真实类型边界 | 腾讯文档与本地来源目标矩阵/解析未交付，本切片没有裁剪原需求 |
| R5 / A13 | 核实逐次模型合同与全局默认副作用风险 | 六阶段路由设置/实际调用披露未实现 |
| A15 / 页面建议 | 仅新增范围与定位的分层设置路径和契约测试，主题 token 复用 | 总壳/hash/独立主对话等仍未实施；真实焦点、IME、窄屏/主题与当前 URL 未验 |

## 未闭合与下一步

G2—G6 继续按提示词顺序推进；缺真实控制隔离、原图权限/保真、腾讯接入认证、阶段路由和集中问题投影等条件时显式阻断受影响动作，不用假按钮/假保存填满页面。GUI 必须在原 URL 验证，无浏览器时列人工检查；不启动替代服务器、不安装、不重启。
