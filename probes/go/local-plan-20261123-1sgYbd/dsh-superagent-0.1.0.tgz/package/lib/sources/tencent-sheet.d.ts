import type { Store } from '../store/index.js';
export interface TencentSheetConfig {
    id: string;
    fileId: string;
    sheetId: string;
    range: string;
    idColumn: string;
    titleColumn: string;
    textColumns: string[];
    revision: string;
}
export interface TencentSheetGrant {
    handle: string;
    fence: string;
    scope: 'scope.sheet.readonly';
    fileId: string;
    sheetId: string;
    range: string;
    wire: 'documented-v3' | 'example-v3';
}
export interface TencentSheetRead {
    config: TencentSheetConfig;
    grant: TencentSheetGrant;
    signal: AbortSignal;
    check(): void;
}
export interface TencentSheetPorts {
    signal: AbortSignal;
    requireEpoch(epoch: string): void;
    authorize?(config: TencentSheetConfig, epoch: string): Promise<TencentSheetGrant>;
    requireGrant?(grant: TencentSheetGrant, config: TencentSheetConfig, epoch: string): void;
    transport?(input: TencentSheetRead): Promise<Uint8Array>;
}
interface Auth {
    epoch: string;
}
interface CAS extends Auth {
    id: string;
    expectedRevision: string;
}
export interface TencentSheetConfigure extends Auth {
    id: string;
    fileId: string;
    sheetId: string;
    range: string;
    idColumn: string;
    titleColumn: string;
    textColumns: string[];
    expectedRevision: string | null;
}
export interface TencentSheetScan extends CAS {
    expectedSnapshot: string | null;
}
export interface TencentSheetDetail extends CAS {
    snapshotId: string;
}
export interface TencentSheetClaim extends TencentSheetDetail {
    itemId: string;
    requestId: string;
    humanReview: 'reviewed-for-draft';
}
export interface Item {
    itemId: string;
    rowId: string;
    row: number;
    title: string;
    text: string;
    strike: 'yes' | 'no' | 'unknown';
    eligible: false;
}
export interface Snapshot {
    snapshotId: string;
    revision: string;
    config: TencentSheetConfig;
    raw: string;
    items: Item[];
    capturedAt: number;
    remoteRevision: 'unknown';
    images: {
        state: 'unknown';
        imageSeen: false;
    };
    trust: 'external-untrusted';
    authorization: 'not-granted';
}
export interface Head {
    snapshotId: string | null;
    configRevision: string;
    state: 'unscanned' | 'partial' | 'blocked';
    reason: string;
    epoch?: string;
    changes?: {
        added: string[];
        changed: string[];
        removed: string[];
    };
}
export interface TencentSheetScanResult extends Head {
    sourceId: string;
    revision?: string;
    remoteRevision: 'unknown';
    images: {
        state: 'unknown';
        imageSeen: false;
    };
    items: Item[];
    authorization: 'not-granted';
}
export declare const TENCENT_SHEET_SUPPORT: readonly [{
    readonly kind: "tencent-sheet";
    readonly state: "partial";
    readonly reason: "oauth-original-images-and-remote-revision-not-verified";
}, {
    readonly kind: "tencent-document";
    readonly state: "unsupported";
}, {
    readonly kind: "wecom-document";
    readonly state: "not-this-connector";
}, {
    readonly kind: "office";
    readonly state: "unsupported";
}, {
    readonly kind: "pdf";
    readonly state: "unsupported";
}];
/** Host-only secret resolver; no URL from browser/evidence and no OAuth/profile changes. */
export declare function createTencentSheetTransport(ports: {
    credentials(handle: string): Promise<{
        clientId: string;
        openId: string;
        accessToken: string;
    }>;
    fetch?: typeof fetch;
}): (input: TencentSheetRead) => Promise<Uint8Array>;
/** Isolated manual observations. Missing original-image/version contracts never become execution authority. */
export declare function createTencentSheets(store: Store, ports: TencentSheetPorts): {
    list(input: Auth): {
        sources: {
            freshness: string;
            snapshotId?: string | null | undefined;
            configRevision?: string | undefined;
            state?: "partial" | "blocked" | "unscanned" | undefined;
            reason?: string | undefined;
            epoch?: string;
            changes?: {
                added: string[];
                changed: string[];
                removed: string[];
            };
            id: string;
            fileId: string;
            sheetId: string;
            range: string;
            idColumn: string;
            titleColumn: string;
            textColumns: string[];
            revision: string;
        }[];
        connection: string;
        support: readonly [{
            readonly kind: "tencent-sheet";
            readonly state: "partial";
            readonly reason: "oauth-original-images-and-remote-revision-not-verified";
        }, {
            readonly kind: "tencent-document";
            readonly state: "unsupported";
        }, {
            readonly kind: "wecom-document";
            readonly state: "not-this-connector";
        }, {
            readonly kind: "office";
            readonly state: "unsupported";
        }, {
            readonly kind: "pdf";
            readonly state: "unsupported";
        }];
    };
    configure(input: TencentSheetConfigure, onCommit?: (result: TencentSheetConfig) => void): TencentSheetConfig;
    remove(input: CAS, onCommit?: (result: {
        id: string;
        removed: true;
    }) => void): {
        id: string;
        removed: true;
    };
    scan(input: TencentSheetScan, onCommit?: (result: TencentSheetScanResult) => void): Promise<TencentSheetScanResult>;
    detail(input: TencentSheetDetail): {
        raw: undefined;
        current: boolean;
        state: "partial";
        reason: string;
        changes: {
            added: string[];
            changed: string[];
            removed: string[];
        } | undefined;
        freshness: "manual-observation-not-remote-atomic";
        snapshotId: string;
        revision: string;
        config: TencentSheetConfig;
        items: Item[];
        capturedAt: number;
        remoteRevision: "unknown";
        images: {
            state: "unknown";
            imageSeen: false;
        };
        trust: "external-untrusted";
        authorization: "not-granted";
    };
    claim(input: TencentSheetClaim): never;
};
export {};
