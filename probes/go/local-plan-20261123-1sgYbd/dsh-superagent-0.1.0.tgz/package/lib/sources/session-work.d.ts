import type { Source, ThreadContext } from './types.js';
export interface SessionWorkPorts {
    listProjects?(): readonly {
        id: string;
        title: string;
        sessionIds: readonly string[];
        accessible?: boolean;
    }[];
    listSessions(signal: AbortSignal): Promise<readonly any[]>;
    read(sessionId: string, signal: AbortSignal): Promise<{
        asOfSeq: number;
        values: Record<string, unknown>;
    }>;
    agent(sessionId: string): any;
    ownedSessionIds(): readonly string[];
    canAccess(sessionId: string): boolean;
    getExcluded(): readonly string[];
    setExcluded(ids: readonly string[]): void;
    getExcludedProjects?(): readonly string[];
    setExcludedProjects?(ids: readonly string[]): void;
    getScopeVersion?(): number;
    signal: AbortSignal;
}
export type SessionWorkProject = {
    kind: 'project';
    key: string;
    name: string;
} | {
    kind: 'unassigned' | 'unknown';
    key: 'unassigned' | 'unknown';
};
export interface SessionWorkItem {
    sessionId: string;
    title: string;
    objective?: string;
    project: SessionWorkProject;
    runtime: 'running' | 'idle' | 'unavailable' | 'unknown';
    goalPhase?: string;
    progress?: string;
    nextAction?: string;
    blocker?: string;
    decision?: string;
    done?: string[];
    result?: {
        state: 'goal-complete' | 'unverified';
        summary?: string;
        acceptanceVerified: false;
    };
    approvalCoverage: 'unavailable';
    observedAt: number;
    evidence: 'structured' | 'missing' | 'unavailable';
    excluded: boolean;
    exclusionReason?: 'session' | 'project' | 'membership-unknown';
    factRevision?: string;
}
export interface SessionWorkListInput {
    view?: 'included' | 'excluded';
    cursor?: string;
    limit?: number;
    projectKey?: string;
}
export interface ScopeProject {
    key: string;
    kind: SessionWorkProject['kind'];
    name?: string;
    excluded: boolean;
    sessionTotal: number;
    includedTotal: number;
}
export interface ScopeProjectList {
    state: 'ready' | 'partial';
    revision: string;
    sampledAt: number;
    items: ScopeProject[];
    total: number;
    hasMore: boolean;
    next?: string;
}
export interface SessionWorkList {
    state: 'ready' | 'partial' | 'unavailable';
    sampledAt: number;
    scope: 'current-host';
    defaultIncluded: true;
    total: number | null;
    excludedTotal: number | null;
    internalTotal: number | null;
    items: SessionWorkItem[];
    hasMore: boolean;
    next?: string;
    revision?: string;
    error?: 'session_work_unavailable' | 'session_work_partial';
}
/** Manual, read-only current-host projection. No subscriptions, prompts, triggers, or actions. */
export declare class SessionWorkSource implements Source {
    private readonly ports;
    readonly id: import("../domain/ids.js").SourceId;
    readonly kind: "session-work";
    readonly attended = false;
    private active;
    private localAbort;
    private generation;
    private roster?;
    private rosterFlight?;
    private readonly pending;
    private readonly reads;
    private readonly itemFlights;
    private readonly items;
    private readonly labels;
    constructor(ports: SessionWorkPorts);
    start(): Promise<void>;
    stop(): Promise<void>;
    health(): Promise<{
        ok: boolean;
        lastAt: number | undefined;
    }>;
    verify(_input: unknown): Promise<boolean>;
    normalize(_input: unknown): Promise<[]>;
    readThread(key: Parameters<Source['readThread']>[0]): Promise<ThreadContext>;
    reply(..._args: Parameters<Source['reply']>): Promise<void>;
    summary(): Promise<SessionWorkList>;
    list(input?: SessionWorkListInput): Promise<SessionWorkList>;
    setIncluded(sessionId: string, included: boolean, input: {
        revision: string;
    }): Promise<{
        sessionId: string;
        included: boolean;
        revision: string;
    }>;
    listScopeProjects(input?: {
        cursor?: string;
        limit?: number;
    }): Promise<ScopeProjectList>;
    setProjectIncluded(projectId: string, included: boolean, input: {
        revision: string;
    }): Promise<{
        projectId: string;
        included: boolean;
        revision: string;
        stopped: false;
    }>;
    /** Bounded fact search, not a control grant. Explicit stable IDs never bypass membership.
     * A title match alone requires clarification; only structured objective evidence locates.
     */
    locate(input: {
        text: string;
        sessionId?: string;
        revision?: string;
    }): Promise<{
        status: "blocked";
        code: string;
        candidates: never[];
        revision: string;
        controlAvailable: false;
        executionReason: string;
    } | {
        status: "blocked";
        code: string;
        coverage: "partial";
        searched: number;
        candidates: {
            sessionId: string;
            title: string;
            project: SessionWorkProject;
            factRevision: string | undefined;
            observedAt: number;
            evidence: "unavailable" | "structured" | "missing";
            matchField: "title" | "progress" | "objective" | "nextAction";
            matchText: string;
        }[];
        revision: string;
        controlAvailable: false;
        executionReason: string;
    } | {
        status: "no_match";
        coverage: "complete";
        searched: number;
        candidates: {
            sessionId: string;
            title: string;
            project: SessionWorkProject;
            factRevision: string | undefined;
            observedAt: number;
            evidence: "unavailable" | "structured" | "missing";
            matchField: "title" | "progress" | "objective" | "nextAction";
            matchText: string;
        }[];
        revision: string;
        controlAvailable: false;
        executionReason: string;
    } | {
        status: "clarify";
        code: string;
        candidates: {
            sessionId: string;
            title: string;
            project: SessionWorkProject;
            factRevision: string | undefined;
            observedAt: number;
            evidence: "unavailable" | "structured" | "missing";
            matchField: "title" | "progress" | "objective" | "nextAction";
            matchText: string;
        }[];
        candidateTotal: number;
        revision: string;
        controlAvailable: false;
        executionReason: string;
    } | {
        status: "located";
        target: {
            sessionId: string;
            title: string;
            project: SessionWorkProject;
            factRevision: string | undefined;
            observedAt: number;
            evidence: "unavailable" | "structured" | "missing";
            matchField: "title" | "progress" | "objective" | "nextAction";
            matchText: string;
        } | undefined;
        candidates: {
            sessionId: string;
            title: string;
            project: SessionWorkProject;
            factRevision: string | undefined;
            observedAt: number;
            evidence: "unavailable" | "structured" | "missing";
            matchField: "title" | "progress" | "objective" | "nextAction";
            matchText: string;
        }[];
        coverage: "complete";
        searched: number;
        revision: string;
        controlAvailable: false;
        executionReason: string;
    }>;
    /** Metadata-only global scope cut for staged uploads; no work bodies or control grant. */
    imageScope(): Promise<{
        revision: string;
        fence: () => void;
    }>;
    /** A fresh, exact target binding plus synchronous revocation fence. Not a control grant. */
    actionTarget(input: {
        sessionId: string;
        scopeRevision: string;
        factRevision: string;
    }): Promise<{
        binding: {
            sessionId: string;
            scopeRevision: string;
            factRevision: string;
            project: {
                kind: "project" | "unassigned";
                key: string;
            };
        };
        fence: () => void;
    }>;
    private available;
    private access;
    private runtime;
    private signal;
    private track;
    private invalidate;
    private exclusion;
    private makeRosterFromMembership;
    private readProjects;
    private getRoster;
    private page;
    private empty;
    private copyItem;
    private project;
    private readProjection;
}
