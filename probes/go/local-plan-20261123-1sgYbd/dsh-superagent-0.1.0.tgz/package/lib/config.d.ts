/** Minimal adapter for the installed Schemastery API; no fabricated DSH service. */
export interface SchemaNode<T = unknown> {
    (input?: unknown): T;
    required(): SchemaNode<T>;
    default(value: unknown): SchemaNode<T>;
    min(value: number): SchemaNode<T>;
    step(value: number): SchemaNode<T>;
}
export interface SchemaFactory {
    string(): SchemaNode<string>;
    number(): SchemaNode<number>;
    boolean(): SchemaNode<boolean>;
    object(properties: Record<string, SchemaNode>): SchemaNode;
    array(inner: SchemaNode): SchemaNode;
    union(values: readonly string[]): SchemaNode;
}
export interface SourceConfig {
    readonly id: string;
    readonly kind: 'session' | 'inbox' | 'wecom-document';
    readonly attended: boolean;
}
export interface WecomDocumentConfig extends SourceConfig {
    readonly kind: 'wecom-document';
    readonly attended: false;
    readonly doc: string;
    readonly sheet: string;
    readonly range: string;
    readonly idColumn: string;
    readonly titleColumn: string;
    readonly textColumns: readonly string[];
    readonly filter?: {
        readonly column: string;
        readonly values: readonly string[];
    };
    /** Actual sheet row number, not an offset; defaults to the range's first row. */
    readonly firstDataRow?: number;
}
export interface WecomDocumentRange {
    readonly r0: number;
    readonly r1: number;
    readonly c0: number;
    readonly c1: number;
}
/** Only finite, explicit A1 rectangles are accepted; no sheet names or open ranges. */
export declare function parseWecomDocumentRange(input: string): WecomDocumentRange;
/** Canonical identity excludes tab query parameters but never accepts a foreign URL. */
export declare function wecomDocumentId(doc: string): string;
/** Reused by resolveConfig and the manual adapter; no runtime or connector policy here. */
export declare function validateWecomDocumentConfig(input: unknown): asserts input is WecomDocumentConfig;
export interface Config {
    readonly stateDir: string;
    readonly dbPath: string;
    readonly lockPath: string;
    readonly workRoot: string;
    readonly mainSessionId?: string;
    readonly routerReadScope: 'none' | 'reported' | 'repo';
    readonly confirm: 'always' | 'when-ambiguous' | 'never';
    readonly acceptMode: 'off' | 'observe' | 'auto';
    readonly bots: 'deny' | 'infer';
    readonly paused: boolean;
    readonly maxWorkers: number;
    readonly queueLimit: number;
    readonly evalTimeoutMs: number;
    readonly maxEvalRequeues: number;
    readonly maxStepsPerTicket: number;
    readonly maxTokensPerTicket: number;
    readonly maxDurationMsPerTicket: number;
    readonly maxRetries: number;
    readonly watchdogIntervalMs: number;
    readonly stallMs: number;
    readonly repeatCallThreshold: number;
    readonly waitingHumanMs: number;
    readonly budgetWarningRatio: number;
    readonly approvalTimeoutMs: number;
    readonly outboxMaxAttempts: number;
    readonly outboxBackoffMs: number;
    readonly outboxBackoffMaxMs: number;
    readonly panelPollMs: number;
    readonly panelPageSize: number;
    readonly backupIntervalMs: number;
    readonly backupKeep: number;
    readonly triggerRetentionMs: number;
    readonly outboundRetentionMs: number;
    readonly sqliteBusyTimeoutMs: number;
    readonly staleLockMs: number;
    readonly sources: readonly SourceConfig[];
    /** Explicit Host-authorized roots; never derived from projects or browser paths. */
    readonly localSourceRoots?: readonly {
        readonly id: string;
        readonly path: string;
        readonly name?: string;
    }[];
    readonly roleTools: {
        readonly router: readonly string[];
        readonly worker: readonly string[];
        readonly watchdog: readonly string[];
    };
}
/** Defaults are centralized configuration, never deployment constants in consumers. */
export declare const defaults: Readonly<{
    routerReadScope: "reported";
    confirm: "when-ambiguous";
    acceptMode: "auto";
    bots: "deny";
    paused: false;
    maxWorkers: 3;
    queueLimit: 200;
    evalTimeoutMs: 120000;
    maxEvalRequeues: 2;
    maxStepsPerTicket: 80;
    maxTokensPerTicket: 2000000;
    maxDurationMsPerTicket: 7200000;
    maxRetries: 2;
    watchdogIntervalMs: 60000;
    stallMs: 300000;
    repeatCallThreshold: 3;
    waitingHumanMs: 1800000;
    budgetWarningRatio: 0.8;
    approvalTimeoutMs: 86400000;
    outboxMaxAttempts: 5;
    outboxBackoffMs: 1000;
    outboxBackoffMaxMs: 60000;
    panelPollMs: 5000;
    panelPageSize: 20;
    backupIntervalMs: 86400000;
    backupKeep: 7;
    triggerRetentionMs: 7776000000;
    outboundRetentionMs: 2592000000;
    sqliteBusyTimeoutMs: 5000;
    staleLockMs: 3600000;
    roleTools: Readonly<{
        router: string[];
        worker: string[];
        watchdog: string[];
    }>;
}>;
/** Exported by host.cjs as the actual callable Schemastery Config, not a JSON object. */
export declare function createConfigSchema(z: SchemaFactory): SchemaNode<Config>;
/** Cross-field/path validation, called after real Schemastery validation. */
export declare function resolveConfig(config: Config): Config;
