/** Serialized client factory: every runtime helper is local, no Host/client package imports. */
export declare function createGoDecisions(React: any, request: (path: string, body?: any, signal?: any) => Promise<any>, t: any): {
    Decisions: (props: {
        epoch: string;
        active: boolean;
        located: any;
    }) => any;
};
