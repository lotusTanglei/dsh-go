/** Serialized client factory: only injected React/request/t and browser primitives. */
export declare function createGoTencent(React: any, request: (path: string, body: any, signal?: AbortSignal) => Promise<any>, t: any): {
    TencentSources: (props: {
        epoch: string;
        active?: boolean;
    }) => any;
};
