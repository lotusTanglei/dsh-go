/** Serialized into the client runtime: all helpers stay inside the factory, with no imports. */
export declare function createGoProjects(React: any, request: (path: string, body: any, signal?: AbortSignal) => Promise<any>, t: any): {
    Projects: (props: {
        epoch: string;
        active: boolean;
        scopeRevision?: string;
        projectKey?: string;
        sessionId?: string;
        tab?: string;
        onNavigate: (view: {
            projectKey?: string;
            sessionId?: string;
            tab?: string;
        }) => void;
        onInspectTarget?: (row: any, revision: string) => void;
        onSources?: () => void;
    }) => any;
};
