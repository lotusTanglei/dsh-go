import { deriveDeskState } from './desk-model.js';
import { createGoSettings } from './go-settings.js';
import { createGoDecisions } from './go-decisions.js';
import { createGoTencent } from './go-tencent.js';
import { createGoProjects } from './go-projects.js';
/** Serialized by the client builder. Every runtime helper is local or explicitly supplied. */
export declare function createWorkspacePage(React: any, request: (path: string, body?: any, signal?: any) => Promise<any>, t: any, css: string, deskState?: typeof deriveDeskState, settingsFactory?: typeof createGoSettings, decisionsFactory?: typeof createGoDecisions, tencentFactory?: typeof createGoTencent, projectsFactory?: typeof createGoProjects): () => any;
