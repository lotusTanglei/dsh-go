/** Fixed, layered workspace shell; prototype proportions with host theme tokens. */
export declare function workspaceStyles(): string;
