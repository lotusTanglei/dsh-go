import { type EffectiveSetting } from './settings.js';
import type { Store, Row } from '../store/index.js';
/** Structural subset of the installed Connection service. No DSH package dependency is needed. */
export interface PanelConnection {
    fetch: {
        register(route: {
            path: string;
            methods: readonly ['POST'];
            requestBody: 'buffered';
            fetch(request: Request): Promise<Response>;
        }): (() => void | Promise<void>);
    };
}
export interface PanelContext {
    readonly connection: PanelConnection;
    readonly effect?: (factory: () => (() => void | Promise<void>)) => unknown;
}
export interface PanelConfig {
    readonly approvalTimeoutMs?: number;
    readonly panelPollMs?: number;
    readonly panelPageSize?: number;
    readonly panelOrigins?: readonly string[];
    readonly paused?: boolean;
    readonly maxWorkers?: number;
    readonly routerReadScope?: string;
    readonly confirm?: string;
    readonly acceptMode?: string;
    readonly bots?: string;
}
/** Side effects that must be supplied by the owning runtime; routes never fake a successful action. */
export interface PanelPorts {
    readonly workspace?: (input?: {
        cursor?: string;
        limit?: number;
        planId?: string;
    }) => Promise<unknown>;
    readonly conversation?: (input: any) => Promise<unknown>;
    readonly command?: (input: any) => Promise<unknown>;
    readonly commandStatus?: (input: any) => Promise<unknown>;
    readonly cancelCommand?: (input: any) => Promise<unknown>;
    readonly admission?: (input: any) => Promise<unknown>;
    readonly reviseAdmission?: (input: any) => Promise<unknown>;
    readonly ownsTicketTransitions?: boolean;
    readonly health?: () => unknown | Promise<unknown>;
    readonly sources?: () => unknown | Promise<unknown>;
    /** Runtime verifies the current epoch; list/detail are local observations, scan is explicit only. */
    readonly documentSource?: (input: any) => Promise<unknown>;
    /** Passive current-Host observations and persistent membership only; runtime checks epoch/revision. */
    readonly sessionWork?: (input: any) => Promise<unknown>;
    /** Side-effect-free target proposal only; never dispatches to the returned Session. */
    readonly sessionLocate?: (input: any) => Promise<unknown>;
    /** Exact prepared control metadata only; production is blocked before any Agent activation. */
    readonly sessionAction?: (input: any) => Promise<unknown>;
    /** Bounded original-byte upload/preview and target binding; no model or delivery call. */
    readonly images?: (input: any) => Promise<unknown>;
    readonly localSources?: (input: any) => Promise<unknown>;
    readonly stageModels?: (input: any) => Promise<unknown>;
    readonly sessionDecision?: (input: any) => Promise<unknown>;
    readonly configMutation?: (input: any) => Promise<unknown>;
    readonly tencentSource?: (input: any) => Promise<unknown>;
    /** Exact local evidence only; never resolves a caller-provided path, URL, or tool. */
    readonly documentImage?: (input: any) => Promise<{
        bytes: Buffer;
        mimeType: string;
    }>;
    readonly settings?: () => readonly EffectiveSetting[] | Promise<readonly EffectiveSetting[]>;
    readonly stopTicket?: (ticketId: string, reason: string) => boolean | void | Promise<boolean | void>;
    readonly resumeTicket?: (ticketId: string) => boolean | void | Promise<boolean | void>;
    /** Revalidation is deliberately a port: a route cannot manufacture a valid mandate. */
    readonly mandateValid?: (ticket: Row) => boolean | Promise<boolean>;
    readonly approvalDecided?: (ticketId: string, approvalId: string, approved: boolean) => void | Promise<void>;
    /** Optional aliases accepted by adapters that name actions explicitly. */
    readonly ticketAction?: (action: 'stop' | 'resume', ticketId: string, reason?: string) => boolean | void | Promise<boolean | void>;
}
export interface PanelInstallation {
    readonly dispose: () => Promise<void>;
}
declare const ROUTES: readonly ["/workspace", "/conversation", "/command", "/command-status", "/command-cancel", "/admission", "/admission-revise", "/board", "/overview", "/tickets", "/ticket", "/threads", "/approvals", "/approval", "/ticket-action", "/health", "/settings", "/document-source", "/document-image", "/session-work", "/session-locate", "/session-action", "/images", "/local-sources", "/stage-models", "/session-decision", "/config-mutation", "/tencent-source"];
export declare function installPanelRoutes(context: PanelContext, store: Store, config: PanelConfig, ports?: PanelPorts): PanelInstallation;
export { ROUTES as PANEL_ROUTE_PATHS };
