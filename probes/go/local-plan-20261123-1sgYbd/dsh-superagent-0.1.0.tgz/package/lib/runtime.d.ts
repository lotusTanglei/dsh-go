import type { Config } from './config.js';
import type { Store, Row } from './store/index.js';
import { SourceRegistry } from './sources/registry.js';
import type { WorkerGuardSnapshot, RoleGuardRuntime } from './tools/runtime.js';
import { type DocumentOrigin } from './workspace/document-origin.js';
import { type SessionActionInput } from './workspace/session-actions.js';
import type { WecomToolsPort } from './sources/wecom-connector.js';
import type { Spawner } from './sessions/worker.js';
/** Narrow Host adapter; DSH's live APIs remain at this boundary. */
export interface RuntimeContext {
    readonly agents: {
        get(id: string): any;
        create(input: any): Promise<any>;
        resume?(input: any): Promise<any>;
    };
    readonly tools?: WecomToolsPort;
    readonly agentPresets: {
        mount(ctx: any, id: string): Promise<unknown>;
        composedPreset(ctx: any): string | undefined;
    };
    readonly subagents: {
        startActivation(input: any): Promise<any>;
        interrupt?(id: string, cause: any): unknown;
    };
    readonly sessionQuery: {
        readSession(id: string): Promise<any>;
        listSessions?(signal?: AbortSignal): Promise<readonly any[]>;
        inspectSession?<T>(id: string, read: (session: any) => T, signal?: AbortSignal): Promise<T>;
    };
    readonly sessionProjections?: {
        snapshot(session: any, keys: readonly string[]): {
            asOfSeq: number;
            values: Record<string, unknown>;
        };
    };
    readonly remoteAccess?: {
        allows(resource: {
            kind: 'session' | 'workspace';
            id: string;
        }): boolean;
    };
    readonly workspaceRegistry?: {
        list(): readonly {
            id: string;
            title: string;
            sessionIds: readonly string[];
        }[];
    };
    readonly get?: (name: string) => any;
    readonly sessions?: {
        flush(session: any): Promise<boolean>;
    };
    readonly agentDefaultModel?: {
        currentSelection(): any;
    };
    readonly llm?: {
        resolveModelInfo(provider: string, model: string, signal?: AbortSignal): Promise<any>;
        listProviders?(): readonly {
            id: string;
            name: string;
        }[];
        listModels?(provider: string): Promise<readonly {
            provider: string;
            id: string;
            name: string;
        }[]>;
    };
    readonly effect: (factory: () => (() => void | Promise<void>)) => unknown;
    readonly on: (event: string, callback: (...args: any[]) => any) => (() => void);
}
/** Every tool execution obtains a fresh trusted DB snapshot, not model-supplied ids. */
export declare function readWorkerSnapshot(store: Store, sessionId: string): WorkerGuardSnapshot | undefined;
/** Synthetic tests may inject a fake Spawner; production never obtains an execution bypass from Config or HTTP. */
export interface RuntimeTestAdapter {
    readonly spawner: Spawner;
    readonly legacyInput?: boolean;
}
export declare function createRuntime(ctx: RuntimeContext, store: Store, config: Config, roleGuard?: RoleGuardRuntime, testAdapter?: RuntimeTestAdapter): {
    ready: Promise<void>;
    engine: {
        ingest(trigger: import("./index.js").Trigger, scoped?: {
            targetTicketId: import("./domain/ids.js").TicketId;
        }): import("./engine/intake.js").IntakeResult;
        ackDelivery(triggerId: import("./domain/ids.js").TriggerId, assignmentId: import("./domain/ids.js").AssignmentId): boolean;
        evaluate(threadKey: import("./domain/ids.js").ThreadKey): Promise<import("./engine/eval.js").EvalResult | undefined>;
        enqueue(message: import("./engine/outbox.js").OutboxMessage): import("./index.js").Outbound;
        drainOutbox(): Promise<import("./engine/outbox.js").OutboxRunResult>;
        pause(): import("./engine/pause.js").PauseResult;
        resume(): import("./engine/pause.js").PauseResult;
        paused(): boolean;
        expireEval(id: import("./domain/ids.js").EvalId): import("./index.js").Eval | undefined;
        recover(): Promise<import("./engine/recovery.js").RecoveryReport>;
    };
    sources: SourceRegistry;
    startAssignment: (id: string) => Promise<{
        ok: boolean;
        code: string;
        assignmentId?: undefined;
    } | {
        ok: boolean;
        code: string;
        assignmentId: import("./domain/ids.js").AssignmentId;
    }>;
    stopTicket: (id: string, reason: string, by?: "human" | "watchdog") => Promise<boolean>;
    /** Same maintenance path as the timer, with no model wake or synthetic metrics. */
    tick(): Promise<void>;
    diagnostics(): {
        mainSessionId: string | undefined;
        triggers: {
            id: string;
            externalId: string;
            threadKey: string;
        }[];
        tickets: {
            id: string;
            state: string;
            outcome: unknown;
        }[];
        assignments: {
            id: string;
            ticketId: string;
            sessionId: string;
            state: string;
            report: unknown;
        }[];
        audit: {
            at: unknown;
            action: unknown;
            detail: unknown;
        }[];
        liveAgents: number;
    };
    invoke(name: string, args: any, exec: any): Promise<{
        ok: boolean;
        code: string;
        assignmentId: import("./domain/ids.js").AssignmentId;
    } | {
        ok: boolean;
        code: string;
        evidence: unknown;
        items?: undefined;
        ticket?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: any;
        evidence?: undefined;
        items?: undefined;
        ticket?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        items: {
            id: unknown;
            state: unknown;
            title: unknown;
        }[];
        evidence?: undefined;
        ticket?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        ticket: {
            id: unknown;
            title: unknown;
            state: unknown;
        };
        evidence?: undefined;
        items?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        plan: import("./workspace/admission.js").AdmissionPlanDTO;
        evidence?: undefined;
        items?: undefined;
        ticket?: undefined;
        ticketId?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        ticketId: import("./domain/ids.js").TicketId;
        evidence?: undefined;
        items?: undefined;
        ticket?: undefined;
        plan?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        errors: readonly string[];
        evidence?: undefined;
        items?: undefined;
        ticket?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        approvalId: `${string}-${string}-${string}-${string}-${string}`;
        evidence?: undefined;
        items?: undefined;
        ticket?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        errors?: undefined;
    }>;
    panelPorts: {
        workspace(input?: any): Promise<{
            pendingApprovals: number;
            admissionsNext?: string | undefined;
            admissions: import("./workspace/admission.js").AdmissionPlanDTO[];
            admissionsTotal: number;
            pendingPlans: number;
            sessionWork?: import("./sources/session-work.js").SessionWorkList | undefined;
            epoch: string;
            archiveEpochs: {
                epoch: string;
                createdAt: number;
            }[];
            state: string;
            model: {
                code?: string | undefined;
                available: boolean;
            };
            serverTime: number;
            capabilities: {
                conversation: boolean;
                send: boolean;
                workerExecution: boolean;
                executionReason: string;
            };
            documentSources: {
                id: string;
                sheet: string;
                range: string;
            }[];
            briefing: import("./workspace/briefing.js").WorkspaceBriefingDTO;
        }>;
        conversation(input: any): Promise<import("./workspace/conversation.js").ConversationPage>;
        command(input: any): Promise<{
            code?: string | undefined;
            ticketId?: string | undefined;
            requestId: string;
            messageId: string;
            epoch: string;
            stage: "unknown" | "received" | "queued" | "claimed" | "admitted" | "processing" | "published" | "canceled" | "rejected";
            accepted: boolean;
            seq: number;
            at: number;
            updatedAt: number;
        }>;
        cancelCommand(input: any): Promise<{
            code?: string | undefined;
            ticketId?: string | undefined;
            requestId: string;
            messageId: string;
            epoch: string;
            stage: "unknown" | "received" | "queued" | "claimed" | "admitted" | "processing" | "published" | "canceled" | "rejected";
            accepted: boolean;
            seq: number;
            at: number;
            updatedAt: number;
        }>;
        commandStatus(input: any): Promise<{
            code?: string | undefined;
            ticketId?: string | undefined;
            requestId: string;
            messageId: string;
            epoch: string;
            stage: "unknown" | "received" | "queued" | "claimed" | "admitted" | "processing" | "published" | "canceled" | "rejected";
            accepted: boolean;
            seq: number;
            at: number;
            updatedAt: number;
        }>;
        reviseAdmission(input: any): Promise<import("./workspace/admission.js").AdmissionPlanDTO>;
        admission(input: any): Promise<import("./workspace/admission.js").AdmissionPlanDTO>;
        sessionWork(input: {
            action: "list" | "set-included" | "projects" | "set-project-included";
            epoch: string;
            view?: "included" | "excluded";
            cursor?: string;
            limit?: number;
            projectKey?: string;
            projectId?: string;
            sessionId?: string;
            included?: boolean;
            revision?: string;
        }): Promise<import("./sources/session-work.js").ScopeProjectList | import("./sources/session-work.js").SessionWorkList | {
            sessionId: string;
            included: boolean;
            revision: string;
        } | {
            projectId: string;
            included: boolean;
            revision: string;
            stopped: false;
        }>;
        sessionLocate(input: {
            epoch: string;
            text: string;
            sessionId?: string;
            revision?: string;
        }): Promise<{
            status: "blocked";
            code: string;
            candidates: never[];
            revision: string;
            controlAvailable: false;
            executionReason: string;
        } | {
            status: "blocked";
            code: string;
            coverage: "partial";
            searched: number;
            candidates: {
                sessionId: string;
                title: string;
                project: import("./sources/session-work.js").SessionWorkProject;
                factRevision: string | undefined;
                observedAt: number;
                evidence: "unavailable" | "structured" | "missing";
                matchField: "title" | "progress" | "objective" | "nextAction";
                matchText: string;
            }[];
            revision: string;
            controlAvailable: false;
            executionReason: string;
        } | {
            status: "no_match";
            coverage: "complete";
            searched: number;
            candidates: {
                sessionId: string;
                title: string;
                project: import("./sources/session-work.js").SessionWorkProject;
                factRevision: string | undefined;
                observedAt: number;
                evidence: "unavailable" | "structured" | "missing";
                matchField: "title" | "progress" | "objective" | "nextAction";
                matchText: string;
            }[];
            revision: string;
            controlAvailable: false;
            executionReason: string;
        } | {
            status: "clarify";
            code: string;
            candidates: {
                sessionId: string;
                title: string;
                project: import("./sources/session-work.js").SessionWorkProject;
                factRevision: string | undefined;
                observedAt: number;
                evidence: "unavailable" | "structured" | "missing";
                matchField: "title" | "progress" | "objective" | "nextAction";
                matchText: string;
            }[];
            candidateTotal: number;
            revision: string;
            controlAvailable: false;
            executionReason: string;
        } | {
            status: "located";
            target: {
                sessionId: string;
                title: string;
                project: import("./sources/session-work.js").SessionWorkProject;
                factRevision: string | undefined;
                observedAt: number;
                evidence: "unavailable" | "structured" | "missing";
                matchField: "title" | "progress" | "objective" | "nextAction";
                matchText: string;
            } | undefined;
            candidates: {
                sessionId: string;
                title: string;
                project: import("./sources/session-work.js").SessionWorkProject;
                factRevision: string | undefined;
                observedAt: number;
                evidence: "unavailable" | "structured" | "missing";
                matchField: "title" | "progress" | "objective" | "nextAction";
                matchText: string;
            }[];
            coverage: "complete";
            searched: number;
            revision: string;
            controlAvailable: false;
            executionReason: string;
        }>;
        sessionAction(input: {
            action: "prepare";
            input: SessionActionInput;
        } | {
            action: "close";
            input: SessionActionInput;
        } | {
            action: "status";
            epoch: string;
            actionId: string;
        }): Promise<{
            target: {
                sessionId: string;
                scopeRevision: string;
                factRevision: string;
            };
            durable: true;
            accepted: false;
            executed: null;
            completed: null;
            disposition: "closed-before-dispatch";
            code: string;
            version: 1;
            epoch: string;
            requestId: string;
            actionId: string;
            operation: import("./workspace/session-actions.js").SessionOperation;
            digest: string;
            seq: 1;
            at: number;
            updatedAt: number;
            state: "closed";
            bindingVerified: false;
        } | {
            target: {
                project: {
                    kind: "project" | "unassigned";
                    key: string;
                };
                sessionId: string;
                scopeRevision: string;
                factRevision: string;
            };
            durable: true;
            accepted: boolean;
            executed: boolean | null;
            completed: boolean | null;
            disposition: string;
            version: 1;
            epoch: string;
            requestId: string;
            actionId: string;
            operation: import("./workspace/session-actions.js").SessionOperation;
            digest: string;
            messageId: string;
            seq: number;
            at: number;
            updatedAt: number;
            state: "recorded" | "blocked" | "dispatch_unknown" | "accepted";
            code?: string;
            controlRevision?: string;
            grantRevision?: string;
        }>;
        tencentSource(input: any): Promise<import("./workspace/config-mutations.js").ConfigMutationReceipt | {
            sources: {
                freshness: string;
                snapshotId?: string | null | undefined;
                configRevision?: string | undefined;
                state?: "partial" | "blocked" | "unscanned" | undefined;
                reason?: string | undefined;
                epoch?: string;
                changes?: {
                    added: string[];
                    changed: string[];
                    removed: string[];
                };
                id: string;
                fileId: string;
                sheetId: string;
                range: string;
                idColumn: string;
                titleColumn: string;
                textColumns: string[];
                revision: string;
            }[];
            connection: string;
            support: readonly [{
                readonly kind: "tencent-sheet";
                readonly state: "partial";
                readonly reason: "oauth-original-images-and-remote-revision-not-verified";
            }, {
                readonly kind: "tencent-document";
                readonly state: "unsupported";
            }, {
                readonly kind: "wecom-document";
                readonly state: "not-this-connector";
            }, {
                readonly kind: "office";
                readonly state: "unsupported";
            }, {
                readonly kind: "pdf";
                readonly state: "unsupported";
            }];
        } | {
            raw: undefined;
            current: boolean;
            state: "partial";
            reason: string;
            changes: {
                added: string[];
                changed: string[];
                removed: string[];
            } | undefined;
            freshness: "manual-observation-not-remote-atomic";
            snapshotId: string;
            revision: string;
            config: import("./sources/tencent-sheet.js").TencentSheetConfig;
            items: import("./sources/tencent-sheet.js").Item[];
            capturedAt: number;
            remoteRevision: "unknown";
            images: {
                state: "unknown";
                imageSeen: false;
            };
            trust: "external-untrusted";
            authorization: "not-granted";
        }>;
        configMutation(input: any): Promise<import("./workspace/config-mutations.js").ConfigMutationReceipt>;
        sessionDecision(input: any): Promise<{
            durable: true;
            accepted: false;
            executed: null;
            completed: null;
            approval: false;
            disposition: "closed-before-dispatch";
            code: "session_decision_id_closed";
            version: 1;
            epoch: string;
            requestId: string;
            actionId: string;
            target: import("./workspace/session-decisions.js").SessionDecisionTarget;
            callId: string;
            snapshot: import("./workspace/session-decisions.js").SessionDecisionInput["snapshot"];
            digest: string;
            seq: 1;
            at: number;
            updatedAt: number;
            state: "closed";
            bindingVerified: false;
        } | {
            durable: true;
            accepted: boolean;
            executed: boolean | null;
            completed: boolean | null;
            approval: false;
            disposition: string;
            version: 1;
            epoch: string;
            requestId: string;
            actionId: string;
            target: import("./workspace/session-actions.js").SessionTargetBinding;
            callId: string;
            snapshot: {
                asOfSeq: number;
                revision: string;
            };
            digest: string;
            answerSummary: {
                digest: string;
                questions: number;
                selections: number;
                customBytes: number;
                skipped: number;
            };
            seq: number;
            at: number;
            updatedAt: number;
            state: "recorded" | "blocked" | "dispatch_unknown" | "accepted";
            code?: string;
            controlRevision?: string;
            grantRevision?: string;
        } | {
            target: import("./workspace/session-actions.js").SessionTargetBinding;
            availability: "unavailable" | "live" | "cold";
            complete: boolean;
            asOfSeq: number;
            snapshotRevision: string;
            calls: {
                canAnswer: false;
                callId: string;
                state: "open" | "continued";
                questions: import("./workspace/session-decisions.js").SessionDecisionQuestion[];
            }[];
            canAnswer: false;
            code: string;
            approval: false;
        }>;
        localSources(input: any): Promise<import("./workspace/local-sources.js").Receipt | {
            documentOrigin: DocumentOrigin;
            draftId: string;
            trust: "external-untrusted";
            authorization: "not-granted";
            planningOnly: true;
        } | {
            roots: {
                id: string;
                name: string;
            }[];
            sources: {
                reason?: string | undefined;
                freshness: "manual-snapshot-not-live";
                state: string;
                snapshotId: string | null;
                id: string;
                rootId: string;
                relativePath: string;
                kind: import("./workspace/local-sources.js").LocalSourceKind;
                csv?: {
                    idColumn: string;
                };
                revision: string;
            }[];
            support: readonly ({
                kind: string;
                state: string;
                requires?: undefined;
                blocked?: undefined;
                reason?: undefined;
            } | {
                kind: string;
                state: string;
                requires: string;
                blocked?: undefined;
                reason?: undefined;
            } | {
                kind: string;
                state: string;
                blocked: boolean;
                requires?: undefined;
                reason?: undefined;
            } | {
                kind: string;
                state: string;
                blocked: boolean;
                reason: string;
                requires?: undefined;
            })[];
            limits: {
                fileBytes: number;
                imageBytes: number;
                totalImageBytes: number;
                images: 10;
                csvRows: 500;
                csvColumns: 100;
                sources: 100;
            };
        } | {
            kind: "image";
            bytes: Buffer<ArrayBuffer>;
            digest: string;
            mediaType: string;
            imageSeen: false;
            freshness?: undefined;
            snapshotId?: undefined;
            revision?: undefined;
            sourceId?: undefined;
            config?: undefined;
            capturedAt?: undefined;
            text?: undefined;
            items?: undefined;
            images?: undefined;
            trust?: undefined;
            authorization?: undefined;
            current?: undefined;
            changes?: undefined;
        } | {
            kind: "snapshot";
            freshness: "manual-snapshot-not-live";
            snapshotId: string;
            revision: string;
            sourceId: string;
            config: import("./workspace/local-sources.js").LocalSourceConfig;
            capturedAt: number;
            text: string;
            items: {
                draftId?: string | undefined;
                state: "claimed" | "candidate";
                text?: string | undefined;
                itemId: string;
                location: {
                    relativePath: string;
                    row?: number;
                    rowId?: string;
                };
            }[];
            images: import("./workspace/local-sources.js").Image[];
            trust: "external-untrusted";
            authorization: "not-granted";
            current: boolean;
            changes: {
                added: string[];
                changed: string[];
                removed: string[];
                imagesChanged: boolean;
            } | undefined;
            bytes?: undefined;
            digest?: undefined;
            mediaType?: undefined;
            imageSeen?: undefined;
        } | import("./workspace/config-mutations.js").ConfigMutationReceipt>;
        stageModels(input: any): Promise<import("./workspace/config-mutations.js").ConfigMutationReceipt | {
            defaultEffort?: string | undefined;
            provider: string;
            model: string;
            reasoningEfforts: {
                id: string;
                name: string;
            }[];
        } | {
            catalog: {
                id: string;
                name: string;
                models: {
                    id: string;
                    name: string;
                    reasoningEfforts?: readonly {
                        id: string;
                        name: string;
                    }[];
                }[];
            }[];
            config: import("./workspace/stage-models.js").StageModelConfig | null;
            configVersion: number;
            stages: Readonly<Record<import("./workspace/stage-models.js").Stage, import("./workspace/stage-models.js").StageResolution>>;
            existingSessionModelPolicy: "preserve";
            existingSessionOverride: "unsupported";
        }>;
        images(input: any): Promise<{
            original: boolean;
            uploadedNotSent: boolean;
            target?: import("./workspace/session-actions.js").SessionTargetBinding;
            version: 1;
            epoch: string;
            imageId: string;
            uploadId: string;
            draftId: string;
            digest: string;
            mediaType: "image/png";
            width: number;
            height: number;
            size: number;
            scopeRevision: string;
            state: "staged" | "bound" | "released";
            seq: number;
            at: number;
        } | {
            scopeRevision: string;
            items: {
                stale: boolean;
                original: boolean;
                uploadedNotSent: boolean;
                target?: import("./workspace/session-actions.js").SessionTargetBinding;
                version: 1;
                epoch: string;
                imageId: string;
                uploadId: string;
                draftId: string;
                digest: string;
                mediaType: "image/png";
                width: number;
                height: number;
                size: number;
                scopeRevision: string;
                state: "staged" | "bound" | "released";
                seq: number;
                at: number;
            }[];
            capability: {
                upload: string;
                originalUnderstanding: boolean;
                targetDelivery: boolean;
                code: string;
            };
        } | {
            bytes: NonSharedBuffer;
            mediaType: "image/png";
            digest: string;
        } | {
            imageId: string;
            seq: number;
            state: "staged" | "bound" | "released";
            bytesRetained: boolean;
            thirdPartyErasureGuaranteed: boolean;
        }>;
        documentSource(input: any): Promise<unknown>;
        documentImage(input: any): Promise<{
            bytes: Buffer<ArrayBuffer>;
            mimeType: string;
        }>;
        health(): Promise<{
            ok: boolean;
            runtime: {
                code?: string | undefined;
                state: string;
            };
            db: {
                version: number;
            };
            watchdog: {
                lastAt: number | undefined;
            };
            sessionChannel: {
                delivery: string;
                modelWakeup: boolean;
                visualVerification: string;
            };
            outbox: {
                pending: number;
            };
            sources: {
                ok: boolean;
                lastAt?: number;
                detail?: string;
                id: import("./domain/ids.js").SourceId;
                kind: "session" | "inbox" | "wecom-document" | "github" | "feishu" | "session-work";
                attended: boolean;
            }[];
        }>;
        sources(): Promise<{
            ok: boolean;
            lastAt?: number;
            detail?: string;
            id: import("./domain/ids.js").SourceId;
            kind: "session" | "inbox" | "wecom-document" | "github" | "feishu" | "session-work";
            attended: boolean;
            paused: boolean;
        }[]>;
        ownsTicketTransitions: boolean;
        stopTicket(id: string, reason: string): Promise<boolean>;
        resumeTicket(_id: string): Promise<boolean>;
        approvalDecided(id: string, approvalId: string, approved: boolean): Promise<void>;
        mandateValid(row: Row): boolean;
    };
    dispose(): Promise<void>;
};
