import type { Store } from '../store/index.js';
import type { DocumentOrigin, DocumentOriginAuthority } from './document-origin.js';
export interface LocalSourceRoot {
    id: string;
    path: string;
    name?: string;
}
export interface LocalSourcePorts {
    roots(): readonly LocalSourceRoot[];
    requireEpoch(epoch: string): void;
    signal: AbortSignal;
}
export type LocalSourceKind = 'md' | 'txt' | 'csv';
export interface LocalSourceConfig {
    id: string;
    rootId: string;
    relativePath: string;
    kind: LocalSourceKind;
    csv?: {
        idColumn: string;
    };
    revision: string;
}
interface Auth {
    epoch: string;
}
interface SourceCAS extends Auth {
    id: string;
    expectedRevision: string;
}
export interface LocalSourceConfigure extends Auth {
    id: string;
    rootId: string;
    relativePath: string;
    kind: LocalSourceKind;
    csv?: {
        idColumn: string;
    };
    expectedRevision: string | null;
}
export interface LocalSourceScan extends SourceCAS {
    expectedSnapshot: string | null;
}
export interface LocalSourceDetail extends SourceCAS {
    snapshotId: string;
    imageDigest?: string;
}
export interface LocalSourceClaim extends SourceCAS {
    snapshotId: string;
    itemId: string;
    requestId: string;
    humanReview: 'reviewed-for-draft';
}
/** Resolves an existing draft receipt into provenance only; never grants a command or execution. */
export interface LocalSourcePlanOrigin extends SourceCAS {
    snapshotId: string;
    itemId: string;
    requestId: string;
}
export interface Image {
    reference: string;
    relativePath?: string;
    digest?: string;
    mediaType?: string;
    size?: number;
    state: 'available' | 'blocked';
    imageSeen: false;
    reason?: string;
}
export interface Receipt {
    draftId: string;
    requestId: string;
    origin: {
        kind: 'local';
        sourceId: string;
        itemId: string;
        snapshotId: string;
        revision: string;
        configRevision: string;
    };
    trust: 'external-untrusted';
    authorization: 'not-granted';
    humanReview: 'reviewed-for-draft';
    text: string;
    images: Image[];
}
export declare const LOCAL_SOURCE_SUPPORT: readonly ({
    kind: string;
    state: string;
    requires?: undefined;
    blocked?: undefined;
    reason?: undefined;
} | {
    kind: string;
    state: string;
    requires: string;
    blocked?: undefined;
    reason?: undefined;
} | {
    kind: string;
    state: string;
    blocked: boolean;
    requires?: undefined;
    reason?: undefined;
} | {
    kind: string;
    state: string;
    blocked: boolean;
    reason: string;
    requires?: undefined;
})[];
/** Manual bounded local evidence. No engine, execution port, watcher, or browser-supplied root. */
export declare function createLocalSources(store: Store, ports: LocalSourcePorts): {
    authority: DocumentOriginAuthority;
    planOrigin(input: LocalSourcePlanOrigin): {
        documentOrigin: DocumentOrigin;
        draftId: string;
        trust: "external-untrusted";
        authorization: "not-granted";
        planningOnly: true;
    };
    list(input: Auth): {
        roots: {
            id: string;
            name: string;
        }[];
        sources: {
            reason?: string | undefined;
            freshness: "manual-snapshot-not-live";
            state: string;
            snapshotId: string | null;
            id: string;
            rootId: string;
            relativePath: string;
            kind: LocalSourceKind;
            csv?: {
                idColumn: string;
            };
            revision: string;
        }[];
        support: readonly ({
            kind: string;
            state: string;
            requires?: undefined;
            blocked?: undefined;
            reason?: undefined;
        } | {
            kind: string;
            state: string;
            requires: string;
            blocked?: undefined;
            reason?: undefined;
        } | {
            kind: string;
            state: string;
            blocked: boolean;
            requires?: undefined;
            reason?: undefined;
        } | {
            kind: string;
            state: string;
            blocked: boolean;
            reason: string;
            requires?: undefined;
        })[];
        limits: {
            fileBytes: number;
            imageBytes: number;
            totalImageBytes: number;
            images: 10;
            csvRows: 500;
            csvColumns: 100;
            sources: 100;
        };
    };
    configure(input: LocalSourceConfigure, onCommit?: (value: any) => void): {
        reason?: string | undefined;
        freshness: "manual-snapshot-not-live";
        state: string;
        snapshotId: string | null;
        id: string;
        rootId: string;
        relativePath: string;
        kind: LocalSourceKind;
        csv?: {
            idColumn: string;
        };
        revision: string;
    };
    remove(input: SourceCAS, onCommit?: (value: any) => void): {
        id: string;
        removed: true;
        revision: string;
    };
    scan(input: LocalSourceScan, onCommit?: (value: any) => void): {
        revision: string;
        items: {
            draftId?: string | undefined;
            state: "claimed" | "candidate";
            text?: string | undefined;
            itemId: string;
            location: {
                relativePath: string;
                row?: number;
                rowId?: string;
            };
        }[];
        images: Image[];
        snapshotId: string | null;
        configRevision: string;
        epoch?: string;
        state: "ready" | "blocked";
        reason?: string;
        changes?: {
            added: string[];
            changed: string[];
            removed: string[];
            imagesChanged: boolean;
        };
        sourceId: string;
    };
    detail(input: LocalSourceDetail): {
        kind: "image";
        bytes: Buffer<ArrayBuffer>;
        digest: string;
        mediaType: string;
        imageSeen: false;
        freshness?: undefined;
        snapshotId?: undefined;
        revision?: undefined;
        sourceId?: undefined;
        config?: undefined;
        capturedAt?: undefined;
        text?: undefined;
        items?: undefined;
        images?: undefined;
        trust?: undefined;
        authorization?: undefined;
        current?: undefined;
        changes?: undefined;
    } | {
        kind: "snapshot";
        freshness: "manual-snapshot-not-live";
        snapshotId: string;
        revision: string;
        sourceId: string;
        config: LocalSourceConfig;
        capturedAt: number;
        text: string;
        items: {
            draftId?: string | undefined;
            state: "claimed" | "candidate";
            text?: string | undefined;
            itemId: string;
            location: {
                relativePath: string;
                row?: number;
                rowId?: string;
            };
        }[];
        images: Image[];
        trust: "external-untrusted";
        authorization: "not-granted";
        current: boolean;
        changes: {
            added: string[];
            changed: string[];
            removed: string[];
            imagesChanged: boolean;
        } | undefined;
        bytes?: undefined;
        digest?: undefined;
        mediaType?: undefined;
        imageSeen?: undefined;
    };
    claim(input: LocalSourceClaim): Receipt;
};
export {};
