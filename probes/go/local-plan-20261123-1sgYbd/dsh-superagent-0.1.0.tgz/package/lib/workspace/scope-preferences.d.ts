import type { Store } from '../store/index.js';
/** Host-owned preferences in existing kv, no DDL, activation, or user-data migration.
 * Keep the legacy session exclusion key intact. Every mutation advances an ABA fence.
 */
export declare function createScopePreferences(store: Store): {
    getExcluded: () => string[];
    setExcluded: (ids: readonly string[]) => void;
    getExcludedProjects: () => string[];
    setExcludedProjects: (ids: readonly string[]) => void;
    getScopeVersion: () => number;
};
