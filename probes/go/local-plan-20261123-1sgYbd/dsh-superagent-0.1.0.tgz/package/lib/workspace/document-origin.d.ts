/** Opaque provenance is Host-resolved; document text is never a human command. */
export interface DocumentOrigin {
    readonly kind: 'wecom-document' | 'local-document';
    readonly itemKey: string;
    readonly revision: string;
    readonly evidenceDigest: string;
    readonly configVersion: string;
}
export declare function validDocumentOrigin(value: unknown): value is DocumentOrigin;
/** Synchronous fresh authority checks bracket every admission transaction/settlement. */
export interface DocumentOriginAuthority {
    validate(origin: DocumentOrigin, requestId: string): void;
    /** Participates in the caller's journal transaction; must not open another transaction. */
    reserve(origin: DocumentOrigin, requestId: string): void;
    link(origin: DocumentOrigin, requestId: string, ticketId: string): void;
    context(origin: DocumentOrigin, requestId: string): unknown;
}
