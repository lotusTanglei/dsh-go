import { type Store } from '../store/index.js';
import type { SessionTargetBinding } from './session-actions.js';
export interface ImageReference {
    imageId: string;
    digest: string;
    seq: number;
}
export interface ImagePorts {
    requireEpoch(epoch: string): void;
    scope(): Promise<{
        revision: string;
        fence(): void;
    }>;
    target(input: {
        sessionId: string;
        scopeRevision: string;
        factRevision: string;
    }): Promise<{
        binding: SessionTargetBinding;
        fence(): void;
    }>;
    /** Host capability plus exact disclosure/permission; missing is a visible block, never fallback. */
    authorize?(input: {
        epoch: string;
        reference: ImageReference;
        target: SessionTargetBinding;
        purpose: 'understand' | 'target';
    }): Promise<{
        allowed: false;
        code: string;
    } | {
        allowed: true;
        originalImage: true;
        provider: string;
        model: string;
        fence(): void;
    }>;
}
export declare function createWorkspaceImages(store: Store, root: string, ports: ImagePorts): {
    upload(input: {
        epoch: string;
        draftId: string;
        uploadId: string;
        digest: string;
        mediaType: string;
        encoded: string;
    }): Promise<{
        original: boolean;
        uploadedNotSent: boolean;
        target?: SessionTargetBinding;
        version: 1;
        epoch: string;
        imageId: string;
        uploadId: string;
        draftId: string;
        digest: string;
        mediaType: "image/png";
        width: number;
        height: number;
        size: number;
        scopeRevision: string;
        state: "staged" | "bound" | "released";
        seq: number;
        at: number;
    }>;
    list(input: {
        epoch: string;
        draftId: string;
    }): Promise<{
        scopeRevision: string;
        items: {
            stale: boolean;
            original: boolean;
            uploadedNotSent: boolean;
            target?: SessionTargetBinding;
            version: 1;
            epoch: string;
            imageId: string;
            uploadId: string;
            draftId: string;
            digest: string;
            mediaType: "image/png";
            width: number;
            height: number;
            size: number;
            scopeRevision: string;
            state: "staged" | "bound" | "released";
            seq: number;
            at: number;
        }[];
        capability: {
            upload: string;
            originalUnderstanding: boolean;
            targetDelivery: boolean;
            code: string;
        };
    }>;
    original(input: {
        epoch: string;
        reference: ImageReference;
    }): Promise<{
        bytes: NonSharedBuffer;
        mediaType: "image/png";
        digest: string;
    }>;
    bind(input: {
        epoch: string;
        reference: ImageReference;
        target: {
            sessionId: string;
            scopeRevision: string;
            factRevision: string;
        };
    }): Promise<{
        original: boolean;
        uploadedNotSent: boolean;
        target?: SessionTargetBinding;
        version: 1;
        epoch: string;
        imageId: string;
        uploadId: string;
        draftId: string;
        digest: string;
        mediaType: "image/png";
        width: number;
        height: number;
        size: number;
        scopeRevision: string;
        state: "staged" | "bound" | "released";
        seq: number;
        at: number;
    }>;
    release(input: {
        epoch: string;
        reference: ImageReference;
    }): Promise<{
        imageId: string;
        seq: number;
        state: "staged" | "bound" | "released";
        bytesRetained: boolean;
        thirdPartyErasureGuaranteed: boolean;
    }>;
    /** Host-internal byte lease; no HTTP caller may manufacture vision/authorization. */
    acquire(input: {
        epoch: string;
        reference: ImageReference;
        purpose: "understand" | "target";
    }): Promise<{
        state: "leased";
        leaseId: string;
        bytes: NonSharedBuffer;
        digest: string;
        mediaType: "image/png";
        provider: string;
        model: string;
    } | {
        state: "blocked";
        code: string;
    }>;
    /** Host acknowledgment only. Unknown external outcomes retain their lease. */
    settle(leaseId: string, outcome: "released" | "unknown"): {
        leaseId: string;
        state: string;
    };
};
