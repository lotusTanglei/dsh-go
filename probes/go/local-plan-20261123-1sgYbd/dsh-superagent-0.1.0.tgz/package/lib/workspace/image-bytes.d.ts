export declare const IMAGE_MAX_BYTES: number;
/** Narrow, decoded raster contract: 8-bit non-interlaced PNG only. Preserve every source byte.
 * Unknown formats/animated images are blocked, never relabeled or converted behind the user.
 */
export declare function inspectImageBytes(bytes: Buffer, mediaType: string): {
    width: number;
    height: number;
    mediaType: 'image/png';
    digest: string;
    size: number;
};
/** Private, pinned directory. The raw blob is never stored in SQLite or a log. */
export declare function createImageBytes(root: string): {
    read: (digest: string) => NonSharedBuffer;
    put(bytes: Buffer, mediaType: string): {
        width: number;
        height: number;
        mediaType: "image/png";
        digest: string;
        size: number;
    };
};
