import { type Store } from '../store/index.js';
export type SessionOperation = 'continue' | 'supplement' | 'steer';
export interface SessionActionInput {
    epoch: string;
    requestId: string;
    actionId: string;
    operation: SessionOperation;
    text: string;
    target: {
        sessionId: string;
        scopeRevision: string;
        factRevision: string;
    };
}
export interface SessionTargetBinding {
    sessionId: string;
    project: {
        kind: 'project' | 'unassigned';
        key: string;
    };
    scopeRevision: string;
    factRevision: string;
}
export interface SessionActionRecord {
    version: 1;
    epoch: string;
    requestId: string;
    actionId: string;
    operation: SessionOperation;
    target: SessionTargetBinding;
    digest: string;
    messageId: string;
    seq: number;
    at: number;
    updatedAt: number;
    state: 'recorded' | 'blocked' | 'dispatch_unknown' | 'accepted';
    code?: string;
    controlRevision?: string;
    grantRevision?: string;
}
export interface SessionActionClosure {
    version: 1;
    epoch: string;
    requestId: string;
    actionId: string;
    operation: SessionOperation;
    target: SessionActionInput['target'];
    digest: string;
    seq: 1;
    at: number;
    updatedAt: number;
    state: 'closed';
    bindingVerified: false;
}
export interface SessionActionEvidence {
    actionId: string;
    sessionId: string;
    digest: string;
    messageId: string;
    durable: true;
    accepted: true;
}
export interface SessionActionPorts {
    requireEpoch(epoch: string): void;
    /** Must read only current authorized facts; a returned binding is not an execution grant. */
    target(input: SessionActionInput['target']): Promise<{
        binding: SessionTargetBinding;
        fence(): void;
    }>;
    /** Host owns actor, isolation, approvals and external resource/conflict policy. No browser switches. */
    gate(input: Readonly<SessionActionInput>, binding: Readonly<SessionTargetBinding>): Promise<{
        allowed: false;
        code: string;
    } | {
        allowed: true;
        controlRevision: string;
        grantRevision: string;
        fence(): void;
    }>;
    /** No production adapter until its isolation/authentication contract is proved. */
    dispatch?(record: Readonly<SessionActionRecord>, text: string): Promise<void>;
    /** Host-only minimal receipt lookup, never transcript/goal/private content; no automatic resend. */
    evidence?(record: Readonly<SessionActionRecord>): Promise<SessionActionEvidence | undefined>;
}
export declare function validSessionAction(input: unknown): input is SessionActionInput;
export declare function sessionActionDigest(input: SessionActionInput): string;
/** Durable, non-replaying dispatch fence. Raw text stays in the caller until one dispatch;
 * it is never persisted in an audit/side_effect record or rehydrated from redacted text.
 */
export declare function createSessionActions(store: Store, ports: SessionActionPorts): {
    prepare(raw: SessionActionInput): Promise<{
        target: {
            sessionId: string;
            scopeRevision: string;
            factRevision: string;
        };
        durable: true;
        accepted: false;
        executed: null;
        completed: null;
        disposition: "closed-before-dispatch";
        code: string;
        version: 1;
        epoch: string;
        requestId: string;
        actionId: string;
        operation: SessionOperation;
        digest: string;
        seq: 1;
        at: number;
        updatedAt: number;
        state: "closed";
        bindingVerified: false;
    } | {
        target: {
            project: {
                kind: "project" | "unassigned";
                key: string;
            };
            sessionId: string;
            scopeRevision: string;
            factRevision: string;
        };
        durable: true;
        accepted: boolean;
        executed: boolean | null;
        completed: boolean | null;
        disposition: string;
        version: 1;
        epoch: string;
        requestId: string;
        actionId: string;
        operation: SessionOperation;
        digest: string;
        messageId: string;
        seq: number;
        at: number;
        updatedAt: number;
        state: "recorded" | "blocked" | "dispatch_unknown" | "accepted";
        code?: string;
        controlRevision?: string;
        grantRevision?: string;
    }>;
    close(raw: SessionActionInput): Promise<{
        target: {
            sessionId: string;
            scopeRevision: string;
            factRevision: string;
        };
        durable: true;
        accepted: false;
        executed: null;
        completed: null;
        disposition: "closed-before-dispatch";
        code: string;
        version: 1;
        epoch: string;
        requestId: string;
        actionId: string;
        operation: SessionOperation;
        digest: string;
        seq: 1;
        at: number;
        updatedAt: number;
        state: "closed";
        bindingVerified: false;
    } | {
        target: {
            project: {
                kind: "project" | "unassigned";
                key: string;
            };
            sessionId: string;
            scopeRevision: string;
            factRevision: string;
        };
        durable: true;
        accepted: boolean;
        executed: boolean | null;
        completed: boolean | null;
        disposition: string;
        version: 1;
        epoch: string;
        requestId: string;
        actionId: string;
        operation: SessionOperation;
        digest: string;
        messageId: string;
        seq: number;
        at: number;
        updatedAt: number;
        state: "recorded" | "blocked" | "dispatch_unknown" | "accepted";
        code?: string;
        controlRevision?: string;
        grantRevision?: string;
    }>;
    status(input: {
        epoch: string;
        actionId: string;
    }): Promise<{
        target: {
            sessionId: string;
            scopeRevision: string;
            factRevision: string;
        };
        durable: true;
        accepted: false;
        executed: null;
        completed: null;
        disposition: "closed-before-dispatch";
        code: string;
        version: 1;
        epoch: string;
        requestId: string;
        actionId: string;
        operation: SessionOperation;
        digest: string;
        seq: 1;
        at: number;
        updatedAt: number;
        state: "closed";
        bindingVerified: false;
    } | {
        target: {
            project: {
                kind: "project" | "unassigned";
                key: string;
            };
            sessionId: string;
            scopeRevision: string;
            factRevision: string;
        };
        durable: true;
        accepted: boolean;
        executed: boolean | null;
        completed: boolean | null;
        disposition: string;
        version: 1;
        epoch: string;
        requestId: string;
        actionId: string;
        operation: SessionOperation;
        digest: string;
        messageId: string;
        seq: number;
        at: number;
        updatedAt: number;
        state: "recorded" | "blocked" | "dispatch_unknown" | "accepted";
        code?: string;
        controlRevision?: string;
        grantRevision?: string;
    }>;
};
