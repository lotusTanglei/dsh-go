import { type Store } from '../store/index.js';
export type ConfigMutationJSON = null | boolean | number | string | ConfigMutationJSON[] | {
    [key: string]: ConfigMutationJSON;
};
export type ConfigMutationKind = 'local-configure' | 'local-remove' | 'local-scan' | 'stage-save' | 'tencent-configure' | 'tencent-remove' | 'tencent-scan';
export interface ConfigMutationInput {
    epoch: string;
    requestId: string;
    kind: ConfigMutationKind;
    payload: ConfigMutationJSON;
}
export interface ConfigMutationMetadata {
    version: 1;
    epoch: string;
    requestId: string;
    kind: ConfigMutationKind;
    digest: string;
    state: 'recorded' | 'settled' | 'rejected' | 'closed';
    at: number;
    updatedAt: number;
    code?: string;
}
export interface ConfigMutationReceipt {
    mutation: ConfigMutationMetadata;
    value?: ConfigMutationJSON;
}
export type ConfigMutationHandler = (commit: (value: ConfigMutationJSON) => void, checkpoint: () => void) => Promise<ConfigMutationJSON> | ConfigMutationJSON;
export declare function configMutationDigest(raw: ConfigMutationInput): string;
/** Caller owns safe payload/result DTOs and the core SQL transaction. No content filtering or replay. */
export declare function createConfigMutations(store: Store, ports: {
    requireEpoch(epoch: string): void;
}): {
    run(raw: ConfigMutationInput, handler: ConfigMutationHandler): Promise<ConfigMutationReceipt>;
    status(raw: {
        epoch: string;
        requestId: string;
    }): Promise<ConfigMutationReceipt>;
    close(raw: ConfigMutationInput): Promise<ConfigMutationReceipt>;
};
