import type { Store } from '../store/index.js';
export declare const STAGES: readonly ["locate", "understand", "plan", "execute", "summarize", "verify"];
export type Stage = typeof STAGES[number];
export interface StageModelSelection {
    readonly provider: string;
    readonly model: string;
    readonly reasoningEffort?: string;
}
export type StageModelChoice = {
    readonly mode: 'inherit';
} | {
    readonly mode: 'override';
    readonly selection: StageModelSelection;
};
export interface StageModelConfig {
    readonly revision: number;
    readonly default: StageModelSelection;
    readonly stages: Readonly<Record<Stage, StageModelChoice>>;
}
export interface StageRequirements {
    readonly vision?: boolean;
    readonly tools?: boolean;
    readonly structured?: boolean;
    readonly minContextTokens?: number;
}
export type CapabilityState = 'supported' | 'unsupported' | 'unknown';
/** The installed rc.5 shape; toolUpdate is deliberately NOT a tool-support flag. */
export interface StageModelInfo {
    readonly provider: string;
    readonly id: string;
    readonly name: string;
    readonly inputModalities?: readonly string[];
    readonly context?: {
        readonly contextWindow: number;
    };
    readonly defaultMaxTokens?: number;
    readonly reasoning?: {
        readonly efforts: readonly {
            readonly id: string;
            readonly name: string;
        }[];
        readonly defaultEffort?: string;
    };
}
export interface StageCatalogPort {
    listProviders(): readonly {
        readonly id: string;
        readonly name: string;
    }[];
    listModels(provider: string): Promise<readonly {
        readonly provider: string;
        readonly id: string;
        readonly name: string;
    }[]>;
    resolveModelInfo(provider: string, model: string, signal?: AbortSignal): Promise<StageModelInfo>;
}
export interface StageCapabilityProof {
    readonly vision: CapabilityState;
    readonly tools: CapabilityState;
    readonly structured: CapabilityState;
    readonly contextWindow: number | null;
    /** Captured capability/default facts, not authorization for the eventual prepared controls. */
    readonly inputModalities: readonly string[] | null;
    readonly defaultMaxTokens: number | null;
    readonly reasoningEfforts: readonly string[];
    readonly defaultEffort: string | null;
    readonly modelInfoEvidence: 'dsh.resolveModelInfo';
    readonly hostEvidence: readonly string[];
}
export interface StageRouteSnapshot extends StageModelSelection {
    readonly stage: Stage;
    readonly configVersion: number;
    readonly mode: 'inherit' | 'override';
    readonly configured: StageModelSelection;
    readonly requirements: StageRequirements;
    readonly capabilityProof: StageCapabilityProof;
}
export interface StageBlocked {
    readonly state: 'blocked';
    readonly code: string;
    readonly configVersion: number;
}
export type StageResolution = {
    readonly state: 'ready';
    readonly snapshot: StageRouteSnapshot;
} & StageModelSelection & {
    readonly configVersion: number;
    readonly capabilityProof: StageCapabilityProof;
} | StageBlocked;
export interface StageModelSettings {
    readonly config: StageModelConfig | null;
    readonly configVersion: number;
    readonly stages: Readonly<Record<Stage, StageResolution>>;
    readonly existingSessionModelPolicy: 'preserve';
    readonly existingSessionOverride: 'unsupported';
}
export type StageJson = null | boolean | number | string | readonly StageJson[] | {
    readonly [key: string]: StageJson;
};
export interface StageRunContext {
    readonly requestId: string;
    readonly inputRevision: string;
    readonly scopeRevision: string;
    readonly sourceRevisions: readonly {
        readonly sourceId: string;
        readonly revision: string;
    }[];
    readonly dataCategories: readonly string[];
}
export interface StageBoundContext extends StageRunContext {
    readonly inputDigest: string;
}
export interface StageFence {
    fence(): void;
}
export type StageAuthorization = {
    readonly allowed: true;
    readonly authorizationRevision: string;
    fence(): void;
} | {
    readonly allowed: false;
    readonly code: string;
};
export interface StageCallConfig extends StageModelSelection {
    readonly maxTokens?: number;
    readonly temperature?: number;
    readonly stop?: readonly string[];
}
export interface StageCallRequest {
    readonly snapshot: StageRouteSnapshot;
    readonly input: StageJson;
    readonly context: StageBoundContext;
    readonly authorizationRevision: string;
    readonly signal?: AbortSignal;
    /** Must be called at every asynchronous boundary inside the Host adapter and immediately before dispatch. */
    checkpoint(): void;
}
export interface StageCallReceipt {
    readonly callId: string;
    readonly config: StageCallConfig;
    readonly configVersion: number;
    readonly inputDigest: string;
    readonly inputRevision: string;
    readonly scopeRevision: string;
    readonly sourceRevisions: StageRunContext['sourceRevisions'];
    readonly authorizationRevision: string;
}
export interface StageCallOutcome {
    readonly output: StageJson;
    readonly receipt: StageCallReceipt;
}
export interface StageCallPort {
    run(request: StageCallRequest): Promise<StageCallOutcome>;
}
export interface StageModelPorts {
    readonly catalog?: StageCatalogPort;
    /** Extra Host-owned attestation, NOT a fabricated DSH model-info API. Missing evidence stays unknown. */
    readonly capabilities?: (selection: StageModelSelection, info: StageModelInfo) => Promise<{
        readonly tools?: boolean;
        readonly structured?: boolean;
        readonly evidenceRefs: readonly string[];
        fence(): void;
    }>;
    /** Authenticated Host checks current input, scope, sources and categories, never browser/model assertions. */
    readonly bind?: (context: StageBoundContext, signal?: AbortSignal) => Promise<StageFence>;
    readonly authorize?: (snapshot: StageRouteSnapshot, context: StageBoundContext, signal?: AbortSignal) => Promise<StageAuthorization>;
    readonly call?: StageCallPort;
}
export type StageRunResult = {
    readonly state: 'completed';
    readonly snapshot: StageRouteSnapshot;
    readonly output: StageJson;
    readonly receipt: StageCallReceipt;
} | StageBlocked;
export declare function parseStageModelConfig(value: unknown): StageModelConfig;
/** Host only: the browser may submit strict config, never inject these ports. */
export declare function createStageModels(store: Store, ports: StageModelPorts): {
    settings(): Promise<StageModelSettings>;
    save(input: unknown, checkpoint?: () => void, onCommit?: (value: StageModelSettings) => void): Promise<StageModelSettings>;
    resolve(stage: Stage, rawRequirements?: StageRequirements): Promise<StageResolution>;
    runStage(stage: Stage, rawRequirements: StageRequirements, request: {
        readonly input: StageJson;
        readonly context: StageRunContext;
        readonly signal?: AbortSignal;
    }): Promise<StageRunResult>;
};
/** Structural rc.5 prepareCall contract. No dependency installation or Agent selection required. */
export interface DshStageLlm {
    prepareCall(config: StageCallConfig, signal: AbortSignal | undefined, configure: (controls: Omit<StageCallConfig, 'provider' | 'model'>, info: StageModelInfo) => Omit<StageCallConfig, 'provider' | 'model'>): Promise<{
        readonly config: StageCallConfig;
        readonly inputModalities?: readonly string[];
        readonly context?: {
            readonly contextWindow: number;
        };
        stream(options: Readonly<Record<string, unknown>>): AsyncIterable<unknown>;
    }>;
}
export interface DshStageCallHooks {
    /** Persist exact model-visible input, prepared config and version before returning. Host owns privacy/lifecycle. */
    record(request: StageCallRequest, config: StageCallConfig): Promise<{
        readonly callId: string;
        readonly options: Readonly<Record<string, unknown>>;
    }>;
    /** Consume one attempt (no retry); terminal errors must reject, not produce successful output. */
    consume(chunks: AsyncIterable<unknown>, request: StageCallRequest): Promise<StageJson>;
}
/**
 * One captured adapter generation with local checkpointed iteration, not an atomic authorization permit.
 * rc.5 llm/stream middleware may await after our last checkpoint and before provider dispatch.
 * Production must not inject this port without a Host-owned atomic permit at final provider I/O.
 * Prepared defaults (including maxTokens) are recorded in the receipt, not claimed as full-controls authorization.
 */
export declare function createDshStageCallPort(llm: DshStageLlm, hooks: DshStageCallHooks): StageCallPort;
