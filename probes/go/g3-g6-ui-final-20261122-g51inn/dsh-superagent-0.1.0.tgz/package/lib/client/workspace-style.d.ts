/** Theme-token surfaces, one task-first layout. No body mount or global reset. */
export declare function workspaceStyles(): string;
