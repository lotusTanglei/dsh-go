/** Browser factory is serialized by build-client; React and slots stay host-owned. */
import { createWorkspacePage } from './workspace.js';
import { workspaceStyles } from './workspace-style.js';
import { deriveDeskState } from './desk-model.js';
import { createGoSettings } from './go-settings.js';
import { createGoDecisions } from './go-decisions.js';
import { createGoTencent } from './go-tencent.js';
export declare function createClientPlugin(React: any, dictionaries: Record<string, Record<string, unknown>>, channelDefinitions: readonly unknown[], workspaceFactory?: typeof createWorkspacePage, styleFactory?: typeof workspaceStyles, deskFactory?: typeof deriveDeskState, settingsFactory?: typeof createGoSettings, decisionsFactory?: typeof createGoDecisions, tencentFactory?: typeof createGoTencent): {
    inject: string[];
    apply(ctx: any): void;
};
