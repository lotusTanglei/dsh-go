/** Serialized into the client factory: no imports or module-scope runtime dependencies. */
export declare function createGoSettings(React: any, request: (path: string, body: any, signal?: AbortSignal) => Promise<any>, t: any): {
    LocalSources: (props: {
        epoch: string;
        located?: any;
        active?: boolean;
    }) => any;
    StageModels: (props: {
        epoch: string;
        active?: boolean;
    }) => any;
};
