import { type Store } from '../store/index.js';
import type { SessionTargetBinding } from './session-actions.js';
export interface SessionDecisionTarget {
    sessionId: string;
    scopeRevision: string;
    factRevision: string;
}
export interface SessionDecisionQuestion {
    id: string;
    question: string;
    detail?: string;
    header?: string;
    options?: {
        label: string;
        description?: string;
    }[];
    multiSelect?: boolean;
}
export interface SessionDecisionCall {
    callId: string;
    state: 'open' | 'continued';
    questions: SessionDecisionQuestion[];
}
export interface SessionDecisionProjection {
    availability: 'live' | 'cold' | 'unavailable';
    complete: boolean;
    asOfSeq: number;
    active: SessionDecisionCall[];
}
export interface SessionDecisionSnapshot extends SessionDecisionProjection {
    snapshotRevision: string;
    fence(): void;
}
export interface SessionDecisionAnswer {
    id: string;
    selected: string[];
    custom?: string;
    skip?: true;
}
export interface SessionDecisionInput {
    epoch: string;
    requestId: string;
    actionId: string;
    target: SessionDecisionTarget;
    callId: string;
    snapshot: {
        asOfSeq: number;
        revision: string;
    };
    answers: SessionDecisionAnswer[];
}
export interface SessionDecisionRecord {
    version: 1;
    epoch: string;
    requestId: string;
    actionId: string;
    target: SessionTargetBinding;
    callId: string;
    snapshot: {
        asOfSeq: number;
        revision: string;
    };
    digest: string;
    answerSummary: {
        digest: string;
        questions: number;
        selections: number;
        customBytes: number;
        skipped: number;
    };
    seq: number;
    at: number;
    updatedAt: number;
    state: 'recorded' | 'blocked' | 'dispatch_unknown' | 'accepted';
    code?: string;
    controlRevision?: string;
    grantRevision?: string;
}
export interface SessionDecisionEvidence {
    actionId: string;
    sessionId: string;
    callId: string;
    snapshotRevision: string;
    digest: string;
    durable: true;
    accepted: true;
}
export interface SessionDecisionPorts {
    requireEpoch(epoch: string): void;
    target(input: SessionDecisionTarget): Promise<{
        binding: SessionTargetBinding;
        fence(): void;
    }>;
    /** Host-only bounded exact projection. No transcript or inferred summary. */
    questions(target: Readonly<SessionTargetBinding>): Promise<SessionDecisionSnapshot>;
    gate(input: Readonly<SessionDecisionInput>, target: Readonly<SessionTargetBinding>): Promise<{
        allowed: false;
        code: string;
    } | {
        allowed: true;
        controlRevision: string;
        grantRevision: string;
        fence(): void;
    }>;
    /** Synthetic adapters only until real isolation, atomic revision and durable receipt contracts are proved. */
    dispatch?(record: Readonly<SessionDecisionRecord>, answer: Readonly<{
        answers: readonly Omit<SessionDecisionAnswer, 'skip'>[];
    }>): Promise<void>;
    evidence?(record: Readonly<SessionDecisionRecord>): Promise<SessionDecisionEvidence | undefined>;
}
export declare function validSessionDecision(v: unknown): v is SessionDecisionInput;
export declare function sessionDecisionDigest(v: SessionDecisionInput): string;
export declare function sessionDecisionSnapshotDigest(binding: SessionTargetBinding, projection: SessionDecisionProjection): string;
/** Exact-question business answers. No direct Agent calls, no raw-body persistence and no replay. */
export declare function createSessionDecisions(store: Store, ports: SessionDecisionPorts): {
    list(raw: {
        epoch: string;
        target: SessionDecisionTarget;
    }): Promise<{
        target: SessionTargetBinding;
        availability: "unavailable" | "live" | "cold";
        complete: boolean;
        asOfSeq: number;
        snapshotRevision: string;
        calls: {
            canAnswer: false;
            callId: string;
            state: "open" | "continued";
            questions: SessionDecisionQuestion[];
        }[];
        canAnswer: false;
        code: string;
        approval: false;
    }>;
    prepare(raw: SessionDecisionInput): Promise<{
        durable: true;
        accepted: boolean;
        executed: boolean | null;
        completed: boolean | null;
        approval: false;
        disposition: string;
        version: 1;
        epoch: string;
        requestId: string;
        actionId: string;
        target: SessionTargetBinding;
        callId: string;
        snapshot: {
            asOfSeq: number;
            revision: string;
        };
        digest: string;
        answerSummary: {
            digest: string;
            questions: number;
            selections: number;
            customBytes: number;
            skipped: number;
        };
        seq: number;
        at: number;
        updatedAt: number;
        state: "recorded" | "blocked" | "dispatch_unknown" | "accepted";
        code?: string;
        controlRevision?: string;
        grantRevision?: string;
    }>;
    status(raw: {
        epoch: string;
        actionId: string;
    }): Promise<{
        durable: true;
        accepted: boolean;
        executed: boolean | null;
        completed: boolean | null;
        approval: false;
        disposition: string;
        version: 1;
        epoch: string;
        requestId: string;
        actionId: string;
        target: SessionTargetBinding;
        callId: string;
        snapshot: {
            asOfSeq: number;
            revision: string;
        };
        digest: string;
        answerSummary: {
            digest: string;
            questions: number;
            selections: number;
            customBytes: number;
            skipped: number;
        };
        seq: number;
        at: number;
        updatedAt: number;
        state: "recorded" | "blocked" | "dispatch_unknown" | "accepted";
        code?: string;
        controlRevision?: string;
        grantRevision?: string;
    }>;
};
