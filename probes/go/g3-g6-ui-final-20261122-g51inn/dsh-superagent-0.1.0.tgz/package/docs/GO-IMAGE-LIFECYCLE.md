# G3 原图链与生命周期：实施合同

## 用户路径

独立图片草稿（无须先选项目）上传/粘贴 → 本地与Host原图预览 → 核对定位目标 → 绑定目标与范围revision → 经能力/外发授权后才理解或提供给受管目标。当前生产执行闸继续关闭，原图理解/目标投递缺实际能力时显示阻断，不去图继续、不用OCR/占位充当看图。

## 最窄数据合同（现有kv，无DDL/迁移）

- 原图上传：`epoch / draftId / uploadId / digest / mediaType / encoded`，UUID稳定ID，同uploadId不同字节/上下文409。当前只接受有CRC/解压后行检查、有限维度/像素/字节的8bit非交错PNG（灰度/RGB/灰度alpha/RGBA）；JPEG、调色板PNG、交错PNG、动画等尚不支持，明确阻断，不转换或裁剪需求。原字节原样保存，digest独立于预览/OCR。字节不进普通日志、错误或审计。
- Host附件：opaque `imageId`、digest、mime、尺寸、大小、draftId、epoch、seq、状态；独立私有证据目录内容寻址保存原始字节。浏览器不选择存储路径/URL，读取只能引用Host附件ID+digest+revision。
- staged上传不等于发送。`bind` 显式指定当前已验证target、scope/fact及附件seq，Host重新核验；定位不是图像访问许可。绑定后读取/使用每次重验授权与范围，排除立即阻止后续读取；恢复不复活旧绑定。
- 当前 Host-only `lease` 绑定附件/seq/digest、用途、目标和范围；进行中引用不能 release/rebind，未知外发结果保持引用，不因取消就假设没发送。**动作/调用 ID 与真实目标接收回执的绑定尚未实现**，不能据此启用生产外发。release仅撤回本地草稿/新访问；字节仍保留且没有后台 GC、备份删除或自动到期承诺，不保证第三方追溯删除。
- 生产原图理解与目标可访问要求严格原图能力、路由披露和Host授权；当前不注入真实外发端口。合成测试必须比较目标收到的字节/digest，不能以preview img loaded或description代替模型实际看图。

## 信任与验收

图片/OCR/文档里的指令都是证据，不构成授权。任何模型、浏览器、文件文本均不能伪造trusted context。HTTP owner/Origin/epoch闸保留。原URL真实点击、图片放大、粘贴/键盘/焦点/IME与窄屏另验；无浏览器不报告通过。
