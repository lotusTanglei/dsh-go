import type { Config } from './config.js';
import type { Store, Row } from './store/index.js';
import { SourceRegistry } from './sources/registry.js';
import type { WorkerGuardSnapshot, RoleGuardRuntime } from './tools/runtime.js';
import type { WecomToolsPort } from './sources/wecom-connector.js';
import type { Spawner } from './sessions/worker.js';
/** Narrow Host adapter; DSH's live APIs remain at this boundary. */
export interface RuntimeContext {
    readonly agents: {
        get(id: string): any;
        create(input: any): Promise<any>;
        resume?(input: any): Promise<any>;
    };
    readonly tools?: WecomToolsPort;
    readonly agentPresets: {
        mount(ctx: any, id: string): Promise<unknown>;
        composedPreset(ctx: any): string | undefined;
    };
    readonly subagents: {
        startActivation(input: any): Promise<any>;
        interrupt?(id: string, cause: any): unknown;
    };
    readonly sessionQuery: {
        readSession(id: string): Promise<any>;
        listSessions?(signal?: AbortSignal): Promise<readonly any[]>;
        inspectSession?<T>(id: string, read: (session: any) => T, signal?: AbortSignal): Promise<T>;
    };
    readonly sessionProjections?: {
        snapshot(session: any, keys: readonly string[]): {
            asOfSeq: number;
            values: Record<string, unknown>;
        };
    };
    readonly remoteAccess?: {
        allows(resource: {
            kind: 'session';
            id: string;
        }): boolean;
    };
    readonly get?: (name: string) => any;
    readonly sessions?: {
        flush(session: any): Promise<boolean>;
    };
    readonly agentDefaultModel?: {
        currentSelection(): any;
    };
    readonly llm?: {
        resolveModelInfo(provider: string, model: string): Promise<any>;
    };
    readonly effect: (factory: () => (() => void | Promise<void>)) => unknown;
    readonly on: (event: string, callback: (...args: any[]) => any) => (() => void);
}
/** Every tool execution obtains a fresh trusted DB snapshot, not model-supplied ids. */
export declare function readWorkerSnapshot(store: Store, sessionId: string): WorkerGuardSnapshot | undefined;
/** Synthetic tests may inject a fake Spawner; production never obtains an execution bypass from Config or HTTP. */
export interface RuntimeTestAdapter {
    readonly spawner: Spawner;
    readonly legacyInput?: boolean;
}
export declare function createRuntime(ctx: RuntimeContext, store: Store, config: Config, roleGuard?: RoleGuardRuntime, testAdapter?: RuntimeTestAdapter): {
    ready: Promise<void>;
    engine: {
        ingest(trigger: import("./index.js").Trigger, scoped?: {
            targetTicketId: import("./domain/ids.js").TicketId;
        }): import("./engine/intake.js").IntakeResult;
        ackDelivery(triggerId: import("./domain/ids.js").TriggerId, assignmentId: import("./domain/ids.js").AssignmentId): boolean;
        evaluate(threadKey: import("./domain/ids.js").ThreadKey): Promise<import("./engine/eval.js").EvalResult | undefined>;
        enqueue(message: import("./engine/outbox.js").OutboxMessage): import("./index.js").Outbound;
        drainOutbox(): Promise<import("./engine/outbox.js").OutboxRunResult>;
        pause(): import("./engine/pause.js").PauseResult;
        resume(): import("./engine/pause.js").PauseResult;
        paused(): boolean;
        expireEval(id: import("./domain/ids.js").EvalId): import("./index.js").Eval | undefined;
        recover(): Promise<import("./engine/recovery.js").RecoveryReport>;
    };
    sources: SourceRegistry;
    startAssignment: (id: string) => Promise<{
        ok: boolean;
        code: string;
        assignmentId?: undefined;
    } | {
        ok: boolean;
        code: string;
        assignmentId: import("./domain/ids.js").AssignmentId;
    }>;
    stopTicket: (id: string, reason: string, by?: "human" | "watchdog") => Promise<boolean>;
    /** Same maintenance path as the timer, with no model wake or synthetic metrics. */
    tick(): Promise<void>;
    diagnostics(): {
        mainSessionId: string | undefined;
        triggers: {
            id: string;
            externalId: string;
            threadKey: string;
        }[];
        tickets: {
            id: string;
            state: string;
            outcome: unknown;
        }[];
        assignments: {
            id: string;
            ticketId: string;
            sessionId: string;
            state: string;
            report: unknown;
        }[];
        audit: {
            at: unknown;
            action: unknown;
            detail: unknown;
        }[];
        liveAgents: number;
    };
    invoke(name: string, args: any, exec: any): Promise<{
        ok: boolean;
        code: string;
        assignmentId: import("./domain/ids.js").AssignmentId;
    } | {
        ok: boolean;
        code: string;
        evidence: unknown;
        items?: undefined;
        ticket?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: any;
        evidence?: undefined;
        items?: undefined;
        ticket?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        items: {
            id: unknown;
            state: unknown;
            title: unknown;
        }[];
        evidence?: undefined;
        ticket?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        ticket: {
            id: unknown;
            title: unknown;
            state: unknown;
        };
        evidence?: undefined;
        items?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        plan: import("./workspace/admission.js").AdmissionPlanDTO;
        evidence?: undefined;
        items?: undefined;
        ticket?: undefined;
        ticketId?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        ticketId: import("./domain/ids.js").TicketId;
        evidence?: undefined;
        items?: undefined;
        ticket?: undefined;
        plan?: undefined;
        errors?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        errors: readonly string[];
        evidence?: undefined;
        items?: undefined;
        ticket?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        approvalId?: undefined;
    } | {
        ok: boolean;
        code: string;
        approvalId: `${string}-${string}-${string}-${string}-${string}`;
        evidence?: undefined;
        items?: undefined;
        ticket?: undefined;
        plan?: undefined;
        ticketId?: undefined;
        errors?: undefined;
    }>;
    panelPorts: {
        workspace(input?: any): Promise<{
            pendingApprovals: number;
            admissionsNext?: string | undefined;
            admissions: import("./workspace/admission.js").AdmissionPlanDTO[];
            admissionsTotal: number;
            pendingPlans: number;
            sessionWork?: import("./sources/session-work.js").SessionWorkList | undefined;
            epoch: string;
            archiveEpochs: {
                epoch: string;
                createdAt: number;
            }[];
            state: string;
            model: {
                code?: string | undefined;
                available: boolean;
            };
            serverTime: number;
            capabilities: {
                conversation: boolean;
                send: boolean;
                workerExecution: boolean;
                executionReason: string;
            };
            documentSources: {
                id: string;
                sheet: string;
                range: string;
            }[];
            briefing: import("./workspace/briefing.js").WorkspaceBriefingDTO;
        }>;
        conversation(input: any): Promise<import("./workspace/conversation.js").ConversationPage>;
        command(input: any): Promise<{
            code?: string | undefined;
            ticketId?: string | undefined;
            requestId: string;
            messageId: string;
            epoch: string;
            stage: "unknown" | "received" | "queued" | "claimed" | "admitted" | "processing" | "published" | "canceled" | "rejected";
            accepted: boolean;
            seq: number;
            at: number;
            updatedAt: number;
        }>;
        cancelCommand(input: any): Promise<{
            code?: string | undefined;
            ticketId?: string | undefined;
            requestId: string;
            messageId: string;
            epoch: string;
            stage: "unknown" | "received" | "queued" | "claimed" | "admitted" | "processing" | "published" | "canceled" | "rejected";
            accepted: boolean;
            seq: number;
            at: number;
            updatedAt: number;
        }>;
        commandStatus(input: any): Promise<{
            code?: string | undefined;
            ticketId?: string | undefined;
            requestId: string;
            messageId: string;
            epoch: string;
            stage: "unknown" | "received" | "queued" | "claimed" | "admitted" | "processing" | "published" | "canceled" | "rejected";
            accepted: boolean;
            seq: number;
            at: number;
            updatedAt: number;
        }>;
        reviseAdmission(input: any): Promise<import("./workspace/admission.js").AdmissionPlanDTO>;
        admission(input: any): Promise<import("./workspace/admission.js").AdmissionPlanDTO>;
        sessionWork(input: {
            action: "list" | "set-included";
            epoch: string;
            view?: "included" | "excluded";
            cursor?: string;
            limit?: number;
            sessionId?: string;
            included?: boolean;
            revision?: string;
        }): Promise<import("./sources/session-work.js").SessionWorkList | {
            sessionId: string;
            included: boolean;
            revision: string;
        }>;
        documentSource(input: any): Promise<unknown>;
        documentImage(input: any): Promise<{
            bytes: Buffer<ArrayBuffer>;
            mimeType: string;
        }>;
        health(): Promise<{
            ok: boolean;
            runtime: {
                code?: string | undefined;
                state: string;
            };
            db: {
                version: number;
            };
            watchdog: {
                lastAt: number | undefined;
            };
            sessionChannel: {
                delivery: string;
                modelWakeup: boolean;
                visualVerification: string;
            };
            outbox: {
                pending: number;
            };
            sources: {
                ok: boolean;
                lastAt?: number;
                detail?: string;
                id: import("./domain/ids.js").SourceId;
                kind: "session" | "inbox" | "wecom-document" | "github" | "feishu" | "session-work";
                attended: boolean;
            }[];
        }>;
        sources(): Promise<{
            ok: boolean;
            lastAt?: number;
            detail?: string;
            id: import("./domain/ids.js").SourceId;
            kind: "session" | "inbox" | "wecom-document" | "github" | "feishu" | "session-work";
            attended: boolean;
            paused: boolean;
        }[]>;
        ownsTicketTransitions: boolean;
        stopTicket(id: string, reason: string): Promise<boolean>;
        resumeTicket(_id: string): Promise<boolean>;
        approvalDecided(id: string, approvalId: string, approved: boolean): Promise<void>;
        mandateValid(row: Row): boolean;
    };
    dispose(): Promise<void>;
};
