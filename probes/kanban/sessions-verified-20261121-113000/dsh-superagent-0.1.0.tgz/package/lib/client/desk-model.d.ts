/** Pure DTO projection; kept self-contained for Function#toString serialization. */
export declare function deriveDeskState(workspace: any, now: number, stale?: boolean): {
    ready: boolean;
    idle: boolean;
    actionTotal: number | null;
    actions: any[];
    recordTotal: number | null;
    records: any[];
    moreActions: boolean;
    moreRecords: boolean;
};
