import { deriveDeskState } from './desk-model.js';
/** Serialized by the client builder. Every runtime helper is local or explicitly supplied. */
export declare function createWorkspacePage(React: any, request: (path: string, body?: any, signal?: any) => Promise<any>, t: any, css: string, deskState?: typeof deriveDeskState): () => any;
