import type { Source, ThreadContext } from './types.js';
export interface SessionWorkPorts {
    listSessions(signal: AbortSignal): Promise<readonly any[]>;
    read(sessionId: string, signal: AbortSignal): Promise<{
        asOfSeq: number;
        values: Record<string, unknown>;
    }>;
    agent(sessionId: string): any;
    ownedSessionIds(): readonly string[];
    canAccess(sessionId: string): boolean;
    getExcluded(): readonly string[];
    setExcluded(ids: readonly string[]): void;
    signal: AbortSignal;
}
export interface SessionWorkItem {
    sessionId: string;
    title: string;
    objective?: string;
    runtime: 'running' | 'idle' | 'unavailable' | 'unknown';
    goalPhase?: string;
    progress?: string;
    nextAction?: string;
    blocker?: string;
    decision?: string;
    observedAt: number;
    evidence: 'structured' | 'missing' | 'unavailable';
    excluded: boolean;
}
export interface SessionWorkListInput {
    view?: 'included' | 'excluded';
    cursor?: string;
    limit?: number;
}
export interface SessionWorkList {
    state: 'ready' | 'partial' | 'unavailable';
    sampledAt: number;
    scope: 'current-host';
    defaultIncluded: true;
    total: number | null;
    excludedTotal: number | null;
    internalTotal: number | null;
    items: SessionWorkItem[];
    hasMore: boolean;
    next?: string;
    revision?: string;
    error?: 'session_work_unavailable' | 'session_work_partial';
}
/** Manual, read-only current-host projection. No subscriptions, prompts, triggers, or actions. */
export declare class SessionWorkSource implements Source {
    private readonly ports;
    readonly id: import("../domain/ids.js").SourceId;
    readonly kind: "session-work";
    readonly attended = false;
    private active;
    private localAbort;
    private generation;
    private roster?;
    private rosterFlight?;
    private readonly pending;
    private readonly reads;
    private readonly itemFlights;
    private readonly items;
    private readonly labels;
    constructor(ports: SessionWorkPorts);
    start(): Promise<void>;
    stop(): Promise<void>;
    health(): Promise<{
        ok: boolean;
        lastAt: number | undefined;
    }>;
    verify(_input: unknown): Promise<boolean>;
    normalize(_input: unknown): Promise<[]>;
    readThread(key: Parameters<Source['readThread']>[0]): Promise<ThreadContext>;
    reply(..._args: Parameters<Source['reply']>): Promise<void>;
    summary(): Promise<SessionWorkList>;
    list(input?: SessionWorkListInput): Promise<SessionWorkList>;
    setIncluded(sessionId: string, included: boolean, input: {
        revision: string;
    }): Promise<{
        sessionId: string;
        included: boolean;
        revision: string;
    }>;
    private available;
    private access;
    private runtime;
    private signal;
    private track;
    private invalidate;
    private makeRosterFromMembership;
    private getRoster;
    private page;
    private empty;
    private project;
    private readProjection;
}
