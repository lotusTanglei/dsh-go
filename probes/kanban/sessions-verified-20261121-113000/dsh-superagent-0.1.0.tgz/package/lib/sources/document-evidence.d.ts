/** Restricted content-addressed local evidence. Not a document catalog or execution path. */
export declare function createDocumentEvidence(root: string): {
    put(value: unknown): string;
    read(digest: string): any;
};
