/** Actual installed ToolsService batch contract; guards and MCP ownership stay in DSH. */
export interface WecomToolsPort {
    execute(input: {
        calls: readonly {
            type: 'tool-call';
            id: string;
            name: string;
            arguments: string;
        }[];
        signal: AbortSignal;
    }): Promise<{
        results: readonly {
            result: {
                isError?: boolean;
                value?: unknown;
            };
        }[];
    }>;
}
export declare function createWecomConnector(tools: WecomToolsPort | undefined, signal: AbortSignal): {
    read(config: {
        doc: string;
        sheet: string;
        range: string;
    }): Promise<unknown>;
};
