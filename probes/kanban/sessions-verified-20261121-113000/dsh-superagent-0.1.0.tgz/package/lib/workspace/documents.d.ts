import type { Config } from '../config.js';
import type { Store } from '../store/index.js';
import { type WecomToolsPort } from '../sources/wecom-connector.js';
import type { SourceRegistry } from '../sources/registry.js';
import { type DocumentOriginAuthority } from './document-origin.js';
/** Manual Source intake and provenance. Never grants a Mandate or edits a linked Ticket. */
export declare function createWorkspaceDocuments(store: Store, config: Config, ports: {
    tools?: WecomToolsPort;
    signal: AbortSignal;
    registry: SourceRegistry;
    ingest(trigger: any): unknown;
    reply(body: string, idem: string): Promise<void>;
}): {
    authority: DocumentOriginAuthority;
    start(): Promise<void>;
    scan(sourceId: string): Promise<unknown>;
    list(cursor?: string): {
        items: {
            ticketId?: unknown;
            documentOrigin: {
                kind: string;
                itemKey: string;
                revision: string;
                evidenceDigest: string;
                configVersion: string;
            };
            state: string;
            version: 1;
            sourceId: string;
            itemKey: string;
            revision: string;
            evidenceDigest: string;
            configVersion: string;
            eligible: boolean;
            reviewable?: boolean;
            review?: {
                evidenceDigest: string;
                revision: string;
                configVersion: string;
                epoch: string;
                at: number;
                decision: "reviewed-not-struck";
            };
            at: number;
            title: string;
            warnings: readonly string[];
            duplicates?: readonly {
                row: number;
                evidenceDigest: string;
            }[];
        }[];
        cursor?: string | undefined;
        sources: {
            id: string;
            sheet: string;
            range: string;
        }[];
        total: number;
        hasMore: boolean;
    };
    review(itemKey: string, revision: string, digest: string, epoch: string): {
        documentOrigin: {
            kind: string;
            itemKey: string;
            revision: string;
            evidenceDigest: string;
            configVersion: string;
        };
        eligible: boolean;
        reviewable: boolean;
        state: string;
    };
    detail(itemKey: string, revision: string): {
        documentOrigin: {
            kind: string;
            itemKey: string;
            revision: string;
            evidenceDigest: string;
            configVersion: string;
        };
        title: string;
        text: string;
        at: number;
        warnings: readonly string[];
        eligible: boolean;
        reviewable: boolean;
        documentLink: string;
        location: {
            sourceId: string;
            sheet: string;
            row: number;
            range: string;
        };
        cells: {
            column: string;
            text: string;
            strike: import("../sources/wecom-document.js").WecomDocumentStrike;
            runs: unknown;
        }[];
        screenshots: {
            cell: string;
            digest: string;
            mediaType: string;
        }[];
    };
    image(itemKey: string, revision: string, digest: string): {
        bytes: Buffer<ArrayBuffer>;
        mimeType: string;
    };
};
