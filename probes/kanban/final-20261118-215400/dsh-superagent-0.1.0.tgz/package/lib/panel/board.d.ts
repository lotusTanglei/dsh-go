import type { Store, Row } from '../store/index.js';
export declare const BOARD_COLUMNS: readonly ["pending", "running", "waiting", "ended"];
export type BoardColumn = typeof BOARD_COLUMNS[number];
export declare function boardColumn(state: unknown): BoardColumn;
export declare function approvalFingerprint(row: Row): string;
export declare function boardTicket(store: Store, row: Row): {
    allowed: {
        input: boolean;
        stop: boolean;
        resume: boolean;
    };
    disabledReason: string | undefined;
    anomaly?: string | undefined;
    id: unknown;
    title: unknown;
    state: unknown;
    column: "running" | "ended" | "waiting" | "pending";
    outcome: unknown;
    createdAt: unknown;
    updatedAt: unknown;
    pendingApprovals: number;
    attention: unknown;
    progress: any;
    lastProgressAt: unknown;
    budget: {
        steps: {} | null;
        usage: {} | null;
    };
    acceptance: {
        passed: any;
        total: any;
    };
};
export declare function readBoard(store: Store, input: {
    column?: BoardColumn;
    cursor?: string;
    limit?: number;
    query?: string;
    outcome?: string;
}): {
    columns: {
        [k: string]: {
            cursor?: string | undefined;
            total: number;
            items: {
                allowed: {
                    input: boolean;
                    stop: boolean;
                    resume: boolean;
                };
                disabledReason: string | undefined;
                anomaly?: string | undefined;
                id: unknown;
                title: unknown;
                state: unknown;
                column: "running" | "ended" | "waiting" | "pending";
                outcome: unknown;
                createdAt: unknown;
                updatedAt: unknown;
                pendingApprovals: number;
                attention: unknown;
                progress: any;
                lastProgressAt: unknown;
                budget: {
                    steps: {} | null;
                    usage: {} | null;
                };
                acceptance: {
                    passed: any;
                    total: any;
                };
            }[];
            hasMore: boolean;
        };
    };
    snapshotAt: number;
    revision: string;
    filtered: boolean;
    pendingApprovals: number;
};
