import { type Config } from './config.js';
import { type RuntimeContext } from './runtime.js';
import { type PanelConnection } from './panel/routes.js';
/** Host owns ordered resource cleanup; runtime keeps DSH calls behind structural adapters. */
export interface PluginContext {
    effect(factory: () => (() => void | Promise<void>)): unknown;
    /** Loader raw values still include !!js markers before interpolation/defaults. */
    readonly fiber?: {
        readonly entry?: {
            readonly options: {
                readonly config?: unknown;
            };
        };
    };
    provide?(name: string, value: unknown): unknown;
    get?: RuntimeContext['get'];
    logger?: {
        info(message: string): void;
    };
    tools?: {
        guard?(callback: (execution: import('./tools/runtime.js').ToolExecutionContext) => unknown): unknown;
    };
    agentPresets?: {
        composedPreset(ctx: unknown): string | undefined;
    };
    connection?: PanelConnection;
    agents?: RuntimeContext['agents'];
    subagents?: RuntimeContext['subagents'];
    sessionQuery?: RuntimeContext['sessionQuery'];
    sessions?: RuntimeContext['sessions'];
    agentDefaultModel?: RuntimeContext['agentDefaultModel'];
    llm?: RuntimeContext['llm'];
    on?: RuntimeContext['on'];
}
export declare const inject: string[];
export declare function apply(ctx: PluginContext, input: Config): void;
export { createConfigSchema, resolveConfig, defaults } from './config.js';
export type { Config } from './config.js';
export * from './domain/index.js';
export { createEngine } from './engine/index.js';
export { createWatchdog, measureWorker } from './engine/watchdog.js';
export { installPanelRoutes } from './panel/routes.js';
