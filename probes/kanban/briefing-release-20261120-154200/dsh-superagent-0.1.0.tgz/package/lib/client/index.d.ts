/** Browser factory is serialized by build-client; React and slots stay host-owned. */
import { createWorkspacePage } from './workspace.js';
import { workspaceStyles } from './workspace-style.js';
export declare function createClientPlugin(React: any, dictionaries: Record<string, Record<string, unknown>>, channelDefinitions: readonly unknown[], workspaceFactory?: typeof createWorkspacePage, styleFactory?: typeof workspaceStyles): {
    inject: string[];
    apply(ctx: any): void;
};
