/** Host theme tokens only. No body mount, global reset, or application colors. */
export declare function workspaceStyles(): string;
