/** Serialized by the client builder. Keep every runtime helper inside this factory. */
export declare function createWorkspacePage(React: any, request: (path: string, body?: any, signal?: any) => Promise<any>, t: any, css: string): () => any;
