/** Pure DSH Conversation Definitions; no renderer/DOM or runtime package imports. */
export declare function createChannelDefinitions(): {
    kind: string;
    target: string;
    match(event: any): {
        id: string;
        role: string;
        exclusive: boolean;
    } | {
        id: any;
        role: string;
        exclusive?: undefined;
    } | null;
    start(_context: any, match: any): {
        seq: any;
        messages: any;
    };
    update(context: any): any;
    publication(): string;
    buildViewNode(context: any): {
        key: any;
        id: any;
        kind: string;
        target: string;
        anchorSeq: any;
        location: any;
        visibility: string;
        groupTree: string;
        data: any;
    } | null;
}[];
