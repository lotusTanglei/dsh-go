export declare const FS_SEARCH_CONFIG: Readonly<{
    sampleOverCapGlobResults: false;
}>;
