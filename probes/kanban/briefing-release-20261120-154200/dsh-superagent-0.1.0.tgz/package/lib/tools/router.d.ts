import type { TicketBrief, TicketState } from '../domain/ticket.js';
import type { ParameterSchema, ParameterValidation } from './descriptor.js';
export interface RouterToolParams {
    readonly ticket_create: {
        readonly brief: TicketBrief;
    };
    readonly ticket_list: {
        readonly state?: TicketState;
        readonly threadKey?: string;
        readonly limit?: number;
    };
    readonly ticket_status: {
        readonly ticketId: string;
    };
    readonly ticket_cancel: {
        readonly ticketId: string;
        readonly reason: string;
    };
    readonly ticket_resume: {
        readonly ticketId: string;
    };
    readonly assignment_start: {
        readonly ticketId: string;
    };
    readonly assignment_stop: {
        readonly assignmentId: string;
        readonly reason: string;
    };
    readonly human_ask: {
        readonly question: string;
        readonly ticketId?: string;
    };
    readonly channel_reply: {
        readonly threadKey: string;
        readonly body: string;
    };
}
export type RouterToolName = keyof RouterToolParams;
export declare const ticketBriefSchema: ParameterSchema;
/** Structural descriptors only. Host registration, engine commands and authorization are separate. */
export declare const routerToolDescriptors: readonly [{
    readonly name: "ticket_create";
    readonly description: "Propose a Ticket from a complete structured brief.";
    readonly parameters: ParameterSchema;
}, {
    readonly name: "ticket_list";
    readonly description: "List Tickets, optionally filtered by state or thread.";
    readonly parameters: ParameterSchema;
}, {
    readonly name: "ticket_status";
    readonly description: "Read the status of one Ticket.";
    readonly parameters: ParameterSchema;
}, {
    readonly name: "ticket_cancel";
    readonly description: "Request cancellation of a Ticket with a reason.";
    readonly parameters: ParameterSchema;
}, {
    readonly name: "ticket_resume";
    readonly description: "Request resumption of an ended Ticket; human trust and Mandate checks remain required.";
    readonly parameters: ParameterSchema;
}, {
    readonly name: "assignment_start";
    readonly description: "Request a new Assignment for an open Ticket.";
    readonly parameters: ParameterSchema;
}, {
    readonly name: "assignment_stop";
    readonly description: "Request stopping an Assignment with a reason.";
    readonly parameters: ParameterSchema;
}, {
    readonly name: "human_ask";
    readonly description: "Ask the human a question, optionally about a Ticket.";
    readonly parameters: ParameterSchema;
}, {
    readonly name: "channel_reply";
    readonly description: "Reply through the thread's Channel; outbound policy and approval checks remain required.";
    readonly parameters: ParameterSchema;
}];
export declare const routerToolNames: readonly RouterToolName[];
/** Strict shape validation only; does not create, resume, dispatch or send anything. */
export declare function validateRouterToolParams<Name extends RouterToolName>(name: Name, input: unknown): ParameterValidation<RouterToolParams[Name]>;
