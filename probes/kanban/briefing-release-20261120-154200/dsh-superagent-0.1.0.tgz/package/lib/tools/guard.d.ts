import type { Assignment } from '../domain/assignment.js';
import type { AssignmentId, TicketId } from '../domain/ids.js';
import type { Ticket } from '../domain/ticket.js';
export type ToolRole = 'router' | 'worker' | 'watchdog';
export type RoleToolAllowlist = Readonly<Record<ToolRole, readonly string[]>>;
export interface WorkerBinding {
    readonly assignmentId: AssignmentId;
    readonly ticketId: TicketId;
}
/** All identity and state fields must come from trusted caller snapshots, never tool arguments. */
export interface ToolGuardInput {
    readonly composedPreset?: string;
    readonly sessionId?: string;
    readonly toolName: string;
    readonly roleTools: RoleToolAllowlist;
    readonly binding?: WorkerBinding;
    readonly ticket?: Pick<Ticket, 'id' | 'state' | 'currentAssignment'>;
    readonly assignment?: Pick<Assignment, 'id' | 'ticketId' | 'sessionId' | 'state'>;
}
export type GuardDenialCode = 'SA_ROLE_TOOL_DENIED' | 'SA_ASSIGNMENT_UNBOUND' | 'SA_ASSIGNMENT_ENDED' | 'SA_ASSIGNMENT_STALE' | 'SA_ASSIGNMENT_WAITING';
export interface GuardDenial {
    readonly reason: string;
    readonly info: {
        readonly name: 'SuperagentToolGuardError';
        readonly code: GuardDenialCode;
    };
}
/** Exact actual preset match only; parent roles and metadata are intentionally not accepted. */
export declare function roleForPreset(composedPreset: string | undefined): ToolRole | undefined;
/**
 * Pure, deny-only decision. Undefined adds no denial: it does NOT grant execution or
 * override any other approval/sandbox guard. Does not hide schemas or read state.
 * The caller must supply a fresh snapshot on every invocation.
 */
export declare function guardToolCall(input: ToolGuardInput): GuardDenial | undefined;
