import type { ApprovalKind } from '../domain/approval.js';
import type { TicketBrief } from '../domain/ticket.js';
import type { Report } from '../engine/report.js';
import type { ParameterSchema, ParameterValidation } from './descriptor.js';
export interface WorkerToolParams {
    readonly report_progress: Pick<Report, 'state' | 'done' | 'todo' | 'changedPaths' | 'risks' | 'needHuman'> & {
        readonly acceptance?: Report['acceptance'];
    };
    readonly report_result: Report;
    readonly request_approval: {
        readonly kind: ApprovalKind;
        readonly summary: string;
        readonly payload: Record<string, unknown>;
    };
    readonly ask_router: {
        readonly question: string;
    };
}
export type WorkerToolName = keyof WorkerToolParams;
export declare const workerToolDescriptors: readonly [{
    readonly name: "report_progress";
    readonly description: "Report bounded progress against the supplied TicketBrief.";
    readonly parameters: ParameterSchema;
}, {
    readonly name: "report_result";
    readonly description: "Return the final structured report for the supplied TicketBrief.";
    readonly parameters: ParameterSchema;
}, {
    readonly name: "request_approval";
    readonly description: "Request one human approval for a declared action.";
    readonly parameters: ParameterSchema;
}, {
    readonly name: "ask_router";
    readonly description: "Ask Router for clarification without contacting a channel.";
    readonly parameters: ParameterSchema;
}];
export declare const workerToolNames: readonly WorkerToolName[];
export declare function validateWorkerToolParams<Name extends WorkerToolName>(name: Name, input: unknown): ParameterValidation<WorkerToolParams[Name]>;
export type WorkerBriefContext = Pick<TicketBrief, 'acceptance'>;
