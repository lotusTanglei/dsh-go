import { type RoleToolAllowlist, type WorkerBinding } from './guard.js';
import type { Assignment } from '../domain/assignment.js';
import type { Ticket } from '../domain/ticket.js';
export interface RuntimeRoleConfig {
    readonly roleTools: RoleToolAllowlist;
    readonly routerPreset?: string;
    readonly workerPreset?: string;
    readonly watchdogPreset?: string;
    /** Production bindings are resolved freshly on every call; never supplied by tool args. */
    readonly resolveWorker?: (agent: object) => WorkerGuardSnapshot | undefined;
    /** Release gate applies to recovery as well as fresh assignment starts. */
    readonly executionBlocked?: boolean;
}
export interface ToolExecutionContext {
    readonly agent?: object & {
        readonly ctx?: unknown;
    };
    readonly name: string;
}
export interface ToolGuardContext {
    readonly tools: {
        guard?(callback: (execution: ToolExecutionContext) => unknown): unknown;
    };
    readonly agentPresets?: {
        composedPreset(ctx: unknown): string | undefined;
    };
}
export interface WorkerGuardSnapshot {
    readonly sessionId: string;
    readonly binding: WorkerBinding;
    readonly ticket: Pick<Ticket, 'id' | 'state' | 'currentAssignment'>;
    readonly assignment: Pick<Assignment, 'id' | 'ticketId' | 'sessionId' | 'state'>;
}
export interface RoleGuardRuntime {
    bindWorker(agent: object, snapshot: WorkerGuardSnapshot): void;
    unbindWorker(agent: object): void;
    dispose(): void;
}
/** Install the final deny-only guard for exact Super-agent preset identities. */
export declare function installRoleGuard(context: ToolGuardContext, config: RuntimeRoleConfig): RoleGuardRuntime | undefined;
/** Register descriptor placeholders inside a mounted role scope; engine handlers are P3-owned. */
export declare function registerRoleToolDescriptors(context: ToolGuardContext & {
    tools: ToolGuardContext['tools'] & {
        register(tool: unknown): unknown;
    };
}, descriptors: readonly {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
}[]): () => void;
