/** Framework-neutral JSON-schema subset used by the P2 descriptors; no registration or execution. */
export interface ParameterSchema {
    readonly type?: 'object' | 'array' | 'string' | 'boolean' | 'integer';
    readonly description?: string;
    readonly properties?: Readonly<Record<string, ParameterSchema>>;
    readonly required?: readonly string[];
    readonly additionalProperties?: false | ParameterSchema;
    readonly items?: ParameterSchema;
    readonly enum?: readonly string[];
}
export interface ToolDescriptor<Name extends string = string> {
    readonly name: Name;
    readonly description: string;
    readonly parameters: ParameterSchema;
}
export interface ParameterIssue {
    readonly path: string;
    readonly message: string;
}
export type ParameterValidation<T> = {
    readonly ok: true;
    readonly value: T;
} | {
    readonly ok: false;
    readonly code: 'SA_TOOL_PARAMETERS_INVALID';
    readonly issues: readonly ParameterIssue[];
};
export declare function invalidParameters(path: string, message: string): ParameterValidation<never>;
export declare function objectSchema(properties: Readonly<Record<string, ParameterSchema>>, required?: readonly string[]): ParameterSchema;
export declare const nonemptyString: ParameterSchema;
export declare const stringArray: ParameterSchema;
export declare function validateParameters<T>(descriptor: ToolDescriptor, input: unknown): ParameterValidation<T>;
