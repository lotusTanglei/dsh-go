import { type Trigger } from '../domain/trigger.js';
import type { Source, ThreadContext, TriggerSink } from './types.js';
export interface SessionEventInput {
    readonly session: {
        readonly id: string;
    };
    readonly event: {
        readonly type: string;
        readonly time: number;
        readonly data: any;
    };
}
export interface SessionSourcePorts {
    on(name: 'session/event', listener: (session: {
        id: string;
    }, event: SessionEventInput['event']) => void): (() => void);
    readThread?(key: string): Promise<readonly Trigger[]>;
    reply(body: string, idempotencyKey: string): Promise<void>;
    onError?(error: unknown): void;
}
export declare class SessionSource implements Source {
    readonly sessionId: string;
    private readonly ports;
    private readonly sink;
    readonly id: import("../domain/ids.js").SourceId;
    readonly kind: "session";
    readonly attended = true;
    private unsubscribe?;
    private lastAt?;
    private error?;
    private readonly pending;
    private stopping;
    constructor(sessionId: string, ports: SessionSourcePorts, sink: TriggerSink);
    verify(input: unknown): Promise<boolean>;
    normalize(input: unknown): Promise<Trigger>;
    /** Normalize one genuine durable human inbox insertion without fabricating user/message. */
    normalizeInbox(input: SessionEventInput, messageId: string): Promise<Trigger>;
    start(): Promise<void>;
    stop(): Promise<void>;
    health(): Promise<{
        ok: boolean;
        lastAt: number | undefined;
        detail: string | undefined;
    }>;
    readThread(key: Parameters<Source['readThread']>[0]): Promise<ThreadContext>;
    reply(channel: Parameters<Source['reply']>[0], key: Parameters<Source['reply']>[1], body: string, idemKey: string): Promise<void>;
}
