import type { SourceId } from '../domain/ids.js';
import type { Source, SourceLifecycle } from './types.js';
/** Keys are exact instance ids; multiple instances of one kind may coexist. */
export declare class SourceRegistry {
    private readonly lifecycle?;
    private readonly sources;
    private readonly disposers;
    constructor(lifecycle?: SourceLifecycle | undefined);
    register(source: Source): () => Promise<void>;
    get(id: SourceId): Source | undefined;
    all(): readonly Source[];
    stopAll(): Promise<void>;
}
