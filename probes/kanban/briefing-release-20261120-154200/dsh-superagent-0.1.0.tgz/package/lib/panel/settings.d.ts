import type { Config } from '../config.js';
export type ConfigOrigin = 'patch' | 'environment' | 'default' | 'derived' | 'unavailable';
export interface EffectiveSetting {
    readonly key: string;
    readonly value: unknown;
    readonly origin: ConfigOrigin;
    readonly redacted?: boolean;
    readonly originDetail?: string;
}
/** Inspect Loader's pre-interpolation values, never compare effective values to defaults.
 * Raw expressions are classified but never evaluated or returned to the browser.
 * Missing Loader metadata is unknown, not evidence that a value was a default.
 */
export declare function effectiveSettings(config: Partial<Config>, raw?: Record<string, unknown>): readonly EffectiveSetting[];
