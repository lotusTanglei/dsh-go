import { type Store } from '../store/index.js';
export interface WorkspaceBriefingDecisionDTO {
    id: string;
    kind: 'approval' | 'question' | 'anomaly';
    ticketId?: string;
    title: string;
    summary: string;
    at: number;
}
export interface WorkspaceBriefingTicketDTO {
    id: string;
    title: string;
    state: string;
    outcome?: string;
    progress?: string;
    nextAction?: string;
    question?: string;
    disabledReason?: string;
    anomaly?: string;
    at: number;
}
export interface WorkspaceBriefingResultDTO extends WorkspaceBriefingTicketDTO {
    risks: string[];
}
export interface WorkspaceBriefingDTO {
    snapshotAt: number;
    decisions: {
        total: number;
        items: WorkspaceBriefingDecisionDTO[];
    };
    active: {
        total: number;
        items: WorkspaceBriefingTicketDTO[];
    };
    results: {
        total: number;
        items: WorkspaceBriefingResultDTO[];
    };
    counts: {
        pending: number;
        running: number;
        waiting: number;
        ended: number;
    };
}
/** Read-only, unfiltered task projection. Report text is display data, never authority. */
export declare function readWorkspaceBriefing(store: Store): WorkspaceBriefingDTO;
