import type { Store } from '../store/index.js';
export type CommandIntent = 'message' | 'new-task' | 'ticket-input';
export interface WorkspaceCommand {
    epoch: string;
    requestId: string;
    intent: CommandIntent;
    text: string;
    ticketId?: string;
    recreateFrom?: string;
}
export interface CommandRecord {
    version: 1;
    requestId: string;
    epoch: string;
    intent: CommandIntent;
    digest: string;
    messageId: string;
    threadKey: string;
    targetTicket?: string;
    originTicket?: string;
    stage: 'received' | 'queued' | 'claimed' | 'admitted' | 'processing' | 'published' | 'canceled' | 'rejected' | 'unknown';
    seq: number;
    at: number;
    updatedAt: number;
    durable: boolean;
    error?: string;
}
export declare class WorkspaceError extends Error {
    readonly code: string;
    readonly status: number;
    constructor(code: string, status: number);
}
export declare const commandError: (code: string, status?: number) => never;
export declare function validateCommand(value: WorkspaceCommand): void;
export declare function commandDigest(value: WorkspaceCommand): string;
export declare function createCommandJournal(store: Store): {
    read: (id: string) => CommandRecord | undefined;
    all: () => CommandRecord[];
    byMessage(messageId: string): CommandRecord | undefined;
    receive(input: WorkspaceCommand, thread: string): CommandRecord;
    update(id: string, patch: Partial<Pick<CommandRecord, "stage" | "durable" | "error">>): CommandRecord;
};
export interface WorkspaceBinding {
    version: 1;
    epoch: string;
    sessionId: string;
    createdAt: number;
}
export declare function bindWorkspace(store: Store, sessionId: string): {
    current: WorkspaceBinding;
    archives: WorkspaceBinding[];
};
