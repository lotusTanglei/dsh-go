export interface ConversationItem {
    id: string;
    /** First visible occurrence; never moves when this message is admitted or updated. */
    seq: number;
    /** Most recent durable event that changed the visible item. */
    lastSeq: number;
    at: number;
    kind: 'user' | 'assistant' | 'notice';
    /** Plain text, not HTML or Markdown. Render with a text node, never innerHTML. */
    text: string;
    stage?: string;
}
export interface ConversationPageOptions {
    epoch: string;
    after?: string;
    before?: string;
    limit?: number;
}
export interface ConversationPage {
    items: ConversationItem[];
    nextBefore?: string;
    nextAfter: string;
    hasMore: boolean;
    /** Latest real model reply, independent of the bounded notice/history window. */
    latestAssistant?: ConversationItem;
}
export type ConversationErrorCode = 'invalid_input' | 'invalid_cursor' | 'epoch_mismatch';
/** Fixed public errors: neither messages nor causes contain caller input. */
export declare class ConversationError extends Error {
    readonly code: ConversationErrorCode;
    constructor(code: ConversationErrorCode);
}
/** Visible human input, model text, and explicit superagent notices only. */
export declare function foldConversation(events: readonly any[]): ConversationItem[];
/**
 * Initial/before: newest bounded window in first-seq ascending display order.
 * After: bounded updates in (lastSeq, event slot) order; merge by stable item id.
 * A completed delta read advances over the whole log, including invisible events.
 * Cursors are opaque positions, not authorization: the Host must bind epoch/log.
 */
export declare function conversationPage(events: readonly any[], options: ConversationPageOptions): ConversationPage;
