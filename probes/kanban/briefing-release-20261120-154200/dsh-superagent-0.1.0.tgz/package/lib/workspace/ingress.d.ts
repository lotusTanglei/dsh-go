import type { Store } from '../store/index.js';
import { type WorkspaceCommand, type CommandRecord, type WorkspaceBinding } from './commands.js';
export interface IngressPorts {
    binding(): WorkspaceBinding;
    agent(): {
        session: unknown;
        followup(message: unknown): void;
        inject?(message: unknown): void;
    } | undefined;
    readSession(): Promise<{
        events: any[];
    }>;
    flush(session: unknown): Promise<boolean>;
    modelAvailable(): Promise<boolean>;
    paused(): boolean;
    queueLimit: number;
    target(id: string): {
        threadKey: string;
    } | undefined;
    ingest(record: CommandRecord, event: any): Promise<void>;
}
/** One authority for UI receipt, event catch-up and restart reconciliation. No message-body copy. */
export declare function createWorkspaceIngress(store: Store, ports: IngressPorts): {
    journal: {
        read: (id: string) => CommandRecord | undefined;
        all: () => CommandRecord[];
        byMessage(messageId: string): CommandRecord | undefined;
        receive(input: WorkspaceCommand, thread: string): CommandRecord;
        update(id: string, patch: Partial<Pick<CommandRecord, "stage" | "durable" | "error">>): CommandRecord;
    };
    receipt: (record: CommandRecord) => {
        code?: string | undefined;
        ticketId?: string | undefined;
        requestId: string;
        messageId: string;
        epoch: string;
        stage: "unknown" | "rejected" | "published" | "canceled" | "received" | "queued" | "claimed" | "admitted" | "processing";
        accepted: boolean;
        seq: number;
        at: number;
        updatedAt: number;
    };
    reconcile: (record: CommandRecord, events?: any[]) => Promise<CommandRecord>;
    submit(input: WorkspaceCommand): Promise<{
        code?: string | undefined;
        ticketId?: string | undefined;
        requestId: string;
        messageId: string;
        epoch: string;
        stage: "unknown" | "rejected" | "published" | "canceled" | "received" | "queued" | "claimed" | "admitted" | "processing";
        accepted: boolean;
        seq: number;
        at: number;
        updatedAt: number;
    }>;
    status(epoch: string, requestId: string): Promise<{
        code?: string | undefined;
        ticketId?: string | undefined;
        requestId: string;
        messageId: string;
        epoch: string;
        stage: "unknown" | "rejected" | "published" | "canceled" | "received" | "queued" | "claimed" | "admitted" | "processing";
        accepted: boolean;
        seq: number;
        at: number;
        updatedAt: number;
    }>;
    cancelUnknown(epoch: string, requestId: string, seq: number): Promise<{
        code?: string | undefined;
        ticketId?: string | undefined;
        requestId: string;
        messageId: string;
        epoch: string;
        stage: "unknown" | "rejected" | "published" | "canceled" | "received" | "queued" | "claimed" | "admitted" | "processing";
        accepted: boolean;
        seq: number;
        at: number;
        updatedAt: number;
    }>;
    catchUp(messageIds: readonly string[]): Promise<CommandRecord[]>;
    recover(): Promise<void>;
};
