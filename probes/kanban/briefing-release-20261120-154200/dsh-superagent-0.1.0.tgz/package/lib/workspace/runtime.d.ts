import type { Store } from '../store/index.js';
import type { Config } from '../config.js';
import type { Policy } from '../domain/policy.js';
import type { SessionSource } from '../sources/session.js';
import { type CommandRecord, type WorkspaceCommand } from './commands.js';
/** Host-only facade. Browser clients never select an Agent, role, actor or Session. */
export declare function createWorkspaceRuntime(store: Store, config: Config, policy: Policy, ports: {
    ctx: any;
    mainId: string;
    source: SessionSource;
    engine: any;
    deliverTicket(id: string): Promise<void>;
    approvalsReady(id: string): boolean;
    mandateValid(row: any): boolean;
}): {
    current: import("./commands.js").WorkspaceBinding;
    ingress: {
        journal: {
            read: (id: string) => CommandRecord | undefined;
            all: () => CommandRecord[];
            byMessage(messageId: string): CommandRecord | undefined;
            receive(input: WorkspaceCommand, thread: string): CommandRecord;
            update(id: string, patch: Partial<Pick<CommandRecord, "stage" | "durable" | "error">>): CommandRecord;
        };
        receipt: (record: CommandRecord) => {
            code?: string | undefined;
            ticketId?: string | undefined;
            requestId: string;
            messageId: string;
            epoch: string;
            stage: "unknown" | "rejected" | "published" | "canceled" | "received" | "queued" | "claimed" | "admitted" | "processing";
            accepted: boolean;
            seq: number;
            at: number;
            updatedAt: number;
        };
        reconcile: (record: CommandRecord, events?: any[]) => Promise<CommandRecord>;
        submit(input: WorkspaceCommand): Promise<{
            code?: string | undefined;
            ticketId?: string | undefined;
            requestId: string;
            messageId: string;
            epoch: string;
            stage: "unknown" | "rejected" | "published" | "canceled" | "received" | "queued" | "claimed" | "admitted" | "processing";
            accepted: boolean;
            seq: number;
            at: number;
            updatedAt: number;
        }>;
        status(epoch: string, requestId: string): Promise<{
            code?: string | undefined;
            ticketId?: string | undefined;
            requestId: string;
            messageId: string;
            epoch: string;
            stage: "unknown" | "rejected" | "published" | "canceled" | "received" | "queued" | "claimed" | "admitted" | "processing";
            accepted: boolean;
            seq: number;
            at: number;
            updatedAt: number;
        }>;
        cancelUnknown(epoch: string, requestId: string, seq: number): Promise<{
            code?: string | undefined;
            ticketId?: string | undefined;
            requestId: string;
            messageId: string;
            epoch: string;
            stage: "unknown" | "rejected" | "published" | "canceled" | "received" | "queued" | "claimed" | "admitted" | "processing";
            accepted: boolean;
            seq: number;
            at: number;
            updatedAt: number;
        }>;
        catchUp(messageIds: readonly string[]): Promise<CommandRecord[]>;
        recover(): Promise<void>;
    };
    admission: {
        propose: (command: CommandRecord, brief: import("../index.js").TicketBrief) => import("./admission.js").AdmissionPlanDTO;
        decide: (input: import("./admission.js").AdmissionDecision) => import("./admission.js").AdmissionPlanDTO;
        list: (epoch?: string) => import("./admission.js").AdmissionPlanDTO[];
        recover: () => import("./admission.js").AdmissionPlanDTO[];
    };
    modelAvailable: () => Promise<boolean>;
    requireEpoch: (epoch: unknown) => undefined;
    workspace(input?: {
        cursor?: string;
        limit?: number;
        planId?: string;
    }): Promise<{
        pendingApprovals: number;
        admissionsNext?: string | undefined;
        epoch: string;
        archiveEpochs: {
            epoch: string;
            createdAt: number;
        }[];
        state: string;
        model: {
            code?: string | undefined;
            available: boolean;
        };
        serverTime: number;
        capabilities: {
            conversation: boolean;
            send: boolean;
            workerExecution: boolean;
            executionReason: string;
        };
        briefing: import("./briefing.js").WorkspaceBriefingDTO;
        admissions: import("./admission.js").AdmissionPlanDTO[];
        admissionsTotal: number;
        pendingPlans: number;
    }>;
    conversation(input: {
        epoch: string;
        after?: string;
        before?: string;
        limit?: number;
    }): Promise<import("./conversation.js").ConversationPage>;
    cancelCommand(input: {
        epoch: string;
        requestId: string;
        seq: number;
    }): Promise<{
        code?: string | undefined;
        ticketId?: string | undefined;
        requestId: string;
        messageId: string;
        epoch: string;
        stage: "unknown" | "rejected" | "published" | "canceled" | "received" | "queued" | "claimed" | "admitted" | "processing";
        accepted: boolean;
        seq: number;
        at: number;
        updatedAt: number;
    }>;
    command(input: WorkspaceCommand): Promise<{
        code?: string | undefined;
        ticketId?: string | undefined;
        requestId: string;
        messageId: string;
        epoch: string;
        stage: "unknown" | "rejected" | "published" | "canceled" | "received" | "queued" | "claimed" | "admitted" | "processing";
        accepted: boolean;
        seq: number;
        at: number;
        updatedAt: number;
    }>;
    commandStatus(input: {
        epoch: string;
        requestId: string;
    }): Promise<{
        code?: string | undefined;
        ticketId?: string | undefined;
        requestId: string;
        messageId: string;
        epoch: string;
        stage: "unknown" | "rejected" | "published" | "canceled" | "received" | "queued" | "claimed" | "admitted" | "processing";
        accepted: boolean;
        seq: number;
        at: number;
        updatedAt: number;
    }>;
    decideAdmission(input: {
        epoch: string;
        requestId: string;
        planId: string;
        fingerprint: string;
        decision: "approve" | "reject";
    }): Promise<import("./admission.js").AdmissionPlanDTO>;
    reviseAdmission(input: {
        epoch: string;
        requestId: string;
        planId: string;
        fingerprint: string;
        patch: Record<string, unknown>;
    }): Promise<import("./admission.js").AdmissionPlanDTO>;
    propose(brief: any): Promise<import("./admission.js").AdmissionPlanDTO>;
    onHuman(trigger: any): Promise<void>;
    recover(): Promise<void>;
};
