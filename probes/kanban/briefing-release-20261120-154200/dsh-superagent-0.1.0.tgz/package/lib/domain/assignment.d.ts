import type { AssignmentId, TicketId } from './ids.js';
import type { Ticket } from './ticket.js';
export type AssignmentState = 'pending' | 'running' | 'ended';
export interface Assignment {
    readonly id: AssignmentId;
    readonly ticketId: TicketId;
    readonly sessionId: string;
    readonly state: AssignmentState;
    readonly createdAt: number;
    readonly startedAt?: number;
    readonly endedAt?: number;
    readonly endedReason?: string;
    readonly lastProgressAt: number;
    readonly steps: number;
    readonly tokens: number;
    readonly retries: number;
    readonly repeatedCalls: number;
}
export type AssignmentEvent = {
    readonly type: 'start';
    readonly at: number;
} | {
    readonly type: 'progress';
    readonly at: number;
    readonly steps?: number;
    readonly tokens?: number;
    readonly repeatedCalls?: number;
} | {
    readonly type: 'end';
    readonly at: number;
    readonly reason?: string;
};
export declare function createAssignment(input: Omit<Assignment, 'state' | 'lastProgressAt' | 'steps' | 'tokens' | 'retries' | 'repeatedCalls'> & Partial<Pick<Assignment, 'lastProgressAt' | 'steps' | 'tokens' | 'retries' | 'repeatedCalls'>>): Assignment;
export declare function transitionAssignment(assignment: Assignment, event: AssignmentEvent): Assignment;
export declare function acceptsAssignmentReport(assignment: Assignment, assignmentId: AssignmentId, ticketState: 'open' | 'running' | 'waiting_human' | 'ended'): boolean;
/** Tool gate used by P2 adapters: only the current live assignment may invoke a tool. */
export declare function canInvokeAssignmentTool(ticket: Pick<Ticket, 'state' | 'currentAssignment'>, assignment: Pick<Assignment, 'id' | 'state'>, boundAssignmentId: AssignmentId): boolean;
