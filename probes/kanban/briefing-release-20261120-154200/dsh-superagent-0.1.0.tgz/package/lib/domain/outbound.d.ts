import type { ThreadKey, TicketId } from './ids.js';
export type ChannelKind = 'session' | 'github-comment' | 'github-review' | 'feishu-thread';
export type OutboundKind = 'acknowledgement' | 'reply' | 'notice';
export type OutboundState = 'pending' | 'sent' | 'dropped';
export interface Outbound {
    readonly id: string;
    readonly ticketId?: TicketId;
    readonly channel: ChannelKind;
    readonly threadKey: ThreadKey;
    readonly kind: OutboundKind;
    readonly body: string;
    readonly idempotencyKey: string;
    readonly state: OutboundState;
    readonly attempts: number;
    readonly nextAt: number;
    readonly lastError?: string;
}
export declare function createOutbound(input: Omit<Outbound, 'state' | 'attempts'>): Outbound;
export declare function markOutboundSent(outbound: Outbound): Outbound;
export declare function retryOutbound(outbound: Outbound, nextAt: number, error: string): Outbound;
export declare function dropOutbound(outbound: Outbound, error?: string): Outbound;
export declare function isSameOutbound(a: Pick<Outbound, 'idempotencyKey'>, b: Pick<Outbound, 'idempotencyKey'>): boolean;
