import type { SourceId, ThreadKey, TicketId, TriggerId, EvalId } from './ids.js';
export type ThreadKind = 'session' | 'issue' | 'pr' | 'im-thread';
export interface ThreadRef {
    readonly source: SourceId;
    readonly kind: ThreadKind;
    readonly id: string;
    readonly address: Readonly<Record<string, string>>;
}
export interface Thread {
    readonly key: ThreadKey;
    readonly ref: ThreadRef;
    readonly createdAt: number;
    readonly lastAt: number;
    readonly seq: number;
    readonly paused: boolean;
    readonly subscriptions: readonly TicketId[];
    readonly pending: readonly TriggerId[];
    readonly evaluating?: EvalId;
}
export declare function threadKeyOf(ref: Pick<ThreadRef, 'source' | 'id'>): ThreadKey;
export declare function createThread(ref: ThreadRef, at: number): Thread;
export declare function enqueueTrigger(thread: Thread, trigger: Pick<{
    id: TriggerId;
    at: number;
}, 'id' | 'at'>): Thread;
export declare function startEvaluation(thread: Thread, id: EvalId, triggerIds?: readonly TriggerId[]): Thread;
export declare function finishEvaluation(thread: Thread, evalId: EvalId): Thread;
export declare function setThreadPaused(thread: Thread, paused: boolean): Thread;
export declare function subscribeThread(thread: Thread, ticket: TicketId): Thread;
export declare function unsubscribeThread(thread: Thread, ticket: TicketId): Thread;
