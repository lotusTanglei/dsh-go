import type { AssignmentId, DecisionId, ThreadKey, TicketId } from './ids.js';
import type { Mandate } from './mandate.js';
import type { Trust } from './trigger.js';
export type TicketState = 'open' | 'running' | 'waiting_human' | 'ended';
export type EndedBy = 'executor' | 'human' | 'watchdog';
export type Outcome = 'completed' | 'stopped' | 'failed' | 'dropped';
export interface AcceptanceCriterion {
    readonly id: string;
    readonly check: string;
    readonly kind: 'command' | 'assertion';
}
export interface TicketBrief {
    readonly goal: string;
    readonly scope: {
        readonly repo: string;
        readonly subdirs: readonly string[];
    };
    readonly base: {
        readonly ref: string;
        readonly requireCleanTree: boolean;
    };
    readonly allowWrite: readonly string[];
    readonly denyWrite: readonly string[];
    readonly runtime: string;
    readonly acceptance: readonly AcceptanceCriterion[];
    readonly outOfScope: readonly string[];
    readonly blockers: readonly string[];
    readonly firstAction: string;
    readonly approvalsRequired: readonly string[];
}
export interface Ticket {
    readonly id: TicketId;
    readonly threadKey: ThreadKey;
    readonly decisionId: DecisionId;
    readonly mandate: Mandate;
    readonly brief: TicketBrief;
    readonly title: string;
    readonly state: TicketState;
    readonly workdir: string;
    readonly createdAt: number;
    readonly updatedAt: number;
    readonly assignments: readonly AssignmentId[];
    readonly currentAssignment?: AssignmentId;
    readonly attention?: {
        readonly id: string;
        readonly question: string;
        readonly at: number;
    };
    readonly stoppedByHuman: boolean;
    readonly ended?: {
        readonly at: number;
        readonly by: EndedBy;
        readonly outcome: Outcome;
        readonly reason?: string;
    };
}
export interface TicketInput extends Omit<Ticket, 'state' | 'updatedAt' | 'assignments' | 'stoppedByHuman'> {
    readonly state?: TicketState;
    readonly updatedAt?: number;
    readonly assignments?: readonly AssignmentId[];
    readonly stoppedByHuman?: boolean;
}
export type TicketEvent = {
    readonly type: 'assignment_start';
    readonly assignmentId: AssignmentId;
    readonly at: number;
    readonly hasCapacity: boolean;
} | {
    readonly type: 'waiting';
    readonly at: number;
    readonly attention?: {
        readonly id: string;
        readonly question: string;
    };
} | {
    readonly type: 'request_approval';
    readonly at: number;
    readonly attention?: {
        readonly id: string;
        readonly question: string;
    };
} | {
    readonly type: 'ask_router';
    readonly at: number;
    readonly attention?: {
        readonly id: string;
        readonly question: string;
    };
} | {
    readonly type: 'human_answer';
    readonly at: number;
    readonly trust: Trust;
    readonly answer?: string;
} | {
    readonly type: 'approval_decision';
    readonly at: number;
    readonly trust: Trust;
    readonly approved?: boolean;
} | {
    readonly type: 'end';
    readonly at: number;
    readonly by: EndedBy;
    readonly outcome: Outcome;
    readonly reason?: string;
} | {
    readonly type: 'stop';
    readonly at: number;
    readonly by: 'human' | 'watchdog' | 'executor';
    readonly reason?: string;
} | {
    readonly type: 'resume';
    readonly at: number;
    readonly trust: Trust;
    readonly mandateValid: boolean;
    readonly hasPendingInput: boolean;
} | {
    readonly type: 'ticket_resume';
    readonly at: number;
    readonly trust: Trust;
    readonly mandateValid: boolean;
    readonly hasPendingInput: boolean;
};
export declare function validateAcceptanceCriterion(criterion: AcceptanceCriterion): boolean;
export declare function validateTicketBrief(brief: TicketBrief): boolean;
export declare function createTicket(input: TicketInput): Ticket;
/** Pure state transition for the Ticket state machine in 001 §7. */
export declare function transition(ticket: Ticket, event: TicketEvent): Ticket;
export declare function canResume(ticket: Ticket, input: {
    readonly trust: Trust;
    readonly mandateValid: boolean;
    readonly hasPendingInput: boolean;
}): boolean;
