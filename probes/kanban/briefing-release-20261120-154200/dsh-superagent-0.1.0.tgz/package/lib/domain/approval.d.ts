import type { ApprovalId, TicketId } from './ids.js';
export type ApprovalKind = 'merge-pr' | 'send-external' | 'delete-branch' | 'close-pr' | 'payment' | 'permission';
export type ApprovalState = 'pending' | 'approved' | 'denied' | 'expired';
export interface Approval {
    readonly id: ApprovalId;
    readonly ticketId?: TicketId;
    readonly kind: ApprovalKind;
    readonly summary: string;
    readonly payload: unknown;
    readonly requestedBy: string;
    readonly createdAt: number;
    readonly state: ApprovalState;
    readonly decidedBy?: string;
    readonly decidedAt?: number;
    readonly reason?: string;
}
export type ApprovalEvent = {
    readonly type: 'approve';
    readonly by: string;
    readonly at: number;
    readonly reason?: string;
} | {
    readonly type: 'deny';
    readonly by: string;
    readonly at: number;
    readonly reason?: string;
} | {
    readonly type: 'expire';
    readonly at: number;
};
export declare function createApproval(input: Omit<Approval, 'state'>): Approval;
export declare function transitionApproval(approval: Approval, event: ApprovalEvent): Approval;
