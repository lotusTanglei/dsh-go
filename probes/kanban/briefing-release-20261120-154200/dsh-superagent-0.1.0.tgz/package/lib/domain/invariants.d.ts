import type { Assignment } from './assignment.js';
import type { Decision, Eval } from './eval.js';
import type { Mandate } from './mandate.js';
import type { Outbound } from './outbound.js';
import type { Policy } from './policy.js';
import type { Thread } from './thread.js';
import type { Ticket } from './ticket.js';
import type { Trigger } from './trigger.js';
import type { AssignmentId } from './ids.js';
/** I1: one trigger per (source, externalId) deduplication key. */
export declare function invariantI1UniqueTriggers(triggers: readonly Pick<Trigger, 'source' | 'externalId'>[]): boolean;
/** I2: accepted decisions sharing any trigger must map to one Ticket. */
export declare function invariantI2OneTicketPerTrigger(decisions: readonly Pick<Decision, 'id' | 'ticketId' | 'triggerIds'>[], tickets: readonly Pick<Ticket, 'id' | 'decisionId'>[]): boolean;
/** I3: a thread may have at most one running evaluation, and evaluating points to that Eval. */
export declare function invariantI3SingleRunningEval(evals: readonly Pick<Eval, 'id' | 'threadKey' | 'state'>[], threads?: readonly Pick<Thread, 'key' | 'evaluating'>[]): boolean;
/** I4: decisions may only use the current Policy version. */
export declare function invariantI4CurrentPolicy(evalOrDecision: Pick<Eval | Decision, 'policyVersion'>, policy: Pick<Policy, 'version'>): boolean;
/** I5: only grant/withdraw/revalidate operations may change a mandate. */
export type MandateMutation = 'grant' | 'withdraw' | 'revalidate';
export declare function invariantI5MandatePolicy(operation: MandateMutation, input: {
    readonly accepted?: boolean;
    readonly humanStop?: boolean;
    readonly revalidated?: boolean;
    readonly valid?: boolean;
    readonly policyVersion?: string;
    readonly currentPolicyVersion?: string;
}): boolean;
/** I6: ended Ticket resume is human-only and never human-stopped. */
export declare function invariantI6HumanOnlyResume(ticket: Pick<Ticket, 'state' | 'stoppedByHuman'>, trust: string): boolean;
/** I7: reports are accepted only for the current running assignment. */
export declare function invariantI7CurrentAssignment(ticket: Pick<Ticket, 'state' | 'currentAssignment'>, assignment: Pick<Assignment, 'id' | 'state'>, reportedAssignmentId: AssignmentId): boolean;
/** I8: idempotency keys uniquely identify outbound sends. */
export declare function invariantI8OutboundIdempotent(outbounds: readonly Pick<Outbound, 'idempotencyKey'>[]): boolean;
/** I9: policy changes do not alter an existing mandate's recorded value. */
export declare function invariantI9MandatePersists(mandateBefore: Pick<Mandate, 'policyVersion'>, mandateAfter: Pick<Mandate, 'policyVersion'>): boolean;
/** I10: an ended Ticket cannot execute tools through its Assignment. */
export declare function invariantI10EndedAssignmentDenied(ticket: Pick<Ticket, 'state' | 'currentAssignment'>, assignment: Pick<Assignment, 'id' | 'state'>, boundAssignmentId?: AssignmentId): boolean;
/** I11: a running Assignment whose session is absent from the live set is orphaned. */
export declare function isOrphan(assignment: Assignment, liveSessionIds: ReadonlySet<string>): boolean;
export declare const I1: typeof invariantI1UniqueTriggers;
export declare const I2: typeof invariantI2OneTicketPerTrigger;
export declare const I3: typeof invariantI3SingleRunningEval;
export declare const I4: typeof invariantI4CurrentPolicy;
export declare const I5: typeof invariantI5MandatePolicy;
export declare const I6: typeof invariantI6HumanOnlyResume;
export declare const I7: typeof invariantI7CurrentAssignment;
export declare const I8: typeof invariantI8OutboundIdempotent;
export declare const I9: typeof invariantI9MandatePersists;
export declare const I10: typeof invariantI10EndedAssignmentDenied;
export declare const I11: typeof isOrphan;
