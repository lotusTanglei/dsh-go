/** Nominal branded primitive helpers used throughout the pure domain model. */
export type Brand<T, K extends string> = T & {
    readonly __brand: K;
};
export type TriggerId = Brand<string, 'TriggerId'>;
export type ThreadKey = Brand<string, 'ThreadKey'>;
export type TicketId = Brand<string, 'TicketId'>;
export type AssignmentId = Brand<string, 'AssignmentId'>;
export type EvalId = Brand<string, 'EvalId'>;
export type DecisionId = Brand<string, 'DecisionId'>;
export type ApprovalId = Brand<string, 'ApprovalId'>;
export type SourceId = Brand<string, 'SourceId'>;
/** Brand a value at a boundary where it has already been validated. */
export declare function brand<T, K extends string>(value: T): Brand<T, K>;
export declare const triggerId: (value: string) => TriggerId;
export declare const threadKey: (value: string) => ThreadKey;
export declare const ticketId: (value: string) => TicketId;
export declare const assignmentId: (value: string) => AssignmentId;
export declare const evalId: (value: string) => EvalId;
export declare const decisionId: (value: string) => DecisionId;
export declare const approvalId: (value: string) => ApprovalId;
export declare const sourceId: (value: string) => SourceId;
export declare function unbrand<T>(value: Brand<T, string>): T;
