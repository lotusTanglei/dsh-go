/** Clone a domain value and recursively freeze object graphs at the pure-domain boundary. */
export declare function snapshot<T>(value: T): T;
