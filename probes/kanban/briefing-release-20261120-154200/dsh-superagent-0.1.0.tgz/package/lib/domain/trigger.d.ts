import type { SourceId, ThreadKey, TriggerId, EvalId, DecisionId, TicketId, AssignmentId } from './ids.js';
export type Trust = 'human' | 'bot' | 'ci' | 'system';
export type Addressed = 'direct' | 'mention' | 'none';
export interface Actor {
    readonly id: string;
    readonly source: SourceId;
    readonly bot: boolean;
}
export interface Trigger {
    readonly id: TriggerId;
    readonly source: SourceId;
    readonly externalId: string;
    readonly threadKey: ThreadKey;
    readonly actor: Actor;
    readonly text: string;
    readonly at: number;
    readonly trust: Trust;
    readonly addressed: Addressed;
    readonly raw: unknown;
}
export interface TriggerDisposition {
    readonly triggerId: TriggerId;
    readonly at: number;
    readonly filtered?: Reason;
    readonly evalId?: EvalId;
    readonly decisionId?: DecisionId;
    readonly ticketId?: TicketId;
    readonly deliveredTo?: AssignmentId;
    readonly requeued?: boolean;
    readonly ackedBy?: string;
}
export type Reason = 'not-addressed' | 'untrusted' | 'suspicious' | 'paused' | 'queue-full' | string;
export interface TriggerInput {
    readonly source: SourceId;
    readonly externalId: string;
    readonly threadKey?: ThreadKey;
    readonly threadRef?: {
        readonly source: SourceId;
        readonly kind: string;
        readonly id: string;
    };
    readonly actor: Actor;
    readonly text: string;
    readonly at: number;
    readonly trust: Trust;
    readonly addressed: Addressed;
    readonly raw: unknown;
}
/** Construct an immutable trigger. The id is the source/external id deduplication key. */
export declare function createTrigger(input: TriggerInput): Trigger;
export declare function triggerDedupKey(trigger: Pick<Trigger, 'source' | 'externalId'>): string;
export declare function validateTrigger(trigger: Trigger): boolean;
