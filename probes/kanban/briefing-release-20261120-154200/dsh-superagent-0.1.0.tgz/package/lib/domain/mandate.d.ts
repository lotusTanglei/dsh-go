import type { Actor } from './trigger.js';
import type { Decision, Strength } from './eval.js';
import type { Policy } from './policy.js';
export type MandateVia = 'addressed' | 'followup' | 'listed' | 'admission';
export interface Mandate {
    readonly strength: Strength;
    readonly policyVersion: string;
    readonly grantedBy: Actor;
    readonly at: number;
    readonly scope: string;
    readonly via: MandateVia;
    readonly rules: readonly string[];
}
export interface RevalidationResult {
    readonly valid: boolean;
    readonly mandate: Mandate;
    readonly reason?: string;
}
/** Only an accept decision with the current policy may create a mandate. */
export declare function canGrant(decision: Pick<Decision, 'kind' | 'policyVersion' | 'strength'>, policy: Pick<Policy, 'version'>): boolean;
export declare function grantMandate(input: Omit<Mandate, 'policyVersion' | 'strength'> & {
    readonly decision: Pick<Decision, 'kind' | 'policyVersion' | 'strength'>;
}, policy: Pick<Policy, 'version'>): Mandate;
/** Revocation is only legal when the caller has an explicit human-stop action. */
export interface HumanStop {
    readonly trust: string;
    readonly explicitStop: boolean;
}
export declare function canWithdraw(trigger: HumanStop): boolean;
export declare function withdrawMandate(mandate: Mandate, trigger: HumanStop): undefined;
/** Revalidation never mutates an existing mandate; it reports whether policy still permits it. */
export declare function revalidate(mandate: Mandate, policy: Pick<Policy, 'version' | 'acceptedSources'>, source?: Mandate['grantedBy']['source']): RevalidationResult;
