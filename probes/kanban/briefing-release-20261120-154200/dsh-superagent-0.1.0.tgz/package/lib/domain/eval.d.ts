import type { DecisionId, EvalId, ThreadKey, TriggerId, TicketId } from './ids.js';
import type { Policy } from './policy.js';
export type EvalState = 'running' | 'decided' | 'expired';
export type DecisionKind = 'accept' | 'ignore' | 'stop' | 'unavailable';
export type Strength = 'explicit' | 'inferred';
export interface Eval {
    readonly id: EvalId;
    readonly threadKey: ThreadKey;
    readonly policyVersion: string;
    readonly triggerIds: readonly TriggerId[];
    readonly startedAt: number;
    readonly deadline: number;
    readonly state: EvalState;
    readonly requeues: number;
}
export interface Decision {
    readonly id: DecisionId;
    readonly evalId: EvalId;
    readonly threadKey: ThreadKey;
    readonly triggerIds: readonly TriggerId[];
    readonly policyVersion: string;
    readonly kind: DecisionKind;
    readonly reason: string;
    readonly strength: Strength;
    readonly ticketId?: TicketId;
    readonly at: number;
}
export declare function createEval(input: Omit<Eval, 'state' | 'requeues'>): Eval;
export declare function decideEval(evaluation: Eval, decision: Omit<Decision, 'evalId' | 'threadKey' | 'triggerIds' | 'policyVersion'>, policy: Policy): Decision;
export declare function markDecided(evaluation: Eval, policyVersion: string): Eval;
export declare function expireEval(evaluation: Eval, now: number): Eval;
export declare function requeueEval(evaluation: Eval, now: number, timeoutMs: number, maxRequeues: number): Eval;
export declare function unavailableDecision(evaluation: Eval, at: number, reason?: string): Decision;
