import type { SourceId } from './ids.js';
export type AcceptMode = 'off' | 'observe' | 'auto';
export type ConfirmMode = 'always' | 'when-ambiguous' | 'never';
export type BotPolicy = 'deny' | 'infer';
export interface Budgets {
    readonly maxWorkers: number;
    readonly maxStepsPerTicket: number;
    readonly maxTokensPerTicket: number;
    readonly maxDurationMsPerTicket: number;
    readonly maxRetries: number;
    readonly queueLimit: number;
    readonly watchdog: {
        readonly intervalMs: number;
        readonly stallMs: number;
        readonly repeatCallThreshold: number;
    };
}
export interface Policy {
    readonly version: string;
    readonly acceptedSources: readonly SourceId[];
    readonly acceptMode: AcceptMode;
    readonly confirm: ConfirmMode;
    readonly bots: BotPolicy;
    readonly paused: boolean;
    readonly evalTimeoutMs: number;
    readonly budgets: Budgets;
}
/** SHA-256 of canonical (sorted-key) policy JSON. */
export declare function policyVersion(input: Omit<Policy, 'version'> | Policy): string;
export declare function createPolicy(input: Omit<Policy, 'version'>): Policy;
export declare function isPolicyVersion(policy: Policy, version: string): boolean;
