import type { Assignment } from '../domain/assignment.js';
import type { Ticket, TicketBrief } from '../domain/ticket.js';
/** Structural subset of DSH's activation result. */
export interface ActivationResult {
    readonly structured?: unknown;
    readonly [key: string]: unknown;
}
/** Structural activation returned by ctx.subagents.startActivation. */
export interface WorkerActivation {
    readonly id?: string;
    readonly sessionId?: string;
    readonly childSessionId?: string;
    readonly childId?: string;
    readonly agent?: object;
    readonly result: Promise<ActivationResult>;
    dispose?(): void | Promise<void>;
}
/** JSON schema shape accepted by DSH; kept structural to avoid a runtime dependency. */
export interface ObjectJsonSchema {
    readonly type: 'object';
    readonly properties: Readonly<Record<string, unknown>>;
    readonly required: readonly string[];
    readonly additionalProperties?: boolean;
}
export interface SpawnActivationInput {
    readonly provider: 'spawn';
    readonly delivery: 'caller';
    readonly cwd: string;
    readonly agentPreset: string;
    readonly outputSchema: ObjectJsonSchema;
    readonly label: string;
    readonly name?: string;
    readonly childId?: string;
    readonly signal?: AbortSignal;
    readonly prompt?: readonly Record<string, unknown>[];
    readonly parent?: {
        readonly id: string;
        readonly [key: string]: unknown;
    };
    readonly agentOptions?: Record<string, unknown>;
}
/** Injectable adapter over ctx.subagents.startActivation. */
export interface WorkerGuardSnapshot {
    readonly sessionId: string;
    readonly binding: {
        readonly assignmentId: Assignment['id'];
        readonly ticketId: Ticket['id'];
    };
    readonly ticket: Pick<Ticket, 'id' | 'state' | 'currentAssignment'>;
    readonly assignment: Pick<Assignment, 'id' | 'ticketId' | 'sessionId' | 'state'>;
}
export interface WorkerBindingRegistrar {
    bindWorker(agent: object, snapshot: WorkerGuardSnapshot): void;
    unbindWorker(agent: object): void;
}
export interface Spawner {
    startActivation(input: SpawnActivationInput): Promise<WorkerActivation>;
    bindWorker?(activation: WorkerActivation, snapshot: WorkerGuardSnapshot): void;
    unbindWorker?(activation: WorkerActivation): void;
}
/** Input kept domain-structural and free of DSH types. */
export interface WorkerInput {
    readonly ticket: Pick<Ticket, 'id' | 'title' | 'brief' | 'workdir'>;
    readonly assignment: Pick<Assignment, 'id' | 'ticketId' | 'sessionId'>;
    readonly brief: TicketBrief;
    readonly workdir: string;
    readonly preset: string;
    readonly parent?: {
        readonly id: string;
        readonly [key: string]: unknown;
    };
    readonly signal?: AbortSignal;
    readonly agentOptions?: Record<string, unknown>;
    readonly correction?: string;
}
export interface WorkerHandle {
    readonly activation: WorkerActivation;
    readonly sessionId?: string;
    readonly result: Promise<ActivationResult>;
    dispose(): Promise<void>;
}
/** Structured report schema enforced by the DSH spawn adapter. */
export declare const REPORT_OUTPUT_SCHEMA: ObjectJsonSchema;
/**
 * Start one worker activation through the injected Spawner. The adapter is the
 * only place that knows DSH's provider/delivery/cwd/outputSchema contract.
 */
export declare function startWorker(input: WorkerInput, spawner: Spawner): Promise<WorkerHandle>;
/** Alias retained for callers that use the docs' shorter `start` name. */
export declare const start: typeof startWorker;
/** Adapter helper for a real DSH context; no DSH package import is needed. */
export declare function spawnerFromContext(context: {
    readonly subagents: {
        startActivation(input: SpawnActivationInput): Promise<WorkerActivation>;
    };
    readonly agents?: {
        get(id: string): object | undefined;
    };
    readonly superagentRoleGuard?: WorkerBindingRegistrar;
}): Spawner;
