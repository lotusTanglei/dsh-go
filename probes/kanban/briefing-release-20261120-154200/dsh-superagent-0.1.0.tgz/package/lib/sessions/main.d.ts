/** Host session id is intentionally structural: no DSH package is required. */
export type SessionId = string;
export interface MainAgent {
    readonly sessionId?: string;
    inject(message: string): void | Promise<void>;
    followup(message: string): void | Promise<void>;
}
export interface MainKv {
    get(key: unknown): unknown;
    insertOrIgnore?(row: {
        readonly k: string;
        readonly v: string;
    }): void;
    /** Optional replacement operation supplied by a host/store adapter. */
    upsert?(row: {
        readonly k: string;
        readonly v: string;
    }): void;
    replace?(row: {
        readonly k: string;
        readonly v: string;
    }): void;
    set?(key: string, value: string): void;
    update?(key: string, value: string): void;
    delete?(key: unknown): void;
}
/** Narrow injected context; callers adapt DSH services to this shape. */
export interface MainSessionContext {
    /** Optional atomic binding writer supplied by the host/store adapter. */
    readonly setMainSessionId?: (sessionId: string) => void;
    readonly kv?: MainKv;
    readonly store?: {
        readonly repos?: {
            readonly kv?: MainKv;
        };
    };
    readonly sessions: {
        get?(sessionId: string): unknown;
        create?(sessionId?: string, options?: unknown): unknown;
    };
    readonly agents: {
        get?(sessionId: string): MainAgent | undefined;
        resume?(input: {
            resumeSessionId: string;
        }): Promise<MainAgent>;
        create?(input: {
            sessionId: string;
            meta?: Record<string, unknown>;
        }): Promise<MainAgent>;
    };
    readonly on?: (event: string, listener: (...args: unknown[]) => void) => unknown;
}
export interface MainSessionConfig {
    readonly mainSessionId?: string;
    readonly routerPreset?: string;
}
/** Ensure the configured, persisted, or newly-created Router session is available. */
export declare function ensureMainSession(context: MainSessionContext, config?: MainSessionConfig): Promise<SessionId>;
export declare function ensureMainSession(config: MainSessionConfig, context: MainSessionContext): Promise<SessionId>;
/** Inject context without waking a model turn. */
export declare function injectContext(context: MainSessionContext, sessionId: SessionId, text: string): void;
/** Notify Router and wake one model turn. */
export declare function notifyRouter(context: MainSessionContext, sessionId: SessionId, text: string): void;
/** Build a context that forwards a session disposal event to KV cleanup. */
export declare function watchMainSessionDisposal(context: MainSessionContext): () => void;
/** Factory form for callers that want the docs' config-first method shape. */
export declare function createMainSessions(context: MainSessionContext): {
    ensureMainSession(config?: MainSessionConfig): Promise<SessionId>;
    injectContext(sessionId: SessionId, text: string): void;
    notifyRouter(sessionId: SessionId, text: string): void;
};
