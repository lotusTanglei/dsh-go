import type { Store } from '../store/index.js';
import type { Policy } from '../domain/policy.js';
import type { Eval, Decision, DecisionKind, Strength } from '../domain/eval.js';
import type { EvalId, ThreadKey, TriggerId, DecisionId, TicketId } from '../domain/ids.js';
import type { TicketBrief } from '../domain/ticket.js';
import type { Mandate } from '../domain/mandate.js';
export interface EvalStartOptions {
    readonly now?: () => number;
    readonly timeoutMs?: number;
    readonly evalId?: EvalId;
    readonly maxRequeues?: number;
}
export interface EvalDecisionInput {
    readonly id?: DecisionId;
    readonly kind: DecisionKind;
    readonly reason: string;
    readonly strength: Strength;
    readonly at?: number;
    readonly ticket?: {
        readonly id?: TicketId;
        readonly title: string;
        readonly brief: TicketBrief;
        readonly mandate: Mandate;
        readonly workdir: string;
    };
}
export interface EvalResult {
    readonly evaluation: Eval;
    readonly decision: Decision;
    readonly ticketId?: TicketId;
}
export interface EvaluationContext {
    readonly evaluation: Eval;
    readonly triggerIds: readonly TriggerId[];
    readonly triggers: readonly Record<string, unknown>[];
    readonly signal?: AbortSignal;
}
export type Evaluation = (context: EvaluationContext) => Promise<EvalDecisionInput> | EvalDecisionInput;
/** Claim one running Eval for a Thread. Concurrent callers are serialized by Store.transaction. */
export declare function startEval(store: Store, threadKey: ThreadKey, policy: Pick<Policy, 'version' | 'evalTimeoutMs'> & Partial<Pick<Policy, 'paused'>>, options?: EvalStartOptions): Eval | undefined;
/** Return a durable Eval snapshot. */
export declare function getEval(store: Store, id: EvalId): Eval | undefined;
/**
 * Apply a Decision and finish the Eval. Accept commits decision + ticket + mandate +
 * subscription + trigger dispositions in one SQLite transaction.
 */
export declare function settleEval(store: Store, evaluationId: EvalId, input: EvalDecisionInput, policy: Pick<Policy, 'version'>, options?: {
    readonly now?: () => number;
}): EvalResult;
/** Evaluate one Thread through a caller-supplied policy/model adapter. */
export declare function evaluateThread(store: Store, threadKey: ThreadKey, policy: Pick<Policy, 'version' | 'evalTimeoutMs'> & Partial<Pick<Policy, 'paused'>>, evaluator: Evaluation, options?: EvalStartOptions): Promise<EvalResult | undefined>;
/** Expire a running Eval and, while under the retry budget, put its triggers back in pending. */
export declare function expireAndRequeue(store: Store, evaluationId: EvalId, policy: Pick<Policy, 'evalTimeoutMs'> & {
    readonly maxRequeues?: number;
}, options?: EvalStartOptions): Eval | undefined;
export declare const startEvaluation: typeof startEval;
export declare const decideEvaluation: typeof settleEval;
export declare const reconcileEval: typeof expireAndRequeue;
