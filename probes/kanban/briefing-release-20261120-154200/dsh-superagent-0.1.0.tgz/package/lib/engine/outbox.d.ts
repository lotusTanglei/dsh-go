import type { Store } from '../store/index.js';
import type { ChannelKind, OutboundKind, Outbound } from '../domain/outbound.js';
import type { ThreadKey, TicketId } from '../domain/ids.js';
export interface OutboxMessage {
    readonly id?: string;
    readonly ticketId?: TicketId;
    readonly threadKey: ThreadKey;
    readonly channel: ChannelKind;
    readonly kind: OutboundKind;
    readonly body: string;
    readonly idempotencyKey: string;
    readonly nextAt?: number;
}
export interface OutboxSender {
    send(message: Pick<Outbound, 'channel' | 'threadKey' | 'body' | 'idempotencyKey'>): Promise<void>;
}
export interface OutboxOptions {
    readonly now?: () => number;
    readonly maxRetries?: number;
    readonly backoffMs?: number;
    readonly backoffMaxMs?: number;
    readonly onDropped?: (outbound: Outbound, error?: string) => void;
}
export interface OutboxRunResult {
    readonly attempted: number;
    readonly sent: number;
    readonly retried: number;
    readonly dropped: number;
    readonly pending: number;
}
/** Enqueue an Outbox row. Duplicate idempotency keys are a successful no-op. */
export declare function enqueueOutbox(store: Store, message: OutboxMessage, options?: Pick<OutboxOptions, 'now'>): Outbound;
/** Serialize drains against one Store so concurrent host ticks cannot double-send a row. */
export declare function drainOutbox(store: Store, sender: OutboxSender, options?: OutboxOptions): Promise<OutboxRunResult>;
/** Requeue pending messages after a restart without touching their attempt count. */
export declare function reconcileOutbox(store: Store, now?: number): number;
export declare const processOutbox: typeof drainOutbox;
export declare const sendOutbox: typeof drainOutbox;
