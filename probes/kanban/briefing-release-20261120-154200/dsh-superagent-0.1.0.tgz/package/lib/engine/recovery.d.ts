import type { Store } from '../store/index.js';
import type { ThreadKey } from '../domain/ids.js';
export interface RecoveryPorts {
    /** Return session ids which are alive in the host. */
    readonly liveSessionIds?: () => ReadonlySet<string> | Promise<ReadonlySet<string>>;
    /** Requeue a pending trigger to the host queue; persistence remains source of truth. */
    readonly enqueue?: (threadKey: ThreadKey, triggerId: import('../domain/ids.js').TriggerId, seq: number) => void | Promise<void>;
    /** Notify an operator when an outbox row reaches dead-letter. */
    readonly warn?: (message: string) => void;
}
export interface RecoveryOptions {
    readonly now?: () => number;
    readonly evalTimeoutMs?: number;
    readonly maxEvalRequeues?: number;
}
export interface RecoveryReport {
    readonly assignments: {
        readonly scanned: number;
        readonly orphaned: number;
    };
    readonly outbox: {
        readonly requeued: number;
    };
    readonly evals: {
        readonly scanned: number;
        readonly expired: number;
        readonly requeued: number;
        readonly unavailable: number;
    };
    readonly queue: {
        readonly scanned: number;
        readonly requeued: number;
    };
}
/** Startup reconciliation in the fixed order required by 003-F8/DEV-ALL §3.9. */
export declare function reconcile(store: Store, ports?: RecoveryPorts, options?: RecoveryOptions): Promise<RecoveryReport>;
export declare const recover: typeof reconcile;
export declare const startupRecovery: typeof reconcile;
