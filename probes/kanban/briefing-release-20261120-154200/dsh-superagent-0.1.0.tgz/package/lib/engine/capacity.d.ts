import type { Store } from '../store/index.js';
/** Single durable union shared by ingress reservations and source intake. */
export declare function queueCapacityUsed(store: Store, admittingExternalId?: string): number;
