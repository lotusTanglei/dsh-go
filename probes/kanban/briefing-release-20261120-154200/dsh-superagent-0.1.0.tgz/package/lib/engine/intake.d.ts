import type { Store } from '../store/index.js';
import type { Policy } from '../domain/policy.js';
import type { Trigger, TriggerDisposition } from '../domain/trigger.js';
import type { AssignmentId, TicketId, TriggerId } from '../domain/ids.js';
export type IntakeStatus = 'accepted' | 'duplicate' | 'filtered' | 'subscription' | 'delivered' | 'rejected';
export interface IntakeResult {
    readonly status: IntakeStatus;
    readonly triggerId: TriggerId;
    readonly threadKey: string;
    readonly seq?: number;
    readonly reason?: string;
    readonly ticketId?: TicketId;
    readonly assignmentId?: AssignmentId;
    readonly position?: number;
}
export interface IntakeOptions {
    readonly policy?: Pick<Policy, 'acceptedSources' | 'bots' | 'paused' | 'budgets'>;
    readonly queueLimit?: number;
    readonly paused?: boolean;
    readonly now?: () => number;
    /** Trusted Host-only routing intent; never derived from message text. */
    readonly targetTicketId?: TicketId;
}
export declare function ingestTrigger(store: Store, trigger: Trigger, options?: IntakeOptions): IntakeResult;
export declare const intakeTrigger: typeof ingestTrigger;
export declare const ingest: typeof ingestTrigger;
export declare function readDisposition(store: Store, triggerId: TriggerId): TriggerDisposition | undefined;
export declare function ackDelivery(store: Store, triggerId: TriggerId, assignmentId: AssignmentId, at?: number): boolean;
