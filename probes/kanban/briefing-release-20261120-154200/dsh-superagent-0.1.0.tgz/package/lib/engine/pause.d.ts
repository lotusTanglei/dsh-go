import type { Store } from '../store/index.js';
import type { ThreadKey } from '../domain/ids.js';
export interface PauseOptions {
    readonly now?: () => number;
    readonly actor?: string;
}
export interface PauseResult {
    readonly paused: boolean;
    readonly threads: number;
    readonly pending: number;
}
/** Set the global pause flag and mirror it onto existing Threads. Triggers remain durable. */
export declare function setPaused(store: Store, paused: boolean, options?: PauseOptions): PauseResult;
export declare function isPaused(store: Store): boolean;
/** Pause a single Thread, preserving pending Trigger order. */
export declare function setThreadPaused(store: Store, threadKey: ThreadKey, paused: boolean, options?: PauseOptions): boolean;
/** Return pending Trigger ids in their durable sequence order. */
export declare function pendingTriggers(store: Store, threadKey?: ThreadKey): TriggerKey[];
export interface TriggerKey {
    readonly threadKey: ThreadKey;
    readonly triggerId: import('../domain/ids.js').TriggerId;
    readonly seq: number;
}
export declare const pause: typeof setPaused;
export declare const resume: (store: Store, options?: PauseOptions) => PauseResult;
