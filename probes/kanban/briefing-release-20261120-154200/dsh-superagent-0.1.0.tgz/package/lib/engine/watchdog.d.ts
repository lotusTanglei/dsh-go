import type { SessionQuery } from '../sessions/watchdog.js';
export interface WatchdogAssignment {
    readonly assignmentId: string;
    readonly ticketId: string;
    readonly sessionId: string;
    readonly state: 'pending' | 'running' | 'ended';
    readonly startedAt: number;
    readonly lastProgressAt: number;
    readonly steps: number;
    readonly tokens: number;
    readonly waitingSince?: number;
    readonly briefGoal: string;
}
export interface WatchdogMetrics {
    readonly at: number;
    readonly lastProgressAt: number;
    readonly steps: number;
    readonly tokens: number;
    readonly stallMs: number;
    readonly durationMs: number;
    readonly repeatedCalls: number;
    readonly repeatedCall?: string;
    readonly waitingMs: number;
}
export interface WatchdogState {
    stallAt?: number;
    stallStage?: number;
    repeatSignature?: string;
    budgetStage?: number;
    deviationAt?: number;
    waitingAt?: number;
}
export type WatchdogAction = 'nudge' | 'steer' | 'cancel' | 'escalate';
export interface WatchdogAudit {
    readonly assignmentId: string;
    readonly ticketId: string;
    readonly sessionId: string;
    readonly action: WatchdogAction;
    readonly rule: string;
    readonly message: string;
    readonly metrics: WatchdogMetrics;
    readonly state: WatchdogState;
    readonly outcome: 'requested' | 'completed' | 'failed';
}
export interface WatchdogOptions {
    readonly stallMs: number;
    readonly repeatCallThreshold: number;
    readonly waitingHumanMs: number;
    readonly maxSteps: number;
    readonly maxTokens: number;
    readonly maxDurationMs: number;
    readonly deviationIntervalMs: number;
}
export interface WatchdogPorts {
    readonly sessionQuery: SessionQuery;
    assignments(): Promise<readonly WatchdogAssignment[]>;
    state?(id: string): WatchdogState | undefined;
    nudge(sessionId: string, message: string): Promise<void>;
    steer(sessionId: string, message: string): Promise<void>;
    cancel(assignment: WatchdogAssignment, reason: string): Promise<void>;
    escalate(assignment: WatchdogAssignment, message: string): Promise<void>;
    audit(record: WatchdogAudit): void | Promise<void>;
    deviation?(assignment: WatchdogAssignment, metrics: WatchdogMetrics): Promise<string | undefined>;
}
/** Read-only metrics: tool calls alone never count as progress. */
export declare function measureWorker(assignment: WatchdogAssignment, events: readonly unknown[], now: number): WatchdogMetrics;
export declare function createWatchdog(ports: WatchdogPorts, options: WatchdogOptions): {
    tick(now?: number): Promise<void>;
};
