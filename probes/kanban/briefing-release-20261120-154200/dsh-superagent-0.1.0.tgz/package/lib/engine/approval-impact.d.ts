export declare function approvalImpact(kind: unknown, payload: unknown): {
    reviewable: boolean;
    reason?: string;
    details: Record<string, string | number>;
};
