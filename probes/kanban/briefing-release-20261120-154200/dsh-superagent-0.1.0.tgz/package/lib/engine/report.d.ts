import type { TicketBrief } from '../domain/ticket.js';
export type ReportState = 'progress' | 'ready' | 'blocked' | 'failed';
export type AcceptanceResult = 'passed' | 'failed' | 'not-run';
export interface ReportAcceptance {
    readonly id: string;
    readonly result: AcceptanceResult;
    readonly evidence: string;
}
export interface Report {
    readonly state: ReportState;
    readonly done: readonly string[];
    readonly todo: readonly string[];
    readonly changedPaths: readonly string[];
    readonly acceptance: readonly ReportAcceptance[];
    readonly risks: readonly string[];
    readonly needHuman: readonly string[];
}
export type ReportInput = Report;
export interface ReportValidation {
    readonly valid: boolean;
    readonly errors: readonly string[];
}
/**
 * Explain every schema/acceptance mismatch without mutating either input.
 * `not-run` is intentionally rejected: a result must provide evidence for
 * every criterion before the router can consume it.
 */
export declare function inspectReport(value: unknown, brief: TicketBrief): ReportValidation;
/** Runtime type guard used by Router/dispatch boundaries. */
export declare function validateReport(value: unknown, brief: TicketBrief): value is Report;
/** Build an immutable report and apply the same boundary checks as parsing. */
export declare function generateReport(input: ReportInput, brief: TicketBrief): Report;
/**
 * F4's narrow retry policy: only a first `ready` result with failed criteria
 * gets one correction attempt. Missing/not-run reports are also retryable when
 * inspected directly; no caller may obtain a second retry.
 */
export declare function shouldRetryReport(value: unknown, brief: TicketBrief, retryCount: number): boolean;
export declare const validateStructuredReport: typeof validateReport;
