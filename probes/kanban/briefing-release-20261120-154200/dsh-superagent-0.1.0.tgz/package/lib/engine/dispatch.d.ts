import { type Assignment } from '../domain/assignment.js';
import type { AssignmentId, TicketId } from '../domain/ids.js';
import { type Ticket } from '../domain/ticket.js';
import type { Trigger } from '../domain/trigger.js';
import { startWorker, type Spawner } from '../sessions/worker.js';
import { type Report } from './report.js';
export type { Spawner } from '../sessions/worker.js';
/** Router has already accepted/admitted this trigger and supplied its open ticket and pending assignment. */
export interface AcceptedDispatch {
    readonly ticket: Ticket;
    readonly assignment: Assignment;
}
export interface DispatchOptions extends Pick<Parameters<typeof startWorker>[0], 'parent' | 'signal'> {
    readonly spawner: Spawner;
    readonly workRoot: string;
    readonly workerPreset: string;
    readonly accept: (trigger: Trigger) => AcceptedDispatch | undefined | Promise<AcceptedDispatch | undefined>;
    readonly now: () => number;
}
/** Correlation stays outside the worker-controlled report body. */
export interface RouterReport {
    readonly ticketId: TicketId;
    readonly assignmentId: AssignmentId;
    readonly report: Report;
}
/**
 * Narrow F4 seam: Router acceptance -> one worker per accepted ticket -> validated reports.
 * This does not evaluate triggers, persist state, retry, or decide ticket completion (P3).
 * The caller supplies the Router's acceptance decision; undefined means conversational/ignored.
 */
export declare function dispatchTriggers(triggers: readonly Trigger[], options: DispatchOptions): Promise<readonly RouterReport[]>;
