import type { AcceptanceCriterion, TicketBrief } from '../domain/ticket.js';
/** Input accepted by the pure brief constructor. All TicketBrief fields are explicit. */
export type TicketBriefInput = {
    readonly goal: string;
    readonly scope: {
        readonly repo: string;
        readonly subdirs: readonly string[];
    };
    readonly base: {
        readonly ref: string;
        readonly requireCleanTree: boolean;
    };
    readonly allowWrite: readonly string[];
    readonly denyWrite: readonly string[];
    readonly runtime: string;
    readonly acceptance: readonly AcceptanceCriterion[];
    readonly outOfScope: readonly string[];
    readonly blockers: readonly string[];
    readonly firstAction: string;
    readonly approvalsRequired: readonly string[];
};
/** The eleven concrete keys in the rev2 TicketBrief contract. */
export declare const TICKET_BRIEF_FIELDS: readonly ["goal", "scope", "base", "allowWrite", "denyWrite", "runtime", "acceptance", "outOfScope", "blockers", "firstAction", "approvalsRequired"];
/**
 * Build an immutable brief without adding policy or side effects.
 * Unknown values belong in the input (for example `blockers: ['unknown']`),
 * rather than being silently invented by this constructor.
 */
export declare function generateBrief(input: TicketBriefInput): TicketBrief;
/** Runtime type guard for the pure brief contract. */
export declare function validateBrief(value: unknown): value is TicketBrief;
/** Throwing counterpart useful at a boundary where invalid input is exceptional. */
export declare function assertBrief(value: unknown): asserts value is TicketBrief;
export declare const generateTicketBrief: typeof generateBrief;
export declare const validateTicketBriefInput: typeof validateBrief;
