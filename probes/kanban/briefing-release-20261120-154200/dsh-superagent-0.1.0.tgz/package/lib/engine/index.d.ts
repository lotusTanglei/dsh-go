import type { Store } from '../store/index.js';
import type { Trigger } from '../domain/trigger.js';
import type { Policy } from '../domain/policy.js';
import type { ThreadKey, EvalId } from '../domain/ids.js';
import { type IntakeResult } from './intake.js';
import { type Evaluation, type EvalResult } from './eval.js';
import { type OutboxMessage, type OutboxOptions, type OutboxRunResult, type OutboxSender } from './outbox.js';
import { type PauseResult } from './pause.js';
import { type RecoveryPorts, type RecoveryReport } from './recovery.js';
export interface EngineConfig {
    readonly policy: Pick<Policy, 'version' | 'evalTimeoutMs' | 'acceptedSources' | 'bots' | 'paused' | 'budgets'>;
    readonly queueLimit?: number;
    readonly maxEvalRequeues?: number;
    readonly outbox?: OutboxOptions;
}
export interface EnginePorts extends RecoveryPorts {
    readonly sender?: OutboxSender;
    readonly evaluate?: Evaluation;
}
/** Small host-facing facade; all state is persisted in the supplied Store. */
export declare function createEngine(store: Store, config: EngineConfig, ports?: EnginePorts): {
    ingest(trigger: Trigger, scoped?: {
        targetTicketId: import("../domain/ids.js").TicketId;
    }): IntakeResult;
    ackDelivery(triggerId: import("../domain/ids.js").TriggerId, assignmentId: import("../domain/ids.js").AssignmentId): boolean;
    evaluate(threadKey: ThreadKey): Promise<EvalResult | undefined>;
    enqueue(message: OutboxMessage): import("../index.js").Outbound;
    drainOutbox(): Promise<OutboxRunResult>;
    pause(): PauseResult;
    resume(): PauseResult;
    paused(): boolean;
    expireEval(id: EvalId): import("../index.js").Eval | undefined;
    recover(): Promise<RecoveryReport>;
};
export * from './intake.js';
export * from './eval.js';
export * from './outbox.js';
export * from './pause.js';
export * from './recovery.js';
