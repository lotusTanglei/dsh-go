export declare const JSON_SCHEMA_VERSION: 1;
/** Privacy sinks hide user paths; execution contracts must retain their exact local paths. */
export declare function redact(value: unknown): unknown;
/** Contracts reject credentials/URLs rather than mutate them; local repo paths remain legal. */
export declare function hasSensitiveContractData(value: unknown): boolean;
export declare function encodeJson(value: unknown, shouldRedact?: boolean): string;
export declare function decodeJson<T = unknown>(raw: string): T;
