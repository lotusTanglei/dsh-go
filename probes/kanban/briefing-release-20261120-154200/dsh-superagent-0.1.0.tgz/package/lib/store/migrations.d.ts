import type { Migration } from './migrations/001_init.js';
export { m001 } from './migrations/001_init.js';
export type { Migration } from './migrations/001_init.js';
export declare const migrations: readonly Migration[];
