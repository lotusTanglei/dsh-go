import type { DatabaseSync } from 'node:sqlite';
export interface Row {
    readonly [key: string]: unknown;
}
export interface TableRepo<T extends Row = Row> {
    insert(row: T): void;
    insertOrIgnore(row: T): void;
    get(key: unknown): T | undefined;
    all(): T[];
    updateByState(key: unknown, expectedState: string, nextState: string, extra?: Partial<T>): boolean;
}
export type TableName = 'source_instance' | 'trigger' | 'trigger_disposition' | 'thread' | 'thread_trigger' | 'eval' | 'decision' | 'ticket' | 'assignment' | 'thread_subscription' | 'approval' | 'outbound' | 'side_effect' | 'audit' | 'kv';
export type Repositories = {
    readonly [K in TableName]: TableRepo;
};
export declare const TABLE_DEFS: Record<string, {
    columns: readonly string[];
    pk: readonly string[];
    state?: string;
}>;
export declare function createRepo(db: DatabaseSync, table: string, def: {
    columns: readonly string[];
    pk: readonly string[];
    state?: string;
}): TableRepo;
