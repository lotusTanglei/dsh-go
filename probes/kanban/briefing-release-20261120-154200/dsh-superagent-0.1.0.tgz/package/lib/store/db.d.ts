import { DatabaseSync } from 'node:sqlite';
import { type Migration } from './migrations.js';
import { type Repositories } from './repos/index.js';
export interface OpenStoreOptions {
    dbPath: string;
    lockPath?: string;
    now?: () => number;
    migrations?: readonly Migration[];
    staleLockMs?: number;
    busyTimeoutMs?: number;
}
export interface Store {
    readonly db: DatabaseSync;
    readonly repos: Repositories;
    readonly version: number;
    readonly migrateVersion: number;
    transaction<T>(fn: (db: DatabaseSync) => T): T;
    close(): void;
}
export declare function openStore(options: OpenStoreOptions): Store;
