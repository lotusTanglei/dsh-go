import type { DatabaseSync } from 'node:sqlite';
export interface Migration {
    readonly version: number;
    readonly up: (db: DatabaseSync) => void;
}
/** Initial schema. Published migrations are append-only. */
export declare const m001: Migration;
