import type { RoleToolsContext } from './role-plugin.js';
export declare const inject: string[];
export declare function apply(_ctx: RoleToolsContext): () => void;
