import { type ToolDescriptor } from '../tools/descriptor.js';
export interface RoleToolsContext {
    readonly tools: {
        register(tool: unknown): unknown;
    };
    readonly superagentRuntime?: {
        invoke(name: string, args: unknown, execution: unknown): Promise<unknown>;
    };
    /** Late lookup avoids a Host → owned Router → Host required-service cycle. */
    get?(name: string): unknown;
}
export interface ToolHandlerMap {
    readonly [name: string]: ((args: unknown) => unknown | Promise<unknown>) | undefined;
}
/** Mount descriptors through DSH's defineTool/register contract in the current preset scope. */
export declare function registerRoleTools(context: RoleToolsContext, descriptors: readonly ToolDescriptor[], handlers?: ToolHandlerMap): () => void;
