/** Browser factory is bundled by scripts/build-client.mjs; React stays host-owned. */
export declare function createClientPlugin(React: any, dictionaries: Record<string, Record<string, unknown>>, channelDefinitions: readonly unknown[]): {
    inject: string[];
    apply(ctx: any): void;
};
