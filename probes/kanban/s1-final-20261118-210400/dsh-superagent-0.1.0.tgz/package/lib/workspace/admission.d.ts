import type { Store } from '../store/index.js';
import type { Policy } from '../domain/policy.js';
import type { TicketBrief } from '../domain/ticket.js';
import { type CommandRecord } from './commands.js';
export type AdmissionState = 'pending' | 'approved' | 'rejected' | 'superseded' | 'consumed';
export interface AdmissionDecision {
    readonly epoch: string;
    readonly requestId: string;
    readonly planId: string;
    readonly fingerprint: string;
    readonly decision: 'approve' | 'reject';
}
export interface AdmissionPlanDTO {
    readonly planId: string;
    readonly requestId: string;
    readonly epoch: string;
    readonly fingerprint: string;
    readonly state: AdmissionState;
    readonly createdAt: number;
    readonly expiresAt: number;
    readonly policyVersion: string;
    readonly brief: TicketBrief;
    readonly scope: TicketBrief['scope'];
    readonly acceptance: TicketBrief['acceptance'];
    readonly risk: Pick<TicketBrief, 'blockers' | 'approvalsRequired' | 'outOfScope'>;
    readonly ticketId?: string;
    readonly blockedReason?: string;
}
export interface AdmissionOptions {
    readonly policy: Policy;
    readonly workRoot: string;
    /** Lifetime of the pending human confirmation, not the Eval timeout. */
    readonly timeoutMs?: number;
    readonly paused?: () => boolean;
}
/**
 * One request, one current immutable single-ticket plan. No model, Worker, or service is
 * started here. The Host MUST authenticate the human and validate its current epoch
 * before decide(); matching a stored epoch alone is not authentication.
 */
export declare function createAdmissionService(store: Store, options: AdmissionOptions): {
    propose: (command: CommandRecord, brief: TicketBrief) => AdmissionPlanDTO;
    decide: (input: AdmissionDecision) => AdmissionPlanDTO;
    list: (epoch?: string) => AdmissionPlanDTO[];
    recover: () => AdmissionPlanDTO[];
};
