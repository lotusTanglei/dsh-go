import { wecomDocumentId, type WecomDocumentConfig } from '../config.js';
import { type ThreadKey } from '../domain/ids.js';
import { type Trigger } from '../domain/trigger.js';
import type { Channel, Source, ThreadContext, TriggerSink } from './types.js';
export type { WecomDocumentConfig } from '../config.js';
export type WecomDocumentStrike = 'yes' | 'no' | 'unknown';
export interface WecomDocumentRun {
    readonly text: string;
    readonly strike: WecomDocumentStrike;
    readonly style?: unknown;
}
export interface WecomDocumentCell {
    readonly column: string;
    readonly address: string;
    readonly text: string;
    readonly strike: WecomDocumentStrike;
    readonly runs?: readonly WecomDocumentRun[];
    readonly style?: unknown;
    readonly formula?: string;
}
export interface WecomDocumentImage {
    readonly address: string;
    readonly mimeType: string;
    readonly data: string;
    readonly sha256: string;
}
export interface WecomDocumentRow {
    readonly row: number;
    readonly cells: readonly WecomDocumentCell[];
    readonly images: readonly WecomDocumentImage[];
    readonly imagesComplete: boolean;
}
export interface WecomDocumentSnapshot {
    readonly schemaVersion: 1;
    readonly documentId: string;
    readonly sheetId: string;
    readonly sheetName: string;
    readonly range: string;
    readonly rows: readonly WecomDocumentRow[];
    readonly complete: boolean;
    readonly capabilities?: unknown;
    readonly warnings?: readonly string[];
    readonly docTitle?: string;
}
export interface WecomDocumentIssue {
    readonly code: string;
    readonly message: string;
    readonly row?: number;
    readonly column?: string;
}
export interface WecomDocumentEvidence {
    readonly documentId: string;
    readonly doc: string;
    readonly sheetId: string;
    readonly sheetName: string;
    readonly range: string;
    readonly row: WecomDocumentRow;
    readonly capabilities?: unknown;
    readonly warnings?: readonly string[];
    readonly docTitle?: string;
}
export interface WecomDocumentItem {
    /** Missing business IDs are retained as blocked evidence, never assigned a row-derived identity. */
    readonly itemKey: string | null;
    readonly revision: string;
    readonly configVersion: string;
    readonly title: string;
    readonly text: string;
    readonly eligible: boolean;
    readonly warnings: readonly string[];
    readonly evidence: WecomDocumentEvidence;
}
export interface WecomDocumentExtraction {
    readonly items: readonly WecomDocumentItem[];
    readonly issues: readonly WecomDocumentIssue[];
    readonly complete: boolean;
}
export interface WecomDocumentPorts {
    read(): Promise<WecomDocumentSnapshot>;
    persist?(items: readonly WecomDocumentItem[]): Promise<void>;
    /** Optional workspace session-channel adapter, never a document writer. */
    reply?: Channel['reply'];
    onError?(error: unknown): void;
}
export declare const canonicalDocumentId: typeof wecomDocumentId;
/** Every supplied configuration field participates, independent of object insertion order. */
export declare function configVersionOf(config: WecomDocumentConfig): string;
/** Pure manual source: no timer, tool lookup, network request, document write, or implicit read. */
export declare class WecomDocumentSource implements Source {
    private readonly ports;
    private readonly sink;
    readonly kind: "wecom-document";
    readonly attended = false;
    readonly id: import("../domain/ids.js").SourceId;
    readonly config: WecomDocumentConfig;
    readonly configVersion: string;
    private readonly documentId;
    private readonly bounds;
    private active;
    private stopping?;
    private scanFlight?;
    private readonly replies;
    private readonly history;
    private lastAt?;
    private error?;
    constructor(config: WecomDocumentConfig, ports: WecomDocumentPorts, sink: TriggerSink);
    private validate;
    /** Validation is deliberately not authentication, provenance verification, or trust elevation. */
    verify(input: unknown): Promise<boolean>;
    extract(input: unknown): WecomDocumentExtraction;
    private trigger;
    normalize(input: unknown): Promise<Trigger[]>;
    start(): Promise<void>;
    scan(): Promise<WecomDocumentExtraction>;
    stop(): Promise<void>;
    health(): Promise<{
        ok: boolean;
        lastAt: number | undefined;
        detail: string | undefined;
    }>;
    readThread(key: ThreadKey): Promise<ThreadContext>;
    reply(channel: Parameters<Channel['reply']>[0], key: ThreadKey, body: string, idemKey: string): Promise<void>;
    private report;
}
