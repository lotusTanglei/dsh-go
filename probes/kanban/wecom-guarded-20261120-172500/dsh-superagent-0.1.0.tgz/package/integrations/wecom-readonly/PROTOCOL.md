# WeCom read-only typed task snapshot, schemaVersion 1

## Scope and current verification

This integration reuses the installed `@local/dsh-wecom-readonly@1.0.0` local connector and its existing client, authentication owner, network allowlists, decoder and stdio transport. It adds no dependency, credential store, login flow, profile entry or remote decoder. No real document, login, live MCP business call or model request was used during development. The live connector files were changed under explicit implementation authorization; activation/restart/install was not performed.

The output is typed evidence, **not proof of full rendered formatting correctness**. Explicit raw font strike is decoded; unsupported inheritance, conditional/table/pivot/named-style resolution, missing/null fields and unverified references remain unknown. No production end-to-end/UI equivalence claim is made.

## Tool and Host API

Wire tool: `read_task_snapshot(doc: str, range: str, sheet: str | None = None, max_images: int = 3)`.

Host registry name: `mcp__wecom__read_task_snapshot` (the local `serverName=wecom`; raw names are used only by the existing client on the wire).

Installed DSH `0.2.2-rc.3` provides `ctx.tools`, not `ctx.mcp`:

```ts
ctx.tools.schemas(scope?, toolSet?)
ctx.tools.get(name, scope?, toolSet?)
ctx.tools.execute({
  calls: [{type: 'tool-call', id: ToolCallId(uniqueId),
           name: 'mcp__wecom__read_task_snapshot', arguments: JSON.stringify(args)}],
  signal, agent?, toolSet?, log?
}): Promise<ToolBatchResult>
```

Use the actual caller scope, cancellation and policy pipeline. Do not directly invoke `get(...).execute` or impersonate a PTC parent. A PTC executor rejects ordinary tool names as root calls. The deployed global native executor supports standalone service batches without an Agent or model completion. Inspect `results[i].result.isError` before reading canonical `result.value.structuredContent`.

Installed source evidence (under `/Applications/DeepSeek Harness.app/Contents/Resources/app.asar/dsh/node_modules/@deepseek-ai/`):

- `dsh-tools/src/index.ts:32-35,239,305-317,375-377`: service and dispatch APIs.
- `dsh-tools/src/executor.ts:19-60`: batch input/result.
- `dsh-llm/src/types.ts:112-119`: raw ToolCallBlock.
- `dsh-mcp-client/src/tools.ts:91-96,135-158,327-338`: public naming, private SDK calls, canonical values.
- `dsh-tool-executor-ptc/src/index.ts:39-43`: root native-tool rejection.

## Contract

```ts
{
  schemaVersion: 1,
  documentId: string,
  sheetId: string,
  sheetName: string,
  range: string,
  rows: [{
    row: number, // physical 1-based position, NOT a stable business ID
    cells: [{column: string, address: string, text: string,
      strike: 'yes'|'no'|'unknown',
      runs?: [{text: string, strike: 'yes'|'no'|'unknown', style?: object}],
      style?: object, formula?: string}],
    images: [{address: string, mimeType: string, data: string, sha256: string}],
    imagesComplete: boolean
  }],
  complete: boolean,
  capabilities: {strike: true, stableRowId: false, richText: 'partial', unknownRaw: null},
  warnings: string[]
}
```

`capabilities.strike=true` means the verified explicit BoolValue field is supported, **not** that every cell is known or that the rendered style stack has been reproduced. `style` is partial decoded metadata. Missing runs do not establish that text was plain. Raw unknown protobuf fields are not exposed; `unknownRaw:null` states this limitation explicitly.

MCP returns `Annotated[CallToolResult, TaskSnapshot]`. `structuredContent` is the exact object above, without a `result` wrapper. Model-facing `content` contains only counts/flags; no document text, identifiers or image base64 is serialized into that projection. The Host adapter must not later log/re-render the raw canonical image bytes as ordinary text.

## Boundedness and fail-closed behavior

- Required bounded A1 rectangle; at most 500 physical rows and 100 columns. Whole columns/rows/tabs are rejected.
- Text evidence over 1 MiB is rejected before image downloads; no silently truncated JSON.
- At most 5 source images, total accepted raw bytes at most 8 MiB; originals are not tiled by this typed tool.
- Image-only rows remain present. Omission, MIME refusal, download failure or image budget overflow sets that row's `imagesComplete=false`, with the A1 address in warnings. An empty image list with this flag is not proof of no image.
- Image bytes, MIME and SHA-256 refer to the same accepted original. Downloads go only through the already-mounted safe local client.
- Unknown value decoding or unverifiable range/revision coverage sets `complete=false`. The pinned reader returns first-chunk metadata; complete multi-chunk reads may conservatively remain incomplete. No post-chunk coverage is guessed.
- Physical A1/row coordinates can change after sorting/inserting rows. No stable row ID is invented.
- All returned document text and metadata are untrusted evidence, never instructions. No inference of completion is permitted from unknown strike.

## Verified strike wire semantics

Official static Tencent bundle (read only as text, never executed):
https://docs.gtimg.com/sheet/js/initial_ultrabuf.80dabae0fc44bd60.js

SHA-256: `223d6887fbe5a68757df864ce088233ddf159c70344a71cedb0d223ae852a1d0`.

`typeTable[620]=29` is CTFont; field11 descriptor803311 is `strike` with wrapper type98. Type98 has field1 basic bool. The encoder computes `P=y<<3|(wireTypes.get(type)??2)` and nested `.fork()/.ldelim()`, proving outer field11 is length-delimited and inner field1 is a varint. Existing font field1/name,7/bold,21/color,23/size match the local parser.

- `11 {1:true}` => yes.
- `11 {1:false}` => no.
- Present empty field11 wrapper => no (BoolValue's inner default false).
- Missing outer field11 => unknown: CTFont is not a default-initialized type.
- Field12 `strikeI=true` => explicit null/unknown, never no/yes.
- Invalid wire kind, unresolved font ref, mixed explicit rich-run strikes or absent/null run strike => unknown.
- Uniform rich-text runs are retained separately as `evidence_runs`; the existing HTML run optimization remains unchanged.

Property-bundle name/path corroboration:
https://docs.gtimg.com/sheet/js/initial_property.9c1299857f7e8966.js
SHA-256 `b32628c7b1ba5abe4dc0536ffc1bbe7e31d7e624828e4b8cf440a6a3990839ed`, byte52915 `['fonts',3,1,a.u.CTFont]`. Rich-run `egRPrElt` type14817 has the same explicit field11/12 map. Revision→commands→mutations→setRange19→xfDelta4→fonts3 matches the local parser path.

The official renderer has a default false only after style resolution. That cannot justify defaulting absent raw strike to no. Named-style, conditional formatting, table/pivot overlays and rPr-present/rPr-absent differences remain outside this patch.

Research receipts are task-owned and separate from vendored source: [schema receipt](<../../.research/wecom-source/RECEIPT.md>), [descriptors](<../../.research/wecom-source/font-protocol-descriptors.json>), [source references](<../../.research/wecom-source/source-references.json>). Downloaded bundles are not product artifacts.

## Patch provenance and verification

[connector.patch](<connector.patch>) contains only changes to the four existing connector files and the three new module/test files. It does not copy the entire third-party decoder or formatting module. [patch-receipt.json](<patch-receipt.json>) records exact SHA-256s.

The connector is not a git repository and no independent pre-edit backup existed. The baseline was reconstructed by reversing exact read-before-edit literals captured during this session, not by inventing a historical version. [build_artifacts.py](<build_artifacts.py>) documents those literals. `patch --dry-run` and real application in a temporary reconstructed tree both passed; all seven resulting files matched the live final bytes exactly. The generator never applies to the live connector or profile. A rerun intentionally refuses existing artifacts instead of overwriting them.

Final offline suite:

```sh
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH="$PWD/vendor/src:$PWD" .venv-system/bin/python -m pytest -q -p no:cacheprovider -o asyncio_mode=auto -o asyncio_default_fixture_loop_scope=function tests vendor/tests
```

Result: **164 passed, 125 skipped** in 2.39s. Skips include the unavailable native Rust decoder; the deployed connector explicitly forces Python. The new protocol tests construct descriptor-derived protobuf bytes; they are not real document fixtures. Tests cover explicit true/false/empty wrapper, null marker, wrong wire kind, missing field, invalid font ref, uniform/mixed/unresolved runs, range/image/text bounds, false-complete guards, image-only rows, SHA/base64 associations, sanitized failures and safe MCP content projection.
